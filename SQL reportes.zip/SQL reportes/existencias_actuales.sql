SELECT existencias_bodegas.codigo_producto, 
inventarios_productos.descripcion,existencias_bodegas.bodega, 
existencias_bodegas.existencia,
inventarios_productos.unidad_id,inventarios.COSTO,
inventarios.COSTO*existencias_bodegas.existencia AS TOTAL 
FROM existencias_bodegas 
INNER JOIN inventarios_productos on existencias_bodegas.codigo_producto = inventarios_productos.codigo_producto 
INNER JOIN INVENTARIOS ON inventarios_productos.codigo_producto = inventarios.codigo_producto 
WHERE ((inventarios.COSTO > 0) AND (existencias_bodegas.EXISTENCIA > 0)) OR 
(existencias_bodegas.EXISTENCIA > 0 AND inventarios.COSTO > 0)
ORDER BY existencias_bodegas.bodega, inventarios_productos.descripcion;