SELECT f.tercero_id, 
       t.nombre_tercero as tercero,
	   f.factura_fiscal as factura,
	   f.total_factura::integer as valor
FROM   fac_facturas f,
       terceros t
WHERE f.tercero_id=t.tercero_id
AND   f.tipo_factura IN ('3','4')
AND   f.estado='0'
AND   f.fecha_registro>=_1
AND   f.fecha_registro<=_2