select
cr.requisicion_id,
cr.fecha_requisicion as fecha_recepcion_requisicion,
d.descripcion as area_solicitante,
ip.codigo_producto as codigo,
ip.descripcion as descripcion_producto,
u.descripcion as unidad_de_manejo,
crd.cantidad::int as cantidad_requisicion
 
from
compras_requisiciones_detalle crd
LEFT OUTER JOIN compras_requisiciones cr ON cr.requisicion_id=crd.requisicion_id
LEFT OUTER JOIN inventarios_productos ip ON crd.codigo_producto=ip.codigo_producto
LEFT OUTER JOIN unidades u ON ip.unidad_id=u.unidad_id
LEFT OUTER JOIN departamentos d ON d.departamento=cr.departamento
where cr.fecha_requisicion between _1 and _2
order by cr.requisicion_id,crd.codigo_producto