SELECT
p.nombre AS PROFESIONAL, d.descripcion, c.descripcion AS actividad, pr.cantidad ,pa.tipo_id_paciente ||' '|| pa.paciente_id AS ID_PACIENTE, pa.primer_nombre ||' '||pa.segundo_nombre||' '||pa.primer_apellido||' '||pa.segundo_apellido AS nom_PACIENTE, pl.plan_descripcion AS Entidad ,a.fecha_cierre AS fecha
FROM
hc_evoluciones a
INNER JOIN hc_sub_procedimientos_realizados_notas_detalle pr ON pr.evolucion_id=a.evolucion_id
INNER JOIN ingresos i ON i.ingreso=a.ingreso AND i.ingreso=pr.ingreso
INNER JOIN profesionales p ON a.usuario_id=p.usuario_id
INNER JOIN departamentos d ON d.departamento=a.departamento
INNER JOIN cups c ON c.cargo=pr.cargo
INNER JOIN pacientes pa ON pa.paciente_id=i.paciente_id
INNER JOIN cuentas cu ON cu.ingreso=i.ingreso
INNER JOIN planes pl ON pl.plan_id=cu.plan_id
WHERE pr.cargo in ('933600','931000','939400','937000')
AND cu.fecha_registro::date BETWEEN _1 AND _2