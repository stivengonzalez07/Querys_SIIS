SELECT			din.codigo_producto,
				ip.descripcion AS producto,
				din.cantidad,
				p.tipo_id_paciente||' '||p.paciente_id AS id_paciente,
				p.primer_apellido||' '||p.segundo_apellido||' '||p.primer_nombre AS paciente,
				b.descripcion AS bodega
FROM			bodegas_documento_despacho_med bdm
INNER JOIN		bodegas_documento_despacho_ins_d din ON bdm.documento_despacho_id = din.documento_despacho_id
INNER JOIN		hc_solicitudes_insumos_d sin ON din.consecutivo_solicitud = sin.consecutivo_d
INNER JOIN		hc_solicitudes_medicamentos hcsm ON	sin.solicitud_id = hcsm.solicitud_id
INNER JOIN		bodegas b ON hcsm.bodega = b.bodega
INNER JOIN		estaciones_enfermeria ee ON hcsm.estacion_id = ee.estacion_id
INNER JOIN		Ingresos i ON hcsm.ingreso = i.ingreso
INNER JOIN		pacientes p ON i.paciente_id = p.paciente_id
INNER JOIN		inventarios_productos ip ON din.codigo_producto = ip.codigo_producto
WHERE 			bdm.fecha BETWEEN _1 AND _2
UNION ALL
SELECT			dmed.codigo_producto,
				ip.descripcion AS producto,
				round(dmed.cantidad,0) AS cantidad,
				p.tipo_id_paciente||' '||p.paciente_id AS id_paciente,
				p.primer_apellido||' '||p.segundo_apellido||' '||p.primer_nombre AS paciente,
				b.descripcion AS bodega
FROM			bodegas_documento_despacho_med bdm
INNER JOIN 		bodegas_documento_despacho_med_d dmed ON bdm.documento_despacho_id=dmed.documento_despacho_id
INNER JOIN 		hc_solicitudes_medicamentos_d smn ON dmed.consecutivo_solicitud=smn.consecutivo_d
INNER JOIN 		hc_solicitudes_medicamentos hcsm ON smn.solicitud_id=hcsm.solicitud_id
INNER JOIN 		bodegas b ON hcsm.bodega = b.bodega
INNER JOIN 		estaciones_enfermeria ee ON hcsm.estacion_id=ee.estacion_id
INNER JOIN 		ingresos i ON hcsm.ingreso=i.ingreso
INNER JOIN 		pacientes p ON i.paciente_id=p.paciente_id
INNER JOIN 		inventarios_productos ip ON dmed.codigo_producto=ip.codigo_producto
LEFT OUTER JOIN medicamentos m ON dmed.codigo_producto=m.codigo_medicamento
WHERE			bdm.fecha BETWEEN _1 AND _2
UNION ALL
SELECT			bdd.codigo_producto,
				ip.descripcion AS producto,
				round(cd.cantidad, 0) AS cantidad,
				p.tipo_id_paciente||' '||p.paciente_id AS id_paciente,
				p.primer_apellido||' '||p.segundo_apellido||' '||p.primer_nombre AS paciente,
				b.descripcion AS bodega
FROM 			cuentas c
INNER JOIN 		cuentas_detalle AS cd ON c.numerodecuenta=cd.numerodecuenta
INNER JOIN 		bodegas_documentos_d AS bdd ON bdd.consecutivo=cd.consecutivo
INNER JOIN 		bodegas_doc_numeraciones AS bdn ON bdn.bodegas_doc_id=bdd.bodegas_doc_id
INNER JOIN 		bodegas b ON bdn.bodega = b.bodega
INNER JOIN 		departamentos ee ON cd.departamento=ee.departamento
INNER JOIN 		ingresos i ON c.ingreso=i.ingreso
INNER JOIN 		system_usuarios su ON cd.usuario_id=su.usuario_id
INNER JOIN 		pacientes p ON i.paciente_id=p.paciente_id
INNER JOIN 		inventarios_productos ip ON bdd.codigo_producto=ip.codigo_producto
LEFT OUTER 		JOIN medicamentos m ON bdd.codigo_producto=m.codigo_medicamento
WHERE			bdn.bodega='29' AND cd.cargo='IMD' AND su.descripcion like '%FARMACIA%' 
AND				cd.fecha_cargo BETWEEN _1 AND _2
