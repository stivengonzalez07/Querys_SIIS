SELECT a.bodega,
e.descripcion as departamento,
b.descripcion,
a.prefijo, 
SUM (a.total_costo) as costo

FROM inv_bodegas_movimiento as a inner join documentos as b on a.documento_id=b.documento_id and a.prefijo=b.prefijo
     inner join tipos_doc_generales as c on b.tipo_doc_general_id=c.tipo_doc_general_id
     left join inv_bodegas_movimiento_consumo as d on a.prefijo=d.prefijo and a.numero=d.numero
     left join departamentos as e on d.departamento=e.departamento
     left join inv_bodegas_movimiento_compras_directas as f on a.prefijo=f.prefijo and a.numero=f.numero
     left join terceros as g on f.tipo_id_tercero=g.tipo_id_tercero and f.tercero_id=g.tercero_id
     left join inv_bodegas_movimiento_traslados as h on a.prefijo=h.prefijo and a.numero=h.numero
     left join inv_bodegas_movimiento_aprovechamientos as i on a.prefijo=i.prefijo and a.numero=i.numero
     left join inv_bodegas_tipos_aprovechamiento as j on i.tipo_aprovechamiento_id=j.tipo_aprovechamiento_id
     left join inv_bodegas_movimiento_conceptos_egresos as k on a.prefijo=k.prefijo and a.numero=k.numero
     left join inv_bodegas_conceptos_egresos as l on k.concepto_egreso_id=l.concepto_egreso_id
     left join inv_bodegas_movimiento_devoluciones as m on a.prefijo=m.prefijo and a.numero=m.numero
     left join inv_bodegas_movimiento_perdidas as n on a.prefijo=n.prefijo and a.numero=n.numero
     left join inv_bodegas_tipos_perdidas as o on n.tipo_perdida_id=o.tipo_perdida_id
     left join inv_bodegas_movimiento_prestamos as p on a.prefijo=p.prefijo and a.numero=p.numero
     left join inv_bodegas_tipos_prestamos as q on p.tipo_prestamo_id=q.tipo_prestamo_id                         
                                                                          
WHERE a.fecha_registro::date >= _1
AND    a.fecha_registro::date <= _2
GROUP BY a.bodega,e.descripcion,b.descripcion,a.prefijo 
ORDER BY 2


