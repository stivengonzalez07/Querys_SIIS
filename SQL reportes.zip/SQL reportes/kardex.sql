SELECT  a.codigo_producto,
        a.descripcion,
        SUM(a.salidas::integer) as salidas,
        SUM(a.entradas::integer) as entradas
FROM    (
        SELECT  prod.codigo_producto,
                IP.descripcion,
                SUM(prod.salidas) as salidas,
                SUM(prod.entradas) as entradas
        FROM    
                (
                SELECT  BDD.codigo_producto,
                        CASE WHEN BDN.tipo_movimiento = 'E' THEN BDD.cantidad
                        ELSE 0 END as salidas,
                        CASE WHEN BDN.tipo_movimiento = 'I' THEN BDD.cantidad
                        ELSE 0 END as entradas
                FROM    bodegas_doc_numeraciones BDN,
                        bodegas_documentos BD,
                        bodegas_documentos_d BDD
                WHERE   BDN.bodegas_doc_id = BD.bodegas_doc_id
                AND     BD.bodegas_doc_id = BDD.bodegas_doc_id
                AND     BD.numeracion = BDD.numeracion
                AND     BD.fecha_registro::date >= _1
                AND     BD.fecha_registro::date <= _2
                AND     BDN.bodega = 'BC'
                ORDER BY 1,2
                ) as prod,
                inventarios_productos IP
        WHERE   prod.codigo_producto = IP.codigo_producto        
        GROUP BY 1,2
        UNION
        SELECT  trans.codigo_producto,
                IP.descripcion,
                SUM(trans.salidas) as salidas,
                SUM(trans.entradas) as entradas
        FROM    
                (
                SELECT  IMD.codigo_producto,
                        CASE WHEN TG.inv_tipo_movimiento = 'E' THEN IMD.cantidad
                        ELSE 0 END as salidas,
                        CASE WHEN TG.inv_tipo_movimiento = 'I' THEN IMD.cantidad
                        ELSE 0 END as entradas
                FROM    tipos_doc_generales TG,
                        documentos D,
                        inv_bodegas_movimiento IM,
                        inv_bodegas_movimiento_d IMD
                WHERE   TG.tipo_doc_general_id = D.tipo_doc_general_id
                AND     D.documento_id = IM.documento_id
                AND     IM.prefijo = IMD.prefijo
                AND     IM.numero = IMD.numero
                AND     IM.fecha_registro::date >= _1
                AND     IM.fecha_registro::date <= _2
                AND     TG.inv_tipo_movimiento IN ('I','E')
                AND     IM.bodega = 'BC'
                ORDER BY 1,2
                ) as trans,
                inventarios_productos IP
        WHERE   trans.codigo_producto = IP.codigo_producto        
        GROUP BY 1,2
        UNION
        SELECT  tras_S.codigo_producto,
                IP.descripcion,
                SUM(tras_S.salidas) as salidas,
                SUM(tras_S.entradas) as entradas
        FROM    
                (
                SELECT  IMD.codigo_producto,
                        IMD.cantidad as salidas,
                        0 as entradas,
                        IMD.prefijo,
                        IMD.numero
                FROM    tipos_doc_generales TG,
                        documentos D,
                        inv_bodegas_movimiento IM,
                        inv_bodegas_movimiento_d IMD
                WHERE   TG.tipo_doc_general_id = D.tipo_doc_general_id
                AND     D.documento_id = IM.documento_id
                AND     IM.prefijo = IMD.prefijo
                AND     IM.numero = IMD.numero
                AND     IM.fecha_registro::date >= _1
                AND     IM.fecha_registro::date <= _2
                AND     TG.inv_tipo_movimiento IN ('T')
                AND     IM.bodega = 'BC'
                ORDER BY 1,2
                ) as tras_S,
                inventarios_productos IP
        WHERE   tras_S.codigo_producto = IP.codigo_producto        
        GROUP BY 1,2
        UNION
        SELECT  tras_E.codigo_producto,
                IP.descripcion,
                SUM(tras_E.salidas) as salidas,
                SUM(tras_E.entradas) as entradas
        FROM    
                (
                SELECT  IMD.codigo_producto,
                        0 as salidas,
                        IMD.cantidad as entradas,
                        IMD.prefijo,
                        IMD.numero
                FROM    tipos_doc_generales TG,
                        documentos D,
                        inv_bodegas_movimiento IM,
                        inv_bodegas_movimiento_d IMD,
                        inv_bodegas_movimiento_traslados IMT
                WHERE   TG.tipo_doc_general_id = D.tipo_doc_general_id
                AND     D.documento_id = IM.documento_id
                AND     IM.prefijo = IMD.prefijo
                AND     IM.numero = IMD.numero
                AND     IM.fecha_registro::date >= _1
                AND     IM.fecha_registro::date <= _2
                AND     IMT.prefijo = IM.prefijo
                AND     IMT.numero = IM.numero
                AND     IMT.bodega_destino = 'BC'
                AND     TG.inv_tipo_movimiento IN ('T')
                ORDER BY 1,2
                ) as tras_E,
                inventarios_productos IP
        WHERE   tras_E.codigo_producto = IP.codigo_producto        
        GROUP BY 1,2
        ) AS a
GROUP BY 1,2
ORDER BY 2
 
          