SELECT d.descripcion, SUM(cd.valor_cubierto)
FROM cuentas c,cuentas_detalle cd,departamentos d
WHERE cd.departamento_al_cargar=d.departamento
AND c.estado='0'
AND c.numerodecuenta=cd.numerodecuenta
GROUP BY d.descripcion