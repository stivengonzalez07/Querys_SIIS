SELECT cgc.documento_contable_id AS Documento_Contable,
        cgc.tercero_id,
        t.nombre_tercero,
        cgcd.debito,
        cgcd.credito,
        cgc.fecha_documento AS Fecha_Documento,
        cgc.prefijo AS Prefijo_Factura,
        cgc.numero AS Numero_Factura,
        cgcd.cuenta AS Cuenta_UnoE
FROM cg_mov_01.cg_mov_contable_01 cgc
INNER JOIN cg_mov_01.cg_mov_contable_01_detalle cgcd ON cgc.documento_contable_id = cgcd.documento_contable_id
INNER JOIN terceros t ON cgc.tercero_id = t.tercero_id
WHERE cgc.fecha_documento BETWEEN _1 AND _2

