SELECT DISTINCT i.ingreso,
        	--i.paciente_id,
        	--i.tipo_id_paciente,
        	to_char(i.fecha_ingreso, 'DD-MM-YYYY') as  fecha_ingreso,
        	to_char(i.fecha_ingreso,'HH24:MI:SS') as hora,
			CASE 
			WHEN i.departamento='CEXUBA' THEN 'CONSULTA EXTERNA TEQUENDAMA'
			WHEN i.departamento='ADCETE' THEN 'ADMON CONSULTA EXTERNA TEQUENDAMA'
			WHEN i.departamento='SPRUBA' THEN 'SALA DE PROCEDIMIENTOS TEQUENDAMA'
			WHEN i.departamento='CESUBA' THEN 'CENTRAL DE ESTERILIZACION TEQUENDAMA'
			WHEN i.departamento='CITUBA' THEN 'CITOLOGIA TEQUENDAMA'
			WHEN i.departamento='DMEUBA' THEN 'DIRECCION MEDICA TEQUENDAMA'
			WHEN i.departamento='IMAUBA' THEN 'IMAGENOLOGIA TEQUENDAMA'
			WHEN i.departamento='NUTUBA' THEN 'NUTRICION TEQUENDAMA'
			WHEN i.departamento='ODOUBA' THEN 'ODONTOLOGIA TEQUENDAMA'
			WHEN i.departamento='OPTUBA' THEN 'OPTOMETRIA TEQUENDAMA'
			WHEN i.departamento='PYPUBA' THEN 'PROMOCION Y PREVENCION TEQUENDAMA'
			WHEN i.departamento='PSIUBA' THEN 'PSICOLOGIA TEQUENDAMA'
			WHEN i.departamento='TOMUBA' THEN 'TOMA DE MUESTRAS TEQUENDAMA'
			WHEN i.departamento='VACUBA' THEN 'VACUNACION TEQUENDAMA' END AS departamento,
			p.tipo_id_paciente as tipo_id,
			p.paciente_id,
			p.primer_nombre || ' ' || p.segundo_nombre || ' ' || p.primer_apellido || ' ' || p.segundo_apellido AS nombre,
    		p.sexo_id as sexo,
            edad(p.fecha_nacimiento),
    		s.nombre as Profesional,
			esp.descripcion,
    		di.tipo_diagnostico_id as codigo_diag,
    		d.diagnostico_nombre
FROM    	pacientes p,
          	planes pl,
          	ingresos i,
          	hc_evoluciones e,
          	cuentas c,
    		system_usuarios s,
    		profesionales pro,
    		tipos_profesionales tpro,
    		hc_diagnosticos_ingreso di,
    		diagnosticos d,
    		profesionales_especialidades pe,
			especialidades esp
WHERE   	i.paciente_id = p.paciente_id
AND     	i.tipo_id_paciente = p.tipo_id_paciente
AND     	c.ingreso = i.ingreso
AND     	c.plan_id = pl.plan_id
AND     	i.ingreso = e.ingreso
--AND    		i.departamento = 'CEXUBA'
AND    		e.usuario_id = s.usuario_id
AND    		e.usuario_id = pro.usuario_id
AND     	pro.tercero_id = pe.tercero_id
AND 		pe.especialidad = esp.especialidad
AND    		pro.tipo_profesional = tpro.tipo_profesional
AND    		di.evolucion_id = e.evolucion_id
AND    		di.tipo_diagnostico_id = d.diagnostico_id
AND			i.fecha_ingreso::date Between _1 AND _2
ORDER BY    	edad

