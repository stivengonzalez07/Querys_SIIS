SELECT 
a.numerodecuenta,
a.fecha_ingreso,
a.fecha_cuenta, 
a.total_cuenta, 
a.valor_cuota_paciente,
a.valor_cuota_moderadora,
a.id_paciente,
a.primer_apellido, 
a.segundo_apellido, 
a.primer_nombre, 
a.segundo_nombre,
a.ENTIDAD, 
a.fecha_factura, 
a.prefijo, 
a.nro_factura, 
a.total_factura,
SUM(a.valor_recibos) as valor_recibos,
SUM(a.valor_glosa_aceptado) AS valor_glosa_aceptado,
SUM(a.vr_nota_credito) AS vr_nota_credito,
SUM(a.vr_nota_debito) AS vr_nota_debito,
a.saldo_factura

FROM (

SELECT 
c.numerodecuenta,
i.fecha_ingreso, 
c.fecha_registro::date AS fecha_cuenta, 
c.total_cuenta, 
ff.valor_cuota_paciente,
ff.valor_cuota_moderadora,
i.tipo_id_paciente||' '||i.paciente_id AS id_paciente,
pc.primer_apellido, 
pc.segundo_apellido, 
pc.primer_nombre, 
pc.segundo_nombre,

p.plan_descripcion AS ENTIDAD, 
ff.fecha_registro::date AS fecha_factura, 
ff.prefijo, 
ff.factura_fiscal AS nro_factura, 
COALESCE(ff.total_factura,0) as total_factura,
0 AS valor_recibos,
0 AS valor_glosa_aceptado,
COALESCE(sum(nc.valor_nota),0) AS vr_nota_credito,
COALESCE(sum(nd.valor_nota),0) AS vr_nota_debito,
ff.saldo as saldo_factura

FROM
cuentas c

LEFT OUTER JOIN fac_facturas_cuentas ffc ON c.numerodecuenta=ffc.numerodecuenta
LEFT OUTER JOIN fac_facturas ff ON ffc.factura_fiscal=ff.factura_fiscal AND ffc.prefijo=ff.prefijo
INNER JOIN  planes p ON c.plan_id=p.plan_id
LEFT OUTER JOIN ingresos i ON c.ingreso=i.ingreso
LEFT OUTER JOIN ingresos_salidas es ON i.ingreso=es.ingreso
LEFT OUTER JOIN departamentos d ON es.departamento_egreso=d.departamento
INNER JOIN pacientes pc ON i.paciente_id=pc.paciente_id AND i.tipo_id_paciente=pc.tipo_id_paciente
LEFT OUTER JOIN glosas g ON ff.factura_fiscal=g.factura_fiscal AND g.prefijo=ff.prefijo AND g.sw_estado != '0' 
LEFT OUTER JOIN notas_credito nc ON ff.prefijo=nc.prefijo_factura AND ff.factura_fiscal=nc.factura_fiscal AND nc.estado='1'
LEFT OUTER JOIN notas_debito nd ON ff.prefijo=nd.prefijo_factura AND ff.factura_fiscal=nd.factura_fiscal AND nd.estado='1'

WHERE
ff.estado<>'3' AND
--ff.fecha_registro::date BETWEEN '2018-01-01' AND '2018-01-02' 
ff.fecha_registro::date BETWEEN _1 AND _2 

GROUP BY 
c.numerodecuenta, 
c.fecha_registro, c.total_cuenta, ff.valor_cuota_paciente,
ff.valor_cuota_moderadora,
p.plan_descripcion, 
ff.fecha_registro, ff.prefijo, ff.factura_fiscal, ff.total_factura, 
i.tipo_id_paciente, i.paciente_id,
pc.primer_apellido, pc.segundo_apellido, pc.primer_nombre, pc.segundo_nombre, i.ingreso, i.fecha_ingreso, g.valor_aceptado, nc.valor_nota, nd.valor_nota, 
ff.saldo 

--MARLONDON
UNION

SELECT 
c.numerodecuenta,
i.fecha_ingreso, 
c.fecha_registro::date AS fecha_cuenta, 
c.total_cuenta, 
ff.valor_cuota_paciente,
ff.valor_cuota_moderadora,
 i.tipo_id_paciente||' '||i.paciente_id AS id_paciente,
pc.primer_apellido, 
pc.segundo_apellido, 
pc.primer_nombre, 
pc.segundo_nombre,
p.plan_descripcion AS ENTIDAD, 
ff.fecha_registro::date AS fecha_factura, 
ff.prefijo, 
ff.factura_fiscal AS nro_factura, 
COALESCE(ff.total_factura,0) as total_factura,
0 AS valor_recibos,
sum(ng.valor_aceptado) AS valor_glosa_aceptado,
0 AS vr_nota_credito,
0 AS vr_nota_debito,
ff.saldo as saldo_factura
 
FROM
cuentas c

LEFT OUTER JOIN fac_facturas_cuentas ffc ON c.numerodecuenta=ffc.numerodecuenta
LEFT OUTER JOIN fac_facturas ff ON ffc.factura_fiscal=ff.factura_fiscal AND ffc.prefijo=ff.prefijo
INNER JOIN  planes p ON c.plan_id=p.plan_id
LEFT OUTER JOIN ingresos i ON c.ingreso=i.ingreso
LEFT OUTER JOIN ingresos_salidas es ON i.ingreso=es.ingreso
LEFT OUTER JOIN departamentos d ON es.departamento_egreso=d.departamento
INNER JOIN pacientes pc ON i.paciente_id=pc.paciente_id AND i.tipo_id_paciente=pc.tipo_id_paciente
LEFT OUTER JOIN glosas g ON ff.factura_fiscal=g.factura_fiscal AND g.prefijo=ff.prefijo AND g.sw_estado != '0'
LEFT OUTER JOIN notas_credito_glosas ng ON g.glosa_id=ng.glosa_id


WHERE
ff.estado<>'3' AND
--ff.fecha_registro::date BETWEEN '2018-01-01' AND '2018-01-02' 
ff.fecha_registro::date BETWEEN _1 AND _2 

GROUP BY 
c.numerodecuenta, 
c.fecha_registro, c.total_cuenta, ff.valor_cuota_paciente,
ff.valor_cuota_moderadora,
p.plan_descripcion, 
ff.fecha_registro, ff.prefijo, ff.factura_fiscal, ff.total_factura, 
i.tipo_id_paciente, i.paciente_id,
pc.primer_apellido, pc.segundo_apellido, pc.primer_nombre, pc.segundo_nombre, i.ingreso, i.fecha_ingreso, g.valor_aceptado,  
ff.saldo 

UNION

SELECT 
c.numerodecuenta,
i.fecha_ingreso, 
c.fecha_registro::date AS fecha_cuenta, 
c.total_cuenta,
ff.valor_cuota_paciente,
ff.valor_cuota_moderadora, 
 i.tipo_id_paciente||' '||i.paciente_id AS id_paciente,
pc.primer_apellido, 
pc.segundo_apellido, 
pc.primer_nombre, 
pc.segundo_nombre,
p.plan_descripcion AS ENTIDAD, 
ff.fecha_registro::date AS fecha_factura, 
ff.prefijo, 
ff.factura_fiscal AS nro_factura, 
COALESCE(ff.total_factura,0) as total_factura,
sum(rcf.valor_abonado) AS valor_recibos,
0 AS valor_glosa_aceptado,
0 AS vr_nota_credito,
0 AS vr_nota_debito,
ff.saldo as saldo_factura
 
FROM
cuentas c

LEFT OUTER JOIN fac_facturas_cuentas ffc ON c.numerodecuenta=ffc.numerodecuenta
LEFT OUTER JOIN fac_facturas ff ON ffc.factura_fiscal=ff.factura_fiscal AND ffc.prefijo=ff.prefijo
LEFT OUTER JOIN rc_detalle_tesoreria_facturas rcf ON ff.factura_fiscal=rcf.factura_fiscal AND ff.prefijo=rcf.prefijo_factura AND rcf.sw_estado='0'
INNER JOIN  planes p ON c.plan_id=p.plan_id
LEFT OUTER JOIN ingresos i ON c.ingreso=i.ingreso
LEFT OUTER JOIN ingresos_salidas es ON i.ingreso=es.ingreso
LEFT OUTER JOIN departamentos d ON es.departamento_egreso=d.departamento
INNER JOIN pacientes pc ON i.paciente_id=pc.paciente_id AND i.tipo_id_paciente=pc.tipo_id_paciente

WHERE
ff.estado<>'3' AND
ff.fecha_registro::date BETWEEN _1 AND _2 
--ff.fecha_registro::date BETWEEN '2018-01-01' AND '2018-01-02' 

GROUP BY 
c.numerodecuenta, 
c.fecha_registro, c.total_cuenta, ff.valor_cuota_paciente,
ff.valor_cuota_moderadora,
p.plan_descripcion, 
ff.fecha_registro, ff.prefijo, ff.factura_fiscal, ff.total_factura, 
i.tipo_id_paciente, i.paciente_id,
pc.primer_apellido, pc.segundo_apellido, pc.primer_nombre, pc.segundo_nombre, i.ingreso, i.fecha_ingreso,  
ff.saldo 
) a

GROUP BY a.numerodecuenta,
a.fecha_ingreso, 
a. fecha_cuenta, 
a.total_cuenta, 
a.valor_cuota_paciente,
a.valor_cuota_moderadora,
a.id_paciente,
a.primer_apellido, 
a.segundo_apellido, 
a.primer_nombre, 
a.segundo_nombre,
a.ENTIDAD, 
a.fecha_factura, 
a.prefijo, 
a.nro_factura, 
a.total_factura,
a.saldo_factura