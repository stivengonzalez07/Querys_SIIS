select  a.numerodecuenta,c.ingreso,g.fecha_ingreso,g.paciente_id,
a.departamento,
f.descripcion,
a.tarifario_id,
a.cantidad,
a.precio,
a.valor_cargo,
a.cargo_cups,
b.cargo,
b.descripcion,
a.fecha_cargo as fecha_cargo_producto
 from 
 cuentas_detalle a,
 tarifarios_detalle b,
 cuentas c,
 planes e,
 departamentos f,
 ingresos g
 where
c.plan_id=e.plan_id AND
a.tarifario_id=b.tarifario_id and
a.cargo=b.cargo and
a.cargo not in ('DIMD','IMD') and
a.numerodecuenta=c.numerodecuenta AND
c.estado!='5' and
c.ingreso=g.ingreso and
a.departamento=f.departamento and
e.tercero_id='817000248' and c.fecha_registro::date BETWEEN _1 AND _2