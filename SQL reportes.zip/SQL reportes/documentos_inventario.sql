SELECT a.bodega AS BODEGA,
h.bodega_destino AS BODEGA_DESTINO,
c.inv_tipo_movimiento,
e.descripcion as DEPARTAMENTO,
l.descripcion as TIPO_E_CONCEPTOS_VARIOS,
m.documento_devolucion AS DOC_DEVOLUCION,
j.descripcion as tipo_aprovechamientio,
o.descripcion as tipo_perdida,
q.descripcion as tipo_prestamo,
f.tipo_id_tercero AS TIPO_TERCERO_COMPRAS_DIRECTA,
f.tercero_id AS COD_TERCERO_COMPRAS_DIRECTAS,
g.nombre_tercero AS NOMBRE_TERCERO_COMPRAS_DIRECTAS,
f.documento_compra AS DOCUMENTO_COMPRA_DIRECTA,
cd.prefijo_factura::text || cd.numero_factura::text AS FACTURA_ORDEN_COMPRA,
b.descripcion,
a.prefijo,
a.numero AS CONSECUTIVO,
a.observacion,
a.fecha_registro,
a.total_costo,
ab.codigo_producto,
ip.descripcion,
md.codigo_cum

FROM inv_bodegas_movimiento as a inner join documentos as b on a.documento_id=b.documento_id and a.prefijo=b.prefijo
     inner join tipos_doc_generales as c on b.tipo_doc_general_id=c.tipo_doc_general_id
     left join inv_bodegas_movimiento_consumo as d on a.prefijo=d.prefijo and a.numero=d.numero
     left join departamentos as e on d.departamento=e.departamento
     left join inv_bodegas_movimiento_compras_directas as f on a.prefijo=f.prefijo and a.numero=f.numero
     left join terceros as g on f.tipo_id_tercero=g.tipo_id_tercero and f.tercero_id=g.tercero_id
	 left join inv_bodegas_movimiento_ordenes_compra cd on a.prefijo=cd.prefijo and a.numero=cd.numero
     left join inv_bodegas_movimiento_traslados as h on a.prefijo=h.prefijo and a.numero=h.numero
     left join inv_bodegas_movimiento_aprovechamientos as i on a.prefijo=i.prefijo and a.numero=i.numero
     left join inv_bodegas_tipos_aprovechamiento as j on i.tipo_aprovechamiento_id=j.tipo_aprovechamiento_id
     left join inv_bodegas_movimiento_conceptos_egresos as k on a.prefijo=k.prefijo and a.numero=k.numero
     left join inv_bodegas_conceptos_egresos as l on k.concepto_egreso_id=l.concepto_egreso_id
     left join inv_bodegas_movimiento_devoluciones as m on a.prefijo=m.prefijo and a.numero=m.numero
     left join inv_bodegas_movimiento_perdidas as n on a.prefijo=n.prefijo and a.numero=n.numero
     left join inv_bodegas_tipos_perdidas as o on n.tipo_perdida_id=o.tipo_perdida_id
     left join inv_bodegas_movimiento_prestamos as p on a.prefijo=p.prefijo and a.numero=p.numero
     left join inv_bodegas_tipos_prestamos as q on p.tipo_prestamo_id=q.tipo_prestamo_id
	 left join inv_bodegas_movimiento_d as ab on a.prefijo=ab.prefijo and a.numero=ab.numero
	 left join inventarios_productos as ip on ab.codigo_producto=ip.codigo_producto
	 left join medicamentos as md on ip.codigo_producto=md.codigo_medicamento                   
                                                                           
WHERE a.fecha_registro::date >= _1
AND   a.fecha_registro::date <= _2   
ORDER BY 14,15
