SELECT e.envio_id as envio,p.plan_descripcion as entidad,ed.prefijo,ed.factura_fiscal as Factura,e.fecha_registro::date
FROM envios e,envios_detalle ed,planes p,envios_planes ep
WHERE e.sw_estado='2'
AND e.envio_id=ed.envio_id
AND ep.envio_id=e.envio_id
AND ep.plan_id=p.plan_id
AND e.fecha_registro::date>=_1
AND e.fecha_registro::date<=_2
ORDER BY 1