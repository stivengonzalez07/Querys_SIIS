SELECT  a.acta_conciliacion_id, 
		a.tipo_id_tercero,
		a.tercero_id,
		t.nombre_tercero,
		a.fecha_acta,
		a.prefijo as prefijo_acta,
		a.numero as numero_acta,
		ac.prefijo,
		ac.factura_fiscal,
		ac.valor_aceptado_ips,
		ac.valor_aceptado_eps,
		f.saldo as saldo_factura,
		ac.observacion
FROM 	actas_conciliacion_glosas a,
		actas_conciliacion_glosas_detalle ac,
		fac_facturas f,
		terceros t
WHERE	a.acta_conciliacion_id=ac.acta_conciliacion_id
AND		a.tercero_id=t.tercero_id
AND		ac.prefijo=f.prefijo
AND		ac.factura_fiscal=f.factura_fiscal
AND		a.sw_activo='1'
AND 	a.fecha_acta::date BETWEEN _1 AND _2
ORDER BY 1
		
		