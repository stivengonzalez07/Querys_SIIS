SELECT  D.diagnostico_id,
        D.diagnostico_nombre,
        to_char(I.fecha_ingreso,'YYYY-MM-DD') AS fecha_ingreso,
        P.tipo_id_paciente,
        P.paciente_id,
        P.primer_nombre,
        P.segundo_nombre,
        P.primer_apellido,
        P.segundo_apellido,
        to_char(age (I.fecha_ingreso, P.fecha_nacimiento),'YY') || ' A�o(s)' AS edad,
        P.residencia_direccion,
        P.residencia_telefono
FROM    ingresos I,
        pacientes P,
        diagnosticos D,
        hc_diagnosticos_egreso DE,
        hc_evoluciones HE
WHERE   I.fecha_registro::date >=_1
AND     I.fecha_registro::date <=_2
AND     I.tipo_id_paciente = P.tipo_id_paciente
AND     I.paciente_id = P.paciente_id
AND     I.ingreso = HE.ingreso
AND     HE.evolucion_id = DE.evolucion_id
AND     DE.tipo_diagnostico_id = D.diagnostico_id
AND     DE.sw_principal = '1'
AND     D.diagnostico_id IN ( 'B059',
                              'B052',
                              'B050',
                              'B069',
                              'B068',
                              'B060',
                              'B082',
                              'B09X',
                              'B083',
                              'A38X',
                              'A90X',
                              'A91X',
                              'G728',
                              'G610',
                              'M792'
                            )
ORDER BY 1
                   