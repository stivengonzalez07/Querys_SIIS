SELECT
cd.consecutivo AS nro_consecutivo,
c.ingreso,
cd.numerodecuenta, 
pl.plan_descripcion,
cd.fecha_cargo, 
CASE WHEN c.estado = '0' THEN 'FACTURADA'
     WHEN c.estado = '1' THEN 'ACTIVA'
     WHEN c.estado = '2' THEN 'INACTIVA'
     WHEN c.estado = '3' THEN 'CUADRADA'
	 ELSE 'ANULADA' END AS estado_cta,
b.descripcion AS bodega, 
CASE WHEN m.sw_uso_controlado='1' THEN 'USO CONTROLADO'
ELSE 'NO CONTROLADO' END AS med_control,
CASE WHEN m.sw_pos='0' THEN 'NO POS' 
	 WHEN m.sw_pos='1' THEN 'POS' 
	 ELSE 'POS' END AS sw_pos,
ee.descripcion AS estacion_enfermeria, 
p.tipo_id_paciente||' '||p.paciente_id AS id_paciente, p.primer_apellido||' '||p.segundo_apellido||' '||p.primer_nombre AS paciente,
su.nombre as Usuario,
cd.cargo,
round(cd.cantidad,0) as cantidad,
bdd.codigo_producto,
ip.descripcion AS producto
FROM cuentas c
INNER JOIN cuentas_detalle AS cd ON c.numerodecuenta=cd.numerodecuenta
INNER JOIN planes AS pl ON c.plan_id=pl.plan_id
INNER JOIN bodegas_documentos_d AS bdd ON bdd.consecutivo=cd.consecutivo
INNER JOIN bodegas_doc_numeraciones AS bdn ON bdn.bodegas_doc_id=bdd.bodegas_doc_id
INNER JOIN bodegas b ON bdn.bodega = b.bodega
INNER JOIN departamentos ee ON cd.departamento=ee.departamento
INNER JOIN ingresos i ON c.ingreso=i.ingreso
INNER JOIN system_usuarios su ON cd.usuario_id=su.usuario_id
INNER JOIN pacientes p ON i.paciente_id=p.paciente_id
INNER JOIN inventarios_productos ip ON bdd.codigo_producto=ip.codigo_producto
LEFT  JOIN medicamentos m ON bdd.codigo_producto=m.codigo_medicamento
WHERE cd.fecha_cargo::date BETWEEN _1 AND _2
ORDER BY cd.numerodecuenta, bdd.codigo_producto

