select a.prefijo,
a.numero,
a.observacion,
a.fecha_registro,
d.descripcion as Bodega,
a.usuario_id,c.nombre as nombre_Usuario,
b.cantidad,
b.porcentaje_gravamen,
i.costo_anterior,
i.costo,
b.total_costo,
b.fecha_vencimiento,
b.lote,b.codigo_producto,
e.descripcion

from inv_bodegas_movimiento a,
inv_bodegas_movimiento_d b,
system_usuarios c,bodegas d,
inventarios_productos e,
inventarios i

where a.prefijo=b.prefijo and
a.numero=b.numero and
a.usuario_id=c.usuario_id and
a.bodega=d.bodega and b.codigo_producto=e.codigo_producto  and
b.codigo_producto=e.codigo_producto and
i.codigo_producto=b.codigo_producto and
a.fecha_registro between _1 and _2
