SELECT
invbd.prefijo, invbd.numero, invbd.codigo_producto, invp.descripcion, invb.fecha_registro::date, invbd.cantidad, 
invbd.total_costo AS valor_venta, invb.total_costo AS valor_ingreso, invb.bodega, bd.descripcion
FROM inv_bodegas_movimiento_d invbd
INNER JOIN inventarios_productos invp ON(invp.codigo_producto=invbd.codigo_producto)
INNER JOIN inv_bodegas_movimiento invb ON(invb.prefijo=invbd.prefijo AND invb.numero=invbd.numero)
INNER JOIN bodegas bd ON(bd.bodega=invb.bodega)
WHERE invbd.prefijo='IA' 
AND invb.fecha_registro::date BETWEEN _1 AND _2
ORDER BY invbd.numero

