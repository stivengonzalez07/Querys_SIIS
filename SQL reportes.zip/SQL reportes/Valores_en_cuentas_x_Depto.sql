SELECT d.descripcion as Departamento,SUM(cd.valor_cargo::integer)as valor
FROM cuentas_detalle cd,planes p,cuentas c,departamentos d
WHERE c.plan_id=p.plan_id
AND c.estado != '5'
AND cd.facturado='1'
AND cd.departamento_al_cargar=d.departamento
AND c.numerodecuenta=cd.numerodecuenta
AND cd.fecha_cargo::date>=_1
AND cd.fecha_cargo::date<=_2
GROUP BY d.descripcion
ORDER BY 1;