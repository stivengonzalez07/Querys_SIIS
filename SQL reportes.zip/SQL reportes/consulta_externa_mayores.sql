SELECT DISTINCT i.ingreso,
        	i.paciente_id,
        	i.tipo_id_paciente,
        	to_char(i.fecha_ingreso, 'DD-MM-YYYY') as  fecha_ingreso,
        	to_char(i.fecha_ingreso,'HH24:MI:SS') as hora,
			p.tipo_id_paciente,
			p.paciente_id,
			p.primer_nombre || p.segundo_nombre || p.primer_apellido || p.segundo_apellido AS nombre,
    		p.sexo_id,
            edad(p.fecha_nacimiento),
          	pl.plan_descripcion,
    		s.nombre as doctor,
          	c.valor_total_paciente,
    		di.tipo_diagnostico_id,
    		d.diagnostico_nombre
FROM    	pacientes p,
          	planes pl,
          	ingresos i,
          	hc_evoluciones e,
          	cuentas c,
    		system_usuarios s,
    		profesionales pro,
    		tipos_profesionales tpro,
    		hc_diagnosticos_ingreso di,
    		diagnosticos d,
    		profesionales_especialidades pe
WHERE   	i.paciente_id = p.paciente_id
AND     	i.tipo_id_paciente = p.tipo_id_paciente
AND     	c.ingreso = i.ingreso
AND     	c.plan_id = pl.plan_id
AND     	i.ingreso = e.ingreso
AND    		i.departamento = 'CEXTER'
AND    		e.usuario_id = s.usuario_id
AND    		e.usuario_id = pro.usuario_id
--AND     	pe.especialidad = '025'
AND     	pro.tercero_id = pe.tercero_id
AND    		pro.tipo_profesional = tpro.tipo_profesional
AND    		di.evolucion_id = e.evolucion_id
AND    		di.tipo_diagnostico_id = d.diagnostico_id
AND		    edad(p.fecha_nacimiento) > 18
ORDER BY    	pl.plan_descripcion
