SELECT c.numerodecuenta
FROM cuentas as c
WHERE c.estado = '5'
AND c.numerodecuenta NOT IN(select numerodecuenta FROM auditoria_anulacion_cuentas)
AND c.fecha_registro >= _1
AND c.fecha_registro <= _2