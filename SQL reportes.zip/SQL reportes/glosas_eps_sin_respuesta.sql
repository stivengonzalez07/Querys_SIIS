SELECT g.glosa_id,g.prefijo,g.factura_fiscal,g.fecha_glosa, (current_date-fecha_glosa) as diferencia, g.fecha_registro,g.valor_glosa, g.sw_devolucion_factura,p.plan_descripcion,
s.nombre,g.sw_glosa_total_factura
FROM glosas g, fac_facturas f, planes p, system_usuarios s
WHERE  NOT EXISTS 
	(
	SELECT * 
	FROM glosas_respuestas gl 
	WHERE gl.glosa_id=g.glosa_id
	)
AND g.prefijo=f.prefijo
AND g.factura_fiscal=f.factura_fiscal
AND f.plan_id=p.plan_id
AND g.sw_estado!='0'
AND p.tipo_cliente!='20'
ANd g.fecha_registro::date between _1 and _2 and g.usuario_id=s.usuario_id
GROUP BY 1,2,3,5,6,7,8,9,10
ORDER BY 3