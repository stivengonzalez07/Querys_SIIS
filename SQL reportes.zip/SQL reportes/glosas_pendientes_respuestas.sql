SELECT a.glosa_id,a.prefijo,a.factura_fiscal,a.fecha_glosa,
       a.valor_glosa,a.valor_aceptado,a.fecha_registro,
       a.valor_no_aceptado,a.valor_pendiente,c.nombre,
       b.fecha_registro AS fecha_registro_respuesta,
       b.usuario_id,b.observacion
FROM
     glosas AS a, 
     glosas_respuestas AS b, 
     system_usuarios AS c

WHERE
 a.glosa_id=b.glosa_id AND b.usuario_id=c.usuario_id AND b.fecha_registro between _1 AND _2