select e.bodega, e.codigo_producto, c.descripcion, e. cantidad, e.fecha_vencimiento, e.lote
from  existencias_despachos_no_confirmados e, inventarios_productos c
where e.codigo_producto = c.codigo_producto;