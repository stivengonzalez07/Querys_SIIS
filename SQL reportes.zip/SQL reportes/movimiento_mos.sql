SELECT  cd.numerodecuenta,
CASE WHEN c.estado = '0' THEN 'FACTURADA'
     WHEN c.estado = '1' THEN 'ACTIVA'
     WHEN c.estado = '2' THEN 'INACTIVA'
     WHEN c.estado = '3' THEN 'CUADRADA'
	 ELSE 'ANULADA' END AS estado_cta,
c.ingreso,
g.fecha_ingreso,
g.tipo_id_paciente||' '||g.paciente_id as identificacion_paciente,
pac.primer_nombre||' '||pac.segundo_nombre||' '||pac.primer_apellido||' '||pac.segundo_apellido as paciente,
cd.departamento,
d.descripcion,
cd.cargo,
cd.cantidad,
cd.precio,
cd.valor_cargo,
ip.codigo_producto,
ip.descripcion,
cd.fecha_cargo AS fecha_cargo_producto,
p.plan_descripcion,
ff.prefijo,
ff.factura_fiscal,
CASE WHEN ff.estado = '0' THEN 'ACTIVA'
     WHEN c.estado = '1' THEN 'PAGADA'
	 ELSE 'ANULADA' END AS estado_factura
FROM 
 cuentas_detalle cd
INNER JOIN  bodegas_documentos_d bd ON (cd.consecutivo=bd.consecutivo)
INNER JOIN  cuentas c ON (cd.numerodecuenta=c.numerodecuenta)
INNER JOIN  inventarios_productos ip ON (bd.codigo_producto=ip.codigo_producto)
INNER JOIN  departamentos d ON (cd.departamento=d.departamento)
INNER JOIN  ingresos g ON (c.ingreso = g.ingreso)
INNER JOIN  planes p ON (c.plan_id=p.plan_id)
INNER JOIN  pacientes pac ON (pac.tipo_id_paciente = g.tipo_id_paciente AND pac.paciente_id = g.paciente_id)
LEFT JOIN   fac_facturas_cuentas fc ON (c.numerodecuenta=fc.numerodecuenta)
LEFT JOIN   fac_facturas ff ON (fc.prefijo=ff.prefijo AND fc.factura_fiscal=ff.factura_fiscal) 
WHERE c.estado!= '5' 
AND ip.grupo_id IN ('03','13')
AND cd.fecha_cargo::date BETWEEN _1 AND _2
ORDER BY c.ingreso
