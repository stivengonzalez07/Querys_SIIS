select 
to_char(hnoc.fecha_registro, 'YYYY-MM-DD') as fecha_cirugia,
age(hnoc.hora_fin,hnoc.hora_inicio)  as duracion_cirugia,
case when qp.estado='1' then 'ACTIVA' when qp.estado='2' then 'LIQUIDADA' else 'CANCELADA' end as estado_cirugia,
qx.descripcion as quirofano,
pl.plan_descripcion AS plan,
ing.tipo_id_paciente,
ing.paciente_id,
pac.primer_nombre||' '||pac.segundo_nombre||' '||pac.primer_apellido||' '||pac.segundo_apellido as paciente,
((now()::date-pac.fecha_nacimiento::date)/365) AS edad_en_anos,
pac.residencia_telefono as Telefono,
(select mp.municipio from tipo_mpios as mp where mp.tipo_pais_id=pac.tipo_pais_id and mp.tipo_dpto_id=pac.tipo_dpto_id and mp.tipo_mpio_id=pac.tipo_mpio_id) as Regional,
(select reg.regimen_descripcion from tipos_cliente as tpcl, regimenes as reg where cta.plan_id=pl.plan_id and pl.tipo_cliente=tpcl.tipo_cliente and tpcl.regimen_id=reg.regimen_id and pl.tercero_id='817000248'),
cu.cargo AS codigo_cups ,cu.descripcion as procedimiento,
pro.nombre as Cirujano,
esp.descripcion as especialidad,
(select pro.nombre from profesionales as pro where pro.tercero_id = hnoc.anestesiologo_id) as Anestesiologo,
(select ta.descripcion from qx_tipos_anestesia as ta where ta.qx_tipo_anestesia_id=hnoc.qx_tipo_anestesia_id ) as Tipo_Anestesia,
(select pro.nombre from profesionales as pro where pro.tercero_id = hnoc.ayudante_id) as Ayudante,
(select pro.nombre from profesionales as pro where pro.tercero_id = hnoc.instrumentista_id) as Instrumentista,
(select pro.nombre from profesionales as pro where pro.tercero_id = hnoc.circulante_id) as Circulante,
hnoc.hora_inicio,
hnoc.hora_fin,
qac.descripcion as ambito,
CASE WHEN hnoc.sw_urg_prog='0' THEN 'SI' ELSE 'NO' END AS Programada,
CASE WHEN hnoc.sw_urg_prog='1' THEN 'SI' ELSE 'NO' END AS Urgencia,
CASE WHEN hnoc.envio_patologico='1' THEN 'SI' ELSE 'NO' END AS Patologia,
CASE WHEN hnoc.envio_cultivo='1' THEN 'SI' ELSE 'NO' END AS Cultivo,
(select qtp.descripcion from qx_tipos_cirugia as qtp where qtp.tipo_cirugia_id=hnoc.tipo_cirugia) as Observacion,
(select hctom.descripcion from hc_ordenes_medicas as hcom, hc_tipos_ordenes_medicas as hctom where hcom.ingreso=ing.ingreso and hcom.evolucion_id>hnoc.evolucion_id
and hcom.hc_tipo_orden_medica_id=hctom.hc_tipo_orden_medica_id  limit 1) as Estacion_Destino,
epi.numerodecuenta
INTO
temporary reportedecirugia
from hc_notas_operatorias_cirugias as hnoc
inner join hc_notas_operatorias_procedimientos as hcnop ON hcnop.hc_nota_operatoria_cirugia_id = hnoc.hc_nota_operatoria_cirugia_id
left join qx_programaciones as qp ON qp.programacion_id = hnoc.programacion_id
left join qx_quirofanos_programacion as qqp ON qqp.programacion_id = qp.programacion_id
left join cuentas_liquidaciones_qx as clq ON clq.programacion_id = qp.programacion_id
left join qx_quirofanos as qx ON qx.quirofano = qqp.quirofano_id
left join acto_quirurgico as aq ON aq.acto_quiru = hnoc.acto_quiru
left join ingresos as ing ON ing.ingreso = aq.ingreso
left join cuentas as cta ON cta.ingreso = ing.ingreso
left join estacion_enfermeria_qx_pacientes_ingresados as epi ON epi.numerodecuenta = cta.numerodecuenta
inner join planes as pl ON pl.plan_id = cta.plan_id and pl.tercero_id='817000248'
left join pacientes as pac ON pac.tipo_id_paciente = qp.tipo_id_paciente AND pac.paciente_id = qp.paciente_id
left join cups as cu ON cu.cargo = hcnop.procedimiento_qx
left join qx_ambitos_cirugias as qac ON qac.ambito_cirugia_id = hnoc.ambito_cirugia
left join profesionales as pro ON pro.tercero_id = hnoc.cirujano_id
left join profesionales_especialidades as pe ON pe.tercero_id = pro.tercero_id
left join especialidades as esp ON esp.especialidad = pe.especialidad
where hnoc.fecha_registro::date  between _1::date AND _2::date AND qqp.qx_tipo_reserva_quirofano_id='3'
group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31
order by 1,4,3,5;

select *,(select c.descripcion as estacion_procedencia from estacion_enfermeria_qx_pacientes_ingresados b, estaciones_enfermeria c where
a.numerodecuenta=b.numerodecuenta and b.estacion_origen = c.estacion_id limit 1) from reportedecirugia as a where a.numerodecuenta is NOT NULL;