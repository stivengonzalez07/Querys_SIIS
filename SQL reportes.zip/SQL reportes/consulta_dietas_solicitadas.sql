SELECT ds.fecha_solicitud, ee.descripcion AS servicio, dts.descripcion_solicitud
FROM
dietas_solicitud ds
INNER JOIN dietas_tipos_solicitud dts ON ds.tipo_solicitud_dieta_id=dts.tipo_solicitud_dieta_id
INNER JOIN estaciones_enfermeria ee ON ds.estacion_id=ee.estacion_id
WHERE ds.fecha_confirmacion IS NOT NULL
AND fecha_solicitud BETWEEN _1 AND _2