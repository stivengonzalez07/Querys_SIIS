SELECT	ff.prefijo,
		ff.factura_fiscal,
		p.tipo_id_paciente,
		p.paciente_id,
		p.primer_nombre,
		p.segundo_nombre,
		p.primer_apellido,
		p.segundo_apellido,
		cu.cargo,
		cu.descripcion as nombre_cargo,
		cd.valor_cargo
FROM
		cuentas c INNER JOIN cuentas_detalle cd ON c.numerodecuenta = cd.numerodecuenta
      	INNER JOIN planes pl ON c.plan_id = pl.plan_id
      	INNER JOIN fac_facturas_cuentas ffc ON c.numerodecuenta = ffc.numerodecuenta
      	INNER JOIN fac_facturas ff ON ff.prefijo = ffc.prefijo AND ff.factura_fiscal = ffc.factura_fiscal
      	INNER JOIN cups cu ON cd.cargo_cups = cu.cargo
      	INNER JOIN ingresos i ON c.ingreso = i.ingreso
      	INNER JOIN pacientes p ON i.tipo_id_paciente = p.tipo_id_paciente AND i.paciente_id = p.paciente_id
      	INNER JOIN grupos_tipos_cargo gt ON cu.grupo_tipo_cargo = gt.grupo_tipo_cargo
      	INNER JOIN departamentos DE 
		INNER JOIN unidades_funcionales UF ON DE.centro_utilidad = UF.centro_utilidad 
		and DE.unidad_funcional = UF.unidad_funcional AND UF.empresa_id = DE.empresa_id
        ON DE.departamento = cd.departamento
WHERE	c.empresa_id like '01'
AND 	ff.estado NOT IN ('2','3')
AND 	ff.fecha_registro::date BETWEEN _1 AND _2 
order by ff.factura_fiscal