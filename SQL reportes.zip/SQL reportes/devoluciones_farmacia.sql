--DEVOLUCIONES ACEPTADAS DE ALMACEN
SELECT
invd.bodega,invd.fecha_registro, invd.documento, p.tipo_id_paciente||' '||p.paciente_id AS id_paciente, p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido, ip.codigo_producto AS nombre_paciente, ip.descripcion AS producto,
CASE WHEN m.sw_pos='1' THEN 'POS'  WHEN m.sw_pos='0' THEN 'NO POS'  ELSE 'NA' END AS sw_pos,
CASE WHEN m.sw_uso_controlado='1' THEN 'USO CONTROLADO'
ELSE 'NO CONTROLADO' END AS med_control
, round(invdd.cantidad,0), invd.observacion, md.descripcion as motivo_devolucion, invdd.estacion_id AS area, enf.descripcion
FROM
inv_solicitudes_devolucion invd
INNER JOIN inv_solicitudes_devolucion_d invdd ON invd.documento=invdd.documento
INNER JOIN estaciones_enfermeria enf ON invd.estacion_id=enf.estacion_id
INNER JOIN estacion_enfermeria_parametros_devolucion md ON invd.parametro_devolucion_id=md.parametro_devolucion_id
INNER JOIN inventarios_productos ip ON invdd.codigo_producto=ip.codigo_producto
LEFT OUTER JOIN medicamentos m ON invdd.codigo_producto=m.codigo_medicamento
INNER JOIN ingresos i ON invd.ingreso=i.ingreso
INNER JOIN pacientes p ON i.paciente_id=p.paciente_id

WHERE
invd.estado='1'
AND
invd.fecha BETWEEN _1 AND _2