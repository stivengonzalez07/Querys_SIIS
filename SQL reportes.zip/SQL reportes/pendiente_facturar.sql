SELECT  c.numerodecuenta AS Cuenta,
        CASE WHEN c.estado = '1' THEN 'ACTIVA'
WHEN c.estado = '2' THEN 'INACTIVA'
WHEN c.estado = '3' THEN 'CUADRADA' END,

        i.ingreso AS ingreso,
        i.tipo_id_paciente AS Tipo_Documento_paciente,
        i.paciente_id AS Documento_paciente,
        c.plan_id,
	 p.plan_descripcion,
        CASE WHEN ip.codigo_producto IS NULL THEN '' ELSE ip.codigo_producto END,
        CASE WHEN ip.descripcion IS NULL THEN '' ELSE ip.descripcion END,
        CASE WHEN m.codigo_cum IS NULL THEN '' ELSE m.codigo_cum END,
        CASE WHEN cp.cargo IS NULL THEN '' ELSE cp.cargo END AS cargo_cups,
        CASE WHEN cp.descripcion IS NULL THEN '' ELSE cp.descripcion END Descripcion_cargo,
        --CASE WHEN cd.cargo = 'DIMD' THEN cd.cantidad - cd.cantidad*2 ELSE cd.cantidad END AS Cantidad_insumo_cargo,
        cd.departamento AS Departamento,
        cd.cantidad,
        cd.precio AS Valor_unitario,                                                                                                                                                                                              
        cd.valor_cargo AS Valor_Total,
        cd.fecha_cargo,
        cd.fecha_registro

FROM cuentas c

INNER JOIN planes p ON p.plan_id = c.plan_id
INNER JOIN ingresos i ON c.ingreso = i.ingreso
INNER JOIN cuentas_detalle cd ON c.numerodecuenta = cd.numerodecuenta
LEFT JOIN bodegas_documentos_d bdd ON cd.consecutivo = bdd.consecutivo
LEFT JOIN inventarios_productos ip ON bdd.codigo_producto = ip.codigo_producto
LEFT JOIN cups cp ON cd.cargo_cups = cp.cargo
LEFT JOIN medicamentos m ON bdd.codigo_producto = m.codigo_medicamento

WHERE c.fecha_registro BETWEEN _1 AND _2 
AND c.estado NOT IN ('0','5')
AND (cp.sw_pos = '0' OR m.sw_pos = '0')
