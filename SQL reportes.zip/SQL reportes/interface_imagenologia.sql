SELECT o.pid_id as identificacion, 
o.pid_first_name as Nombres_paciente, 
o.pid_last_name as Apellidos_paciente, 
o.obr_procedure_start_date as fecha_solicitud, 
o.obr_procedure_code as codigo_examen, 
o.obr_exam_reason as descripcion_procedimiento, 
b.fecha_solicitud as fecha_solicitud_medico,
i.departamento, i.ingreso, rd.obr_results_date as fecha_resultado
FROM ingresos i,
interface_imagenes.order_request o
LEFT JOIN interface_imagenes.report_data rd ON (o.orc_order_id = rd.orc_order_id)
INNER JOIN os_maestro a ON (a.numero_orden_id = CAST(o.orc_order_id as INT))
INNER JOIN hc_os_solicitudes b ON (a.hc_os_solicitud_id = b.hc_os_solicitud_id)
WHERE i.ingreso = CAST(o.pv1_visit_id as INT)
AND o.obr_procedure_start_date::date BETWEEN _1 AND _2
ORDER BY 4

