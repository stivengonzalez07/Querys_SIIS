SELECT
			a.quirofano,
			hora_inicio as hora_inicio,
			b.primer_nombre||' '||b.segundo_nombre||' '||b.primer_apellido||' '||b.segundo_apellido as paciente,
			cu.numerodecuenta,
			d.descripcion as cargo_descripcion,
			ter.nombre_tercero as cirujano,
			c.plan_descripcion,
			a.programacion_id,
			a.fecha_registro,
			a.observaciones
		FROM
		ingresos i,
        cuentas cu,
		(
			SELECT 
				a.departamento,
				a.programacion_id,
				a.tipo_id_paciente,
				a.paciente_id,
				c.hora_inicio,
				c.hora_fin,
				c.quirofano_id,
				d.descripcion as quirofano,
				b.tipo_id_cirujano,
				b.cirujano_id,
				b.procedimiento_qx as cargo,
				b.plan_id,
				a.fecha_registro,
                    b.observaciones
			FROM 
				qx_programaciones a,
				qx_procedimientos_programacion b,
				qx_quirofanos_programacion c,
				qx_quirofanos d
			
			WHERE 
				a.programacion_id = c.programacion_id 
				AND a.programacion_id = b.programacion_id 
				AND c.quirofano_id=d.quirofano 
				AND c.qx_tipo_reserva_quirofano_id='3'
		) as a
		
		
		
        LEFT JOIN terceros ter 
            ON (a.cirujano_id=ter.tercero_id AND a.tipo_id_cirujano=ter.tipo_id_tercero),
                pacientes b,
                planes c,
                cups d,
                departamentos e
		WHERE
			a.tipo_id_paciente=b.tipo_id_paciente 
			AND a.paciente_id=b.paciente_id 
			AND a.plan_id=c.plan_id
			AND a.cargo = d.cargo
			AND e.departamento = a.departamento
			AND e.empresa_id='01'
			AND i.tipo_id_paciente=a.tipo_id_paciente
			AND i.paciente_id=a.paciente_id
			AND cu.ingreso=i.ingreso
			AND date(a.hora_inicio) >= _1
			AND date(a.hora_inicio) <= _2
		ORDER BY
			e.departamento,
			a.quirofano_id,
			a.hora_inicio,
			a.programacion_id,
			cirujano
     