SELECT 
p.tipo_id_paciente, 
p.paciente_id, 
p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS Nombre,
p.residencia_direccion,
p.residencia_telefono,
p.tipo_pais_id,
tp.pais,
p.tipo_dpto_id,
td.departamento,
p.tipo_mpio_id,
tm.municipio,
'N/A' As email
FROM tipo_pais tp
INNER JOIN tipo_dptos td ON (td.tipo_pais_id=tp.tipo_pais_id)
INNER JOIN tipo_mpios tm ON (tm.tipo_dpto_id=td.tipo_dpto_id AND tm.tipo_pais_id=tp.tipo_pais_id)
INNER JOIN pacientes p ON(p.tipo_mpio_id=tm.tipo_mpio_id AND p.tipo_dpto_id=td.tipo_dpto_id AND p.tipo_pais_id=tp.tipo_pais_id)
WHERE
p.fecha_registro BETWEEN _1 AND _2
UNION ALL 
SELECT 
t.tipo_id_tercero,
t.tercero_id,
t.nombre_tercero,
t.direccion,
t.telefono,
t.tipo_pais_id,
tp.pais,
t.tipo_dpto_id,
td.departamento,
t.tipo_mpio_id,
tm.municipio,
t.email
FROM tipo_pais tp
INNER JOIN tipo_dptos td ON (td.tipo_pais_id=tp.tipo_pais_id)
INNER JOIN tipo_mpios tm ON (tm.tipo_dpto_id=td.tipo_dpto_id AND tm.tipo_pais_id=tp.tipo_pais_id)
INNER JOIN terceros t ON(t.tipo_mpio_id=tm.tipo_mpio_id AND t.tipo_dpto_id=td.tipo_dpto_id AND t.tipo_pais_id=tp.tipo_pais_id)
WHERE
t.fecha_registro BETWEEN _1 AND _2
