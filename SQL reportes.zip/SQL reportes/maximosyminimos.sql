SELECT
e.bodega AS Bodega_id,
bo.descripcion AS Bodega, 
ip.codigo_producto,
ip.descripcion AS Producto,
u.descripcion AS unidad,
ip.codigo_invima,
ip.codigo_cum,
ip.codigo_atc,
ip.contenido_unidad_venta AS unidad_venta,
COALESCE(i.costo,0) AS costo,
COALESCE(e.existencia,0) AS existencia_producto,
em.empresa_id,
em.razon_social,
e.existencia_minima,
e.existencia_maxima,
lfv.existencia_actual as Existencia_Lote,
lfv.fecha_vencimiento,
lfv.lote

FROM

inventarios_productos ip, inventarios i, empresas em, 
existencias_bodegas e, bodegas bo, unidades u, existencias_bodegas_lote_fv lfv

where  ip.codigo_producto=i.codigo_producto
and em.empresa_id=i.empresa_id and i.codigo_producto=e.codigo_producto and
e.bodega=bo.bodega and ip.unidad_id=u.unidad_id 
and e.codigo_producto=lfv.codigo_producto and e.bodega=lfv.bodega

ORDER BY bo.descripcion,ip.descripcion,lfv.existencia_actual