SELECT 
i.ingreso,
c.numerodecuenta,
(p.primer_apellido||' '|| p.segundo_apellido||' '|| p.primer_nombre|| ' ' ||p.segundo_nombre) AS Nombre_paciente,
p.tipo_id_paciente,
p.paciente_id,
p.fecha_nacimiento,
pl.plan_descripcion,
i.departamento as Departamento_ingreso,
i.departamento_actual,	
i.fecha_ingreso,
s.fecha_registro AS Fecha_de_egreso,
i.estado

FROM
pacientes p
INNER JOIN ingresos i on (p.paciente_id=i.paciente_id and p.tipo_id_paciente=i.tipo_id_paciente)
INNER JOIN cuentas c on (c.ingreso=i.ingreso)
INNER JOIN planes pl on (pl.plan_id=c.plan_id)
INNER JOIN ingresos_salidas s on (s.ingreso=i.ingreso)
WHERE
i.departamento_actual in ('HOS003','HO004','HOS005','HOS006','HOS007')
AND i.fecha_ingreso::date BETWEEN _1 AND _2
--AND i.fecha_ingreso BETWEEN '2021-01-01' AND '2021-02-15';

