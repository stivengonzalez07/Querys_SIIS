SELECT a.bodega,
e.descripcion as departamento,
c.inv_tipo_movimiento,
a.documento_id,
b.descripcion,
a.prefijo,
a.numero,
a.observacion,
a.sw_estado,
a.usuario_id,
a.fecha_registro,
a.total_costo

FROM inv_bodegas_movimiento as a inner join documentos as b on a.documento_id=b.documento_id and a.prefijo=b.prefijo
                                      inner join tipos_doc_generales as c on b.tipo_doc_general_id=c.tipo_doc_general_id
                                      inner join inv_bodegas_movimiento_consumo as d on a.prefijo=d.prefijo and a.numero=d.numero
                                      inner join departamentos as e on d.departamento=e.departamento

WHERE a.fecha_registro::date >= _1
AND   a.fecha_registro::date <= _2
ORDER BY 1,2