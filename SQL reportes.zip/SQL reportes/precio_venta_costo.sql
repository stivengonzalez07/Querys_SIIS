select
   ip.codigo_producto,
   ip.descripcion as producto,
   ip.codigo_invima,
   ip.titular_reginvima_id,
   ip.codigo_atc,
   m.codigo_cum,
   if.descripcion as fabricante,
   sc.subclase_id,
   sc.descripcion as subclase,
   c.clase_id,
   c.descripcion as clase,
   g.grupo_id,
   g.descripcion as grupo,
   i.costo,
   i.precio_venta,
   i.costo_anterior,
   i.costo_ultima_compra 
from
   inv_grupos_inventarios g 
   join
      inv_clases_inventarios c 
      ON (c.grupo_id = g.grupo_id) 
   join
      inv_subclases_inventarios sc 
      ON (c.clase_id = sc.clase_id 
      and sc.grupo_id = c.grupo_id) 
   join
      inventarios_productos ip 
      ON (ip.subclase_id = sc.subclase_id 
      and ip.clase_id = sc.clase_id 
      and ip.grupo_id = sc.grupo_id) 
   left join
      inventarios i 
      ON(ip.codigo_producto = i.codigo_producto) 
   left join
      medicamentos m 
      ON (ip.codigo_producto = m.codigo_medicamento) 
   INNER JOIN
      inv_fabricantes if 
      ON (if.fabricante_id = ip.fabricante_id)

