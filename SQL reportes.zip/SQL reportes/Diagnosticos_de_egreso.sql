SELECT
c.numerodecuenta,
i.ingreso,
i.fecha_ingreso,
dp.descripcion as departamento,
i.tipo_id_paciente,i.paciente_id,
de.tipo_diagnostico_id as diagnostico,
d.diagnostico_nombre as descripcion,
FROM hc_diagnosticos_egreso de,diagnosticos d, hc_evoluciones e,departamentos dp,ingresos i, cuentas c
WHERE dp.departamento=e.departamento
AND   i.ingreso=c.ingreso
AND   de.tipo_diagnostico_id=d.diagnostico_id
AND   de.evolucion_id=e.evolucion_id
AND   i.ingreso=e.ingreso
AND i.estado <>'5'
AND i.fecha_ingreso::date>=_1
AND i.fecha_ingreso::date<=_2
ORDER BY 1,2

