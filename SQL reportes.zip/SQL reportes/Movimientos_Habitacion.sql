SELECT mh.numerodecuenta,
i.fecha_ingreso,
i.ingreso,
p.tipo_id_paciente||' '||p.paciente_id AS identificacion_pacte,
p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS paciente,
mh.cama,
TO_CHAR (mh.fecha_ingreso, 'YYYY-MM-DD') AS fecha_ingreso_cama,
TO_CHAR (mh.fecha_ingreso, 'HH24:MI:SS') AS hora_ingreso_cama,
TO_CHAR (mh.fecha_egreso, 'YYYY-MM-DD') AS fecha_egreso_cama,
TO_CHAR (mh.fecha_egreso, 'HH24:MI:SS') AS hora_egreso_cama,
ee.descripcion AS estacion_enfermeria,
pl.plan_descripcion,
mh.cargo as cups,
cu.descripcion
FROM movimientos_habitacion mh
INNER JOIN ingresos i ON (i.ingreso=mh.ingreso)
INNER JOIN pacientes p ON (i.tipo_id_paciente=p.tipo_id_paciente AND i.paciente_id=p.paciente_id)
INNER JOIN estaciones_enfermeria ee ON (mh.estacion_id=ee.estacion_id)
INNER JOIN cuentas ct ON (mh.numerodecuenta=ct.numerodecuenta)
INNER JOIN planes pl ON (ct.plan_id=pl.plan_id)
INNER JOIN cups cu ON (mh.cargo=cu.cargo)
WHERE mh.fecha_ingreso::date BETWEEN _1 AND _2

