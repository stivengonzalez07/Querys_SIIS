SELECT 	ffc.factura_fiscal,
        cd.numerodecuenta as cuenta,
        e.descripcion as estado_cuenta,
        d.descripcion as departamento,
        p.plan_descripcion as entidad,
        cd.cargo_cups,
        cd.cargo,
        cd.cantidad,
        cd.precio,
        cd.fecha_cargo
        
FROM    cuentas_detalle cd,
        fac_facturas_cuentas ffc,
        cuentas c,
        planes p,
        departamentos d,
        cuentas_estados e

WHERE   cd.numerodecuenta = ffc.numerodecuenta
AND     cd.numerodecuenta = c.numerodecuenta
AND     cd.departamento = d.departamento
AND     c.estado = e.estado
AND     c.plan_id = p.plan_id
AND     c.estado = '0'
AND     cd.facturado = '1'
AND     ffc.sw_tipo IN ('1', '2')
AND     cd.cargo_cups IN ('891401', '861411' ,'895100' ,'991201' , '893910' ,'901407' ,'954103' ,'954107' ,'954301','860201' ,'954302')
AND     cd.fecha_cargo::date >= _1
AND     cd.fecha_cargo::date <= _2
ORDER BY cd.cargo_cups