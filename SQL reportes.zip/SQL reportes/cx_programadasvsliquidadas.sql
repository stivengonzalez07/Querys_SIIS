select 
plan_descripcion,
(to_char(hora_inicio,'yyyy-mm-dd')) as fecha_cirugia,
pac.tipo_id_paciente,
pac.paciente_id,
(pac.primer_nombre||' '||pac.segundo_nombre||' '||pac.primer_apellido||' '||pac.segundo_apellido) as paciente,
esp.descripcion as especialidad,
ter.nombre_tercero as profesional,
cu.descripcion as procedimiento_programado,
case when clq.estado = '0' then 'NO LIQUIDADA' when clq.estado = '1' then 'LIQUIDADA' when clq.estado = '2' then 'FACTURADA' WHEN clq.estado is null then 'NO HAY PROCESO DE LIQUIDACION DE CIRUGIA' else 'CANCELADA O CARGADA MANUALMENTE' end as estado_liquidacion,
(select cu1.descripcion from cups as cu1 where clqp.cargo_cups = cu1.cargo and clqp.cuenta_liquidacion_qx_id = clq.cuenta_liquidacion_qx_id) as cargo_liquidado,
case when ffc.prefijo = 'C' then 'CONTADO' when ffc.prefijo is null then 'NO HAY PROCESO DE LIQUIDACION DE CIRUGIA o SIN FACTURA' else 'CREDITO' end as tipo_factura,
ffc.factura_fiscal as Numero_Factura
from qx_programaciones as qp
inner join qx_quirofanos_programacion as qqp ON qqp.programacion_id = qp.programacion_id
inner join pacientes as pac ON pac.tipo_id_paciente = qp.tipo_id_paciente and pac.paciente_id = qp.paciente_id
inner join planes as pl ON pl.plan_id = qp.plan_id
inner join terceros as ter ON ter.tipo_id_tercero = qp.tipo_id_cirujano and ter.tercero_id = qp.cirujano_id
inner join profesionales as pro ON pro.tipo_id_tercero = ter.tipo_id_tercero and pro.tercero_id = ter.tercero_id
inner join profesionales_especialidades as pe ON pe.tipo_id_tercero = pro.tipo_id_tercero and pe.tercero_id = pro.tercero_id
inner join especialidades as esp On esp.especialidad = pe.especialidad
left join qx_procedimientos_programacion as qpp ON qpp.programacion_id = qp.programacion_id
left join cups as cu ON cu.cargo = qpp.procedimiento_qx
left join cuentas_liquidaciones_qx as clq ON clq.programacion_id = qp.programacion_id
left join cuentas_liquidaciones_qx_procedimientos as clqp ON clqp.cuenta_liquidacion_qx_id = clq.cuenta_liquidacion_qx_id
left join fac_facturas_cuentas as ffc ON ffc.numerodecuenta = clq.numerodecuenta
where 
qqp.qx_tipo_reserva_quirofano_id <> 0
and hora_inicio between _1 and _2
order by 1,2