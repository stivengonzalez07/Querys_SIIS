select a.ingreso,
a.tipo_id_paciente,
a.paciente_id,concat
(f.primer_apellido,' ',f.segundo_apellido,' ',f.primer_nombre,' ',f.segundo_nombre) as Nombre_Completo,
a.fecha_ingreso,
c.via_ingreso_nombre,
b.fecha_cierre as Fecha_cierre_evolucion,
d.descripcion as departamento_egreso,
hc.descripcion
from pacientes f 
inner join ingresos a on(a.tipo_id_paciente=f.tipo_id_paciente and a.paciente_id=f.paciente_id) 
inner join hc_evoluciones b on (b.ingreso=a.ingreso) 
inner join vias_ingreso c on (a.via_ingreso_id=c.via_ingreso_id) 
inner join historias_clinicas_tipos_cierres hc on(hc.historia_clinica_tipo_cierre_id=b.historia_clinica_tipo_cierre_id)
join departamentos d on(b.departamento=d.departamento)
where hc.historia_clinica_tipo_cierre_id=8
and a.fecha_registro::date BETWEEN _1 AND _2 order by a.ingreso,a.fecha_registro asc

