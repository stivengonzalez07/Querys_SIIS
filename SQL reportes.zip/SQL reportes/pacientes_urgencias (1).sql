SELECT      	DISTINCT i.ingreso,
					i.paciente_id,
					to_char(i.fecha_ingreso, 'DD-MM-YYYY') as  fecha_ingreso,
					to_char(i.fecha_ingreso,'HH24:MI:SS') as hora,
					p.primer_nombre,
					p.segundo_nombre,
					p.primer_apellido,
					p.segundo_apellido,
					pr.nombre as medico
FROM          	ingresos i
					JOIN (	SELECT	MIN(a.evolucion_id) as evolucion_id,
                          a.ingreso
								FROM		hc_evoluciones a,
												profesionales b
								WHERE	a.usuario_id = b.usuario_id
								AND			b.tipo_profesional IN ('1', '2')
								GROUP BY a.ingreso
							)	as	hc
					ON 	(hc.ingreso = i.ingreso),
					pacientes p,
          hc_evoluciones he,
          profesionales pr
WHERE     i.paciente_id = p.paciente_id
AND       i.tipo_id_paciente = p.tipo_id_paciente
AND       i.via_ingreso_id = '1'
AND				i.departamento = 'URGENC'
AND				i.fecha_ingreso::date >= _1
AND 			i.fecha_ingreso::date <= _2
AND       he.evolucion_id = hc.evolucion_id
AND       pr.usuario_id = he.usuario_id