SELECT eg.envio_id, 
CASE WHEN eg.sw_estado= '0' THEN 'SIN RADICAR'
     WHEN eg.sw_estado='1' THEN 'RADICADO'
     WHEN eg.sw_estado= '2' THEN 'ANULADO'
     END AS estado_envio_glosa,
gc.descripcion_concepto_general||' / '|| gce.descripcion_concepto_especifico AS C_general_especifico,
gr.respuesta_numero, gr.valor_aceptado,
egd.prefijo, 
egd.factura_fiscal, 
--p.plan_descripcion,
t.nombre_tercero,
to_char(eg.fecha_registro, 'dd/mm/YYYY') as fecha_envio,
        to_char(eg.fecha_registro, 'hh:mi:ss' ) as hora_envio,
reg.fecha_radicacion, 
g.fecha_glosa,
egd.glosa_id,
egd.valor
FROM envios_glosas eg
INNER JOIN envios_glosas_detalle egd ON (eg.envio_id = egd.envio_id)
INNER JOIN glosas g ON (g.glosa_id = egd.glosa_id)
INNER JOIN glosas_respuestas gr ON g.glosa_id=gr.glosa_id
LEFT JOIN glosas_concepto_general gc ON g.codigo_concepto_general=gc.codigo_concepto_general
LEFT JOIN glosas_concepto_especifico gce ON g.codigo_concepto_especifico=gce.codigo_concepto_especifico
LEFT JOIN radicacion_envios_glosas reg ON (eg.envio_id = reg.envio_id)
INNER JOIN fac_facturas f ON (g.factura_fiscal = f.factura_fiscal AND g.prefijo = f.prefijo)
INNER JOIN planes p ON (f.plan_id = p.plan_id)
INNER JOIN terceros t ON t.tercero_id=p.tercero_id AND t.tipo_id_tercero=p.tipo_tercero_id
WHERE eg.fecha_final BETWEEN _1 AND _2
ORDER BY eg.envio_id, egd.factura_fiscal, gr.respuesta_numero