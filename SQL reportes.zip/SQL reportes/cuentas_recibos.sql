SELECT c.prefijo,
       c.recibo_caja,
       c.numerodecuenta,
       e.descripcion as estado,
	   s.nombre,
       a.total_abono,
	   a.fecha_ingcaja,
       a.tipo_id_tercero,
       a.tercero_id,
       b.nombre_tercero
       
FROM recibos_caja a, 
     terceros b,
     rc_detalle_hosp c,
     cuentas d,
     cuentas_estados e,
	 system_usuarios s

WHERE a.tercero_id = b.tercero_id 
AND   a.recibo_caja = c.recibo_caja
AND   c.numerodecuenta = d.numerodecuenta
AND   d.usuario_id = s.usuario_id
AND   d.estado = e.estado
AND   a.estado = '0'
AND   NOT (d.estado ='0')
AND   a.fecha_ingcaja::date >= _1
AND   a.fecha_ingcaja::date <= _2
ORDER BY a.fecha_ingcaja