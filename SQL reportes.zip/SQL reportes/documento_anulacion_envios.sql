SELECT DISTINCT AE.prefijo,
		AE.numero,
		AE.envio_id as numero_envio,
		
      AE.fecha_registro as fecha_documento, 
      ED.prefijo,
	  ED.factura_fiscal,
      FF.tipo_id_tercero, 
      FF.tercero_id 
      
      FROM   public.anulacion_envios AE,  
      public.anulacion_envios_detalle ED,
      public.fac_facturas FF
     
      WHERE  AE.empresa_id = '01' 
	  AND    AE.prefijo is not null
      AND    AE.anulacion_envio_id = ED.anulacion_envio_id 
      AND    ED.empresa_id = FF.empresa_id 
      AND    ED.prefijo = FF.prefijo 
      AND    ED.factura_fiscal = FF.factura_fiscal 
	  AND AE.fecha_registro::date BETWEEN _1 AND _2
group by 1,2,3,4,5,6,7,8
order by 1,2