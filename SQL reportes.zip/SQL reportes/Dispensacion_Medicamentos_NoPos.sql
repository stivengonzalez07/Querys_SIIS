SELECT 
--hmd.ingreso,
CASE WHEN hm.sw_estado='1' THEN 'DESPACHADA'
     WHEN hm.sw_estado= '2' THEN 'RECIBIDA'
     ELSE 'REVISAR'
     END AS estado_solicitud,
pa.tipo_id_paciente,
pa.paciente_id, 
pa.primer_nombre ||' '|| pa.segundo_nombre ||' '|| pa.primer_apellido ||' '|| pa.segundo_apellido as nombre_paciente,
hmd.medicamento_id as cod_producto,
ip.descripcion as desc_producto,
hm.fecha_solicitud,
SUM(hmd.cant_solicitada) as cantidad_solicitada,
SUM(bdd.cantidad) as cantidad_despachada,
bd.fecha_registro as fecha_despacho,
hm.usuario_id as asistencial,
pr.nombre as nombre_asistencial,
bd.usuario_id as aux_farmacia,
su.nombre as nombre_farmarcia

FROM hc_solicitudes_medicamentos_d hmd
INNER JOIN hc_solicitudes_medicamentos hm ON hmd.solicitud_id=hm.solicitud_id
INNER JOIN inventarios_productos ip ON hmd.medicamento_id=ip.codigo_producto
LEFT JOIN medicamentos med ON hmd.medicamento_id=med.codigo_medicamento
INNER JOIN estaciones_enfermeria ee ON hm.estacion_id=ee.estacion_id
INNER JOIN ingresos i ON hmd.ingreso=i.ingreso
INNER JOIN pacientes pa ON i.tipo_id_paciente=pa.tipo_id_paciente AND i.paciente_id=pa.paciente_id
INNER JOIN bodegas_documento_despacho_med_d bdd ON hmd.consecutivo_d=bdd.consecutivo_solicitud
INNER JOIN bodegas_documento_despacho_med bd ON bdd.documento_despacho_id = bd.documento_despacho_id	
LEFT JOIN profesionales pr ON hm.usuario_id=pr.usuario_id
LEFT JOIN system_usuarios su ON bd.usuario_id=su.usuario_id

WHERE
bd.fecha_registro::DATE BETWEEN _1 AND _2
--i.fecha_ingreso::DATE BETWEEN '2021-08-01' AND '2021-08-15' --antes estaba por ingreso del paciente.
AND med.sw_pos = '0'

GROUP BY  estado_solicitud, pa.tipo_id_paciente, pa.paciente_id, hmd.medicamento_id, ip.descripcion, hm.fecha_solicitud,bd.fecha_registro,
hm.usuario_id, bd.usuario_id, pr.nombre,su.nombre