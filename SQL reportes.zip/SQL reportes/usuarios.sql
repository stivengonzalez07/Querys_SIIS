select s.usuario_id,
s.usuario,
s.nombre,
case when s.activo='1' then 'Activo' else 'Retirado' end as estado,
p.descripcion as perfil
from system_usuarios s
inner join system_usuarios_perfiles sp on (s.usuario_id=sp.usuario_id)	
inner join system_perfiles p on (p.perfil_id=sp.perfil_id)	
order by s.usuario_id