SELECT  i.ingreso,
to_char(i.fecha_ingreso, 'yyyy-mm-dd') as fecha_ingreso,
d.descripcion as depto_ingreso,
e.descripcion as depto_actual,
p.tipo_id_paciente||' '||p.paciente_id as tipo_id_paciente,
p.primer_apellido||' '||p.segundo_apellido||' '||p.primer_nombre||' '||p.segundo_nombre as paciente,
s.evento,
c.numerodecuenta,
CASE    WHEN c.estado='0' THEN 'FACTURADA'
                            WHEN c.estado='1' THEN 'ACTIVA'
                            WHEN c.estado='2' THEN 'INACTIVA'
                            WHEN c.estado='3' THEN 'CUADRADA'
                          END AS cuenta_estado,
to_char(c.fecha_registro, 'yyyy-mm-dd') as fecha_cuenta,
c.total_cuenta,
c.valor_total_paciente,
c.valor_total_empresa as valor_total,
to_char(ac.fecha_registro, 'yyyy-mm-dd') as fecha_cuadre,
t.nombre_tercero,
pl.plan_descripcion,
ff.prefijo||' '||ff.factura_fiscal as factura				  				  

FROM cuentas c
INNER JOIN ingresos i ON c.ingreso=i.ingreso
INNER JOIN pacientes p ON i.paciente_id=p.paciente_id AND i.tipo_id_paciente=p.tipo_id_paciente
LEFT JOIN ingresos_soat s ON i.ingreso=s.ingreso 
LEFT JOIN (select max(fecha_registro) as fecha_registro, numerodecuenta from auditoria_cuentas_cuadradas group by 2) ac ON c.numerodecuenta=ac.numerodecuenta
INNER JOIN departamentos d ON (i.departamento = d.departamento)
INNER JOIN departamentos e ON (i.departamento_actual = e.departamento)
INNER JOIN planes pl ON c.plan_id=pl.plan_id 
INNER JOIN terceros t ON pl.tipo_tercero_id=t.tipo_id_tercero AND pl.tercero_id=t.tercero_id
left join (
                    select  f.*,
                            ffc.numerodecuenta
                    from    fac_facturas f
                        left join fac_facturas_cuentas ffc on (f.empresa_id = ffc.empresa_id and f.prefijo = ffc.prefijo and f.factura_fiscal = ffc.factura_fiscal)
                    where f.estado NOT IN ('2','3')
					and f.tipo_factura != '0'
                ) ff on (ff.numerodecuenta = c.numerodecuenta)
WHERE c.estado IN ('1','2','3')
AND c.fecha_registro::DATE  BETWEEN _1 AND _2
ORDER BY 1