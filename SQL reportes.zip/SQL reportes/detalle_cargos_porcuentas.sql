SELECT
c.ingreso,
cd.numerodecuenta, 
pl.plan_descripcion,
cd.fecha_cargo, 
CASE WHEN c.estado = '0' THEN 'FACTURADA'
     WHEN c.estado = '1' THEN 'ACTIVA'
     WHEN c.estado = '2' THEN 'INACTIVA'
     WHEN c.estado = '3' THEN 'CUADRADA'
	 ELSE 'ANULADA' END AS estado_cta,
cd.tarifario_id,
ta.descripcion,
round(cd.cantidad,0) as cantidad,
cd.precio,
CASE WHEN cu.sw_pos='0' THEN 'NO POS' 
	 WHEN cu.sw_pos='1' THEN 'POS' 
	 ELSE 'POS' END AS sw_pos,
p.tipo_id_paciente||' '||p.paciente_id AS id_paciente, p.primer_apellido||' '||p.segundo_apellido||' '||p.primer_nombre AS paciente,
su.nombre as Usuario_cargue,
cd.cargo_cups,
cu.descripcion AS cargo_cups,
cd.cargo,
td.descripcion
FROM cuentas c
INNER JOIN cuentas_detalle AS cd ON c.numerodecuenta=cd.numerodecuenta
INNER JOIN planes AS pl ON c.plan_id=pl.plan_id
INNER JOIN ingresos i ON c.ingreso=i.ingreso
INNER JOIN cups cu ON (cd.cargo_cups=cu.cargo)
INNER JOIN tarifarios ta ON (cd.tarifario_id=ta.tarifario_id)
INNER JOIN tarifarios_detalle td ON (cd.cargo=td.cargo AND cd.tarifario_id=td.tarifario_id)
INNER JOIN system_usuarios su ON cd.usuario_id=su.usuario_id
INNER JOIN pacientes p ON i.paciente_id=p.paciente_id
WHERE cd.consecutivo IS NULL 
AND cd.fecha_cargo::date BETWEEN _1 AND _2
ORDER BY cd.numerodecuenta

