select ing.ingreso,
cta.numerodecuenta,
(pac.primer_nombre||' '||pac.segundo_nombre||' '||pac.primer_apellido||' '||pac.segundo_apellido) as paciente,
bdd.codigo_producto,
ip.descripcion,
cd.cantidad,
bdn.descripcion,
bd.numeracion,
bdn.bodega,
u.nombre as Usuario_realiza_cargue,
cd.fecha_cargo from cuentas_detalle as cd
inner join cuentas as cta ON cta.numerodecuenta = cd.numerodecuenta
inner join ingresos as ing ON ing.ingreso = cta.ingreso
inner join pacientes as pac ON ing.tipo_id_paciente = pac.tipo_id_paciente and ing.paciente_id = pac.paciente_id
inner join bodegas_documentos_d as bdd ON bdd.consecutivo = cd.consecutivo
inner join inventarios_productos as ip ON ip.codigo_producto = bdd.codigo_producto
inner join bodegas_documentos as bd ON bd.bodegas_doc_id = bdd.bodegas_doc_id and bd.numeracion = bdd.numeracion
inner join bodegas_doc_numeraciones as bdn ON bdn.bodegas_doc_id = bd.bodegas_doc_id
inner join system_usuarios as u  ON bd.usuario_id=u.usuario_id
where cd.fecha_cargo::date >= _1 and cd.fecha_cargo::date<=_2
order by 1,2,8,5

