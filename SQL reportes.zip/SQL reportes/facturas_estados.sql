SELECT a.prefijo, a.factura_fiscal, a.total_factura, a.valor_cuota_paciente, b.plan_descripcion, ed.envio_id,
a.fecha_registro::date AS fecha_factura, e.fecha_registro_sistema::date AS fecha_registro_envio, e.fecha_radicacion::date,
CASE WHEN a.fecha_vencimiento_factura IS NULL THEN 'SIN RADICAR'
     ELSE 'RADICADO' END AS ESTADO
FROM fac_facturas a LEFT OUTER JOIN envios_detalle ed ON ed.factura_fiscal=a.factura_fiscal 
LEFT OUTER JOIN envios e ON ed.envio_id=e.envio_id
INNER JOIN planes b ON (a.plan_id=b.plan_id)
WHERE a.estado NOT IN('1', '2', '3')
AND a.tipo_factura ='1'
AND a.prefijo='FC'
AND a.fecha_registro::date BETWEEN _1 AND _2