SELECT a.solicitud_id AS Solicitud
,a.tipo_solicitud
,CASE WHEN a.sw_estado= '0' THEN 'SIN DESPACHO'
     WHEN a.sw_estado='1' THEN 'DESPACHADA'
     WHEN a.sw_estado= '2' THEN 'RECIBIDA'
     WHEN a.sw_estado= '3' THEN 'CANCELADA'
     WHEN a.sw_estado= '4' THEN 'CONSUMO DIRECTO'
	 WHEN a.sw_estado= '5' THEN 'RECIBIDO PARCIALMENTE'
     WHEN a.sw_estado= '6' THEN 'DESPACHADO BOD - CANCELADO EST'
     END AS estado_solicitud
,concat(h.tipo_id_paciente,' ',h.paciente_id) AS Identificacion_Paciente
,concat(i.primer_apellido,' ',i.segundo_apellido,' ',i.primer_nombre,' ',i.segundo_nombre) AS Nombre_paciente
,m.descripcion AS Bodega
,c.codigo_producto AS medicamento
,d.descripcion
,c.cantidad
,c.lote AS lote_med
--
,j.codigo_producto AS insumo
,di.descripcion AS nombre_ins
,j.lote AS lote_ins
,k.cantidad
--
,e.nombre AS Usuario_solicita
,f.descripcion AS Estacion
,a.fecha_solicitud::date 
,g.nombre AS Usuario_despacha
,b.fecha_registro::date AS Fecha_confirmacion_despacho
FROM hc_solicitudes_medicamentos a
INNER JOIN bodegas_documento_despacho_med b ON b.documento_despacho_id=a.documento_despacho 
LEFT JOIN bodegas_documento_despacho_med_d c ON b.documento_despacho_id=c.documento_despacho_id 
LEFT JOIN bodegas_documento_despacho_ins_d j ON b.documento_despacho_id=j.documento_despacho_id
LEFT JOIN hc_solicitudes_insumos_d k ON j.consecutivo_solicitud=k.consecutivo_d AND a.solicitud_id=k.solicitud_id
LEFT JOIN inventarios_productos d ON c.codigo_producto=d.codigo_producto
LEFT JOIN inventarios_productos di ON j.codigo_producto=di.codigo_producto
INNER JOIN bodegas_doc_numeraciones l ON b.bodegas_doc_id=l.bodegas_doc_id
INNER JOIN bodegas m ON l.bodega=m.bodega
INNER JOIN system_usuarios e ON a.usuario_id=e.usuario_id
INNER JOIN system_usuarios g ON b.usuario_id=g.usuario_id
INNER JOIN estaciones_enfermeria f ON a.estacion_id=f.estacion_id 
INNER JOIN ingresos h ON a.ingreso=h.ingreso
INNER JOIN pacientes i ON h.paciente_id=i.paciente_id
WHERE a.fecha_solicitud::date BETWEEN _1 AND _2
