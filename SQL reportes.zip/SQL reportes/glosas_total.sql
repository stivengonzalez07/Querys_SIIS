select g.glosa_id, 
g.prefijo, 
g.factura_fiscal, 
g.valor_glosa,
g.valor_pendiente,
g.fecha_glosa,
ff.saldo as saldo_factura,
SUM(gr.valor_aceptado) as valor_aceptado_ips,
SUM(gr.valor_no_aceptado) as valor_no_aceptado_ips,
SUM(gre.valor_aceptado) as valor_aceptado_eps,
SUM(gre.valor_no_aceptado) as valor_no_aceptado_eps
FROM glosas g
JOIN fac_facturas ff ON (g.prefijo = ff.prefijo AND g.factura_fiscal=ff.factura_fiscal)
JOIN glosas_respuestas gr ON (g.glosa_id=gr.glosa_id)
JOIN glosas_respuestas_eps gre ON (g.glosa_id=gre.glosa_id)
WHERE g.fecha_glosa BETWEEN _1 AND _2
GROUP BY 1,2,3,4,5,6,7
ORDER BY 3
