
                   SELECT  D.diagnostico_id,
        D.diagnostico_nombre,
        to_char(I.fecha_ingreso,'YYYY-MM-DD') AS fecha_ingreso,
        P.tipo_id_paciente,
        P.paciente_id,
        P.primer_nombre,
        P.segundo_nombre,
        P.primer_apellido,
        P.segundo_apellido,
		I.ingreso,
        to_char(age (I.fecha_ingreso, P.fecha_nacimiento),'YY') || ' Año(s)' AS edad,
        P.residencia_direccion,
        P.residencia_telefono,
		dep.descripcion as departamento,
		HE.fecha_cierre
FROM    ingresos I,
        pacientes P,
        diagnosticos D,
        hc_diagnosticos_egreso DE,
        hc_evoluciones HE,
		departamentos dep
WHERE   I.fecha_registro::date >=_1
AND     I.fecha_registro::date <=_2
AND     I.tipo_id_paciente = P.tipo_id_paciente
AND     I.paciente_id = P.paciente_id
AND     I.ingreso = HE.ingreso
AND     HE.evolucion_id = DE.evolucion_id
AND     HE.departamento = dep.departamento
AND     DE.tipo_diagnostico_id = D.diagnostico_id
AND     DE.sw_principal = '1'
ORDER BY 1
