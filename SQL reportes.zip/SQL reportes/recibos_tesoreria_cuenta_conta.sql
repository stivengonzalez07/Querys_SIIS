SELECT  rct.descripcion,
		rc.fecha_ingcaja::date AS fecha_ingreso_caja, 
        rc.fecha_registro::date AS fecha_registro_recibo, 
        rc.prefijo||' '||rc.recibo_caja AS recibo_caja, 
        t.nombre_tercero AS entidad, 
        CASE 
        WHEN rc.estado='1' THEN 'ANULADO'
        ELSE 'CERRADO' END AS estado_recibo, 
        rcf.prefijo_factura||' '||rcf.factura_fiscal AS factura_fiscal, 
        rcf.valor_abonado, 
        rcco.descripcion AS concepto, 
        rcc.valor AS valor_concepto,
		cg1d.cuenta, 
		cg1d.debito,
		cg1d.credito
FROM    recibos_caja rc
JOIN rc_tipos_documentos rct ON rc.rc_tipo_documento=rct.rc_tipo_documento
LEFT JOIN cg_mov_01.cg_mov_contable_01 cg1 ON (rc.prefijo = cg1.prefijo AND rc.recibo_caja = cg1.numero)
LEFT JOIN cg_mov_01.cg_mov_contable_01_detalle 	cg1d ON cg1.documento_contable_id = cg1d.documento_contable_id	
LEFT JOIN rc_detalle_tesoreria_facturas rcf ON rc.prefijo=rcf.prefijo AND rc.recibo_caja=rcf.recibo_caja
LEFT JOIN rc_detalle_tesoreria_conceptos rcc ON rc.prefijo= rcc.prefijo AND rc.recibo_caja=rcc.recibo_caja
LEFT JOIN rc_conceptos_tesoreria rcco ON rcc.concepto_id=rcco.concepto_id
INNER JOIN terceros t ON rc.tipo_id_tercero=t.tipo_id_tercero AND rc.tercero_id=t.tercero_id
WHERE rc.fecha_registro::date BETWEEN _1 AND _2
AND   rc.sw_recibo_tesoreria = '1'