SELECT DISTINCT i.ingreso,
        	i.paciente_id,
        	i.tipo_id_paciente,
        	to_char(i.fecha_ingreso, 'DD-MM-YYYY') as  fecha_ingreso,
        	to_char(i.fecha_ingreso,'HH24:MI:SS') as hora,
        	p.primer_nombre || p.segundo_nombre || p.primer_apellido || p.segundo_apellido AS nombre,
    		p.sexo_id,
          	pl.plan_descripcion,
    		s.nombre as doctor,
          	c.valor_total_paciente,
    		di.tipo_diagnostico_id,
    		d.diagnostico_nombre,
			dep.descripcion as Departamento_ingreso
FROM    	pacientes p,
          	planes pl,
          	ingresos i,
          	hc_evoluciones e,
          	cuentas c,
    		system_usuarios s,
    		profesionales pro,
    		tipos_profesionales tpro,
    		hc_diagnosticos_ingreso di,
    		diagnosticos d,
			departamentos dep,
    		profesionales_especialidades pe
WHERE   	i.paciente_id = p.paciente_id
AND     	i.tipo_id_paciente = p.tipo_id_paciente
AND     	c.ingreso = i.ingreso
AND     	c.plan_id = pl.plan_id
AND     	i.ingreso = e.ingreso
AND    		i.departamento IN('CIRU01','HOS003','HOS004','HOS005','HOS006','UCI003','UCI005','UCI006','UCI07A','UCIN04','URGENC')
AND    		e.usuario_id = s.usuario_id
AND    		e.usuario_id = pro.usuario_id
--AND     	pe.especialidad = '024'
AND     	pro.tercero_id = pe.tercero_id
AND    		pro.tipo_profesional = tpro.tipo_profesional
AND    		di.evolucion_id = e.evolucion_id
AND    		di.tipo_diagnostico_id = d.diagnostico_id
AND			dep.departamento=i.departamento
AND    		i.fecha_ingreso::date >= _1
AND     	i.fecha_ingreso::date <= _2
ORDER BY    	pl.plan_descripcion
