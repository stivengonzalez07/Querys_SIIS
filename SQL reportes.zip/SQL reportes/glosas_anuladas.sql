SELECT ga.glosa_auditoria_anulacion_id, ga.glosa_id, ga.observacion as observacion_anulacion, ga.fecha_registro as fecha_registro_anulacion, su.nombre, ga.prefijo, ga.numero as numerocont_glosa_anulada, g.prefijo, g.factura_fiscal, g.fecha_glosa
FROM glosas_auditoria_anulaciones ga, glosas g, system_usuarios su
WHERE ga.glosa_id = g.glosa_id
AND su.usuario_id = ga.usuario_id
AND ga.fecha_registro::date >= _1
AND ga.fecha_registro::date <= _2
order by ga.glosa_auditoria_anulacion_id