SELECT  pa.primer_nombre ||' '|| pa.segundo_nombre ||' '|| pa.primer_apellido ||' '|| pa.segundo_apellido as nombre_paciente,
pa.paciente_id, pa.tipo_id_paciente, ee.descripcion,
bd.codigo_producto, ip2.descripcion, hm.fecha_solicitud, b.fecha_registro as fecha_despacho , bd.cantidad, bd.lote, bd.fecha_vencimiento

--,bd.consecutivo_depacho, b.documento_despacho_id, consecutivo_d
FROM hc_solicitudes_medicamentos_d hmd
INNER JOIN hc_solicitudes_medicamentos hm ON hmd.solicitud_id=hm.solicitud_id
INNER JOIN inventarios_productos ip ON hmd.medicamento_id=ip.codigo_producto
INNER JOIN estaciones_enfermeria ee ON hm.estacion_id=ee.estacion_id
INNER JOIN ingresos i ON hmd.ingreso=i.ingreso
INNER JOIN pacientes pa ON i.tipo_id_paciente=pa.tipo_id_paciente AND i.paciente_id=pa.paciente_id
INNER JOIN bodegas_documento_despacho_med_d bd ON hmd.consecutivo_d=bd.consecutivo_solicitud
INNER JOIN inventarios_productos ip2 ON bd.codigo_producto=ip2.codigo_producto
INNER JOIN bodegas_documento_despacho_med b ON bd.documento_despacho_id = b.documento_despacho_id
WHERE hm.bodega = 'CP'
AND hm.fecha_solicitud BETWEEN _1 AND _2
--AND b.fecha_registro BETWEEN '2022-02-01' AND '2022-02-03'