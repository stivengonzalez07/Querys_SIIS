SELECT c.numerodecuenta,i.tipo_id_paciente ||' '||i.paciente_id AS id_paciente,
 p.primer_apellido||' '||p.segundo_apellido||' '||p.primer_nombre||' '||p.segundo_nombre AS paciente,
 c.valor_total_empresa::integer as valor_cuenta,
 su.nombre AS usuario_admision,
  i.fecha_ingreso::date, pl.plan_descripcion AS entidad,
CASE 
WHEN c.estado='0' THEN 'FACTURADA'
WHEN c.estado='1' THEN 'ACTIVA'
WHEN c.estado='2' THEN 'INACTIVA'
WHEN c.estado='3' THEN 'CUADRADA'
WHEN c.estado='4' THEN 'ANTICIPOS'
ELSE 'ANULADA' 
END AS cuenta_estado,
d.descripcion AS departamento_ingreso
FROM cuentas c,
ingresos i,
pacientes p, 
system_usuarios su, 
planes pl,
departamentos d 
WHERE c.ingreso=i.ingreso
AND i.tipo_id_paciente=p.tipo_id_paciente AND i.paciente_id=p.paciente_id
AND c.estado!='5' 
AND pl.tipo_cliente='20'
AND i.paciente_id=p.paciente_id
AND c.plan_id=pl.plan_id
AND i.usuario_id=su.usuario_id
AND i.departamento=d.departamento
AND i.fecha_ingreso::date>=_1
AND i.fecha_ingreso::date<=_2
ORDER BY 1
