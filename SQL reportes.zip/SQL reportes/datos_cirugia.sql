SELECT
qxp.tipo_id_paciente,
qxp.paciente_id,
p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS Nombre_paciente,
e.numerodecuenta,
pl.tipo_tercero_id AS tipo_id_plan,
pl.tercero_id AS id_plan, pl.plan_descripcion, noc.hora_inicio::date AS fecha_cirugia,
tc.nombre_tercero AS cirujano_id,
ta.nombre_tercero AS anestesiologo,
tay.nombre_tercero AS ayudante

FROM hc_notas_operatorias_cirugias AS noc  

INNER JOIN qx_programaciones AS qxp ON qxp.programacion_id=noc.programacion_id
INNER JOIN pacientes AS p ON p.paciente_id=qxp.paciente_id AND p.tipo_id_paciente=qxp.tipo_id_paciente
INNER JOIN hc_evoluciones AS e ON e.evolucion_id=noc.evolucion_id
INNER JOIN cuentas AS c ON c.numerodecuenta=e.numerodecuenta
INNER JOIN planes AS pl ON pl.plan_id=c.plan_id
LEFT JOIN terceros AS tc ON tc.tercero_id=noc.cirujano_id AND tc.tipo_id_tercero=noc.tipo_id_cirujano
LEFT JOIN terceros AS ta ON ta.tercero_id=noc.anestesiologo_id AND ta.tipo_id_tercero=noc.tipo_id_anestesiologo
LEFT JOIN terceros AS tay ON noc.ayudante_id = tay.tercero_id AND noc.tipo_id_ayudante = tay.tipo_id_tercero

--WHERE noc.fecha_registro BETWEEN '2021-02-28' AND '2021-03-23'
WHERE noc.fecha_registro BETWEEN _1 AND _2
