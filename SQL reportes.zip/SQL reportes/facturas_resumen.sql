SELECT 	prefijo,
        factura_fiscal,
        tipo_id_tercero,
	      tercero_id,
        total_factura,
        total_recibo,
        total_nota_glosa,
	      total_nota_ajuste,
        total_nota_credito,
        total_nota_debito,
        total_nota_anulacion

FROM    cartera.facturas_resumen

WHERE   intervalo = 201206;




