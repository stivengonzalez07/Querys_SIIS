SELECT at.fecha_turno AS fecha_cita, ac.hora as hora_cita, 
esp.descripcion AS especialidad, pr.nombre AS Profesional_atiende, aca.fecha_registro AS fecha_asignacion_cita ,p.tipo_id_paciente||' '||p.paciente_id AS id_paciente, 
p.primer_apellido||' '||p.segundo_apellido||' '||p.primer_nombre AS paciente, pl.plan_descripcion AS entidad, su.nombre AS usuario_asigno_cita,
tc.descripcion as tipo_consulta, 
'SI' as asignada,
(select 
CASE 
WHEN evol.evolucion_id IS NOT NULL THEN 'SI'
ELSE 'NO' END  from hc_evoluciones AS evol where  ctas.ingreso=evol.ingreso limit 1) as cumplida,
'' as incumplida,
(select 'SI' from agenda_citas_asignadas_cancelacion acc where ac.agenda_cita_id=aca.agenda_cita_id and 
	aca.agenda_cita_asignada_id=acc.agenda_cita_asignada_id limit 1) as cancelada,
'' as sacar,
concat(p.paciente_id,at.fecha_turno,ac.hora) as calculo,
ac.agenda_cita_id as cita_id,
aca.observacion
INTO
temporary matrizcitas
FROM
agenda_citas ac
LEFT OUTER JOIN agenda_citas_asignadas aca ON ac.agenda_cita_id=aca.agenda_cita_id 
INNER JOIN tipos_cita AS tc ON aca.tipo_cita=tc.tipo_cita
INNER JOIN agenda_turnos at ON ac.agenda_turno_id=at.agenda_turno_id
LEFT OUTER JOIN os_cruce_citas AS os_cruz ON aca.agenda_cita_asignada_id=os_cruz.agenda_cita_asignada_id
LEFT OUTER JOIN os_maestro AS os_maes ON os_cruz.numero_orden_id=os_maes.numero_orden_id
LEFT OUTER JOIN cuentas AS ctas ON os_maes.numerodecuenta=ctas.numerodecuenta
LEFT OUTER JOIN pacientes p ON aca.tipo_id_paciente=p.tipo_id_paciente AND aca.paciente_id=p.paciente_id
LEFT OUTER JOIN profesionales pr ON at.tipo_id_profesional=pr.tipo_id_tercero AND at.profesional_id=pr.tercero_id
LEFT OUTER JOIN profesionales_especialidades pe ON pr.tipo_id_tercero=pe.tipo_id_tercero AND pr.tercero_id=pe.tercero_id
LEFT OUTER JOIN especialidades esp ON pe.especialidad=esp.especialidad
LEFT OUTER JOIN planes pl ON aca.plan_id=pl.plan_id
LEFT OUTER JOIN system_usuarios su ON aca.usuario_id=su.usuario_id
--WHERE aca.fecha_registro::date BETWEEN '2018-04-01' AND '2018-04-30';
WHERE at.fecha_turno::date BETWEEN _1 AND _2;
update matrizcitas set incumplida='SI' where cancelada is NULL and cumplida is NULL;
update matrizcitas set cumplida='NO' where cumplida IS NULL;
update matrizcitas set cancelada='NO' where cancelada IS NULL;
update matrizcitas set incumplida='NO' where incumplida::text='';
ALTER TABLE matrizcitas ADD COLUMN secuencia serial;
update matrizcitas set sacar='SI' from (select count(calculo),cita_id,calculo from matrizcitas where cancelada::text='SI' and matrizcitas.cumplida::text='NO'  group by calculo,cita_id
having count(calculo)>=1) as lina where matrizcitas.calculo=lina.calculo and matrizcitas.cumplida::text='NO';

select calculo  INTO
temporary matrizcitassi from matrizcitas where sacar::text='SI' group by calculo having count(calculo)>1;

select a.calculo,a.secuencia INTO temporary matrizcitasno from matrizcitas a, matrizcitassi b where a.calculo=b.calculo and 
 (a.incumplida::text='SI' and a.cancelada::text='NO') group by a.calculo,a.secuencia  order by a.secuencia;
update matrizcitas set sacar='' from (select calculo,max(secuencia) as mayor from matrizcitasno group by calculo) as mlondono where 
matrizcitas.secuencia=mlondono.mayor;
update matrizcitas set sacar='SI' from (select calculo from matrizcitasno group by calculo) as mlondono where matrizcitas.calculo=mlondono.calculo and matrizcitas.incumplida::text<>'SI' ;

select a.calculo,a.secuencia from matrizcitas a, matrizcitassi b where a.calculo=b.calculo and (a.cumplida::text='SI' and a.cancelada::text='NO') group by a.calculo,a.secuencia  order by a.secuencia;

select a.calculo,a.secuencia INTO temporary matrizcitasno1 from matrizcitas a, matrizcitassi b where a.calculo=b.calculo and 
(a.cumplida::text='SI' and a.cancelada::text='NO') group by a.calculo,a.secuencia  order by a.secuencia;
update matrizcitas set sacar='SI' from (select calculo from matrizcitasno1 group by calculo) as mlondono1 where matrizcitas.calculo=mlondono1.calculo and matrizcitas.cumplida::text<>'SI';


select a.calculo,a.secuencia INTO temporary matrizcitasno2 from matrizcitas a, matrizcitassi b where a.calculo=b.calculo and 
 (a.cumplida::text='NO' and a.cancelada::text='SI') group by a.calculo,a.secuencia  order by a.secuencia;
update matrizcitas set sacar='' from (select calculo,max(secuencia) as mayor from matrizcitasno2 group by calculo) as mlondono where 
matrizcitas.secuencia=mlondono.mayor and (matrizcitas.cumplida::text='NO' and matrizcitas.cancelada::text='SI') or (matrizcitas.incumplida::text='SI' and matrizcitas.cancelada::text='NO') ;
update matrizcitas set sacar='SI' from (select calculo,min(secuencia) as mayor from matrizcitasno2 group by calculo) as mlondono where 
matrizcitas.secuencia=mlondono.mayor and (matrizcitas.cumplida::text<>'NO' and matrizcitas.cancelada::text<>'SI') or (matrizcitas.incumplida::text<>'SI' and matrizcitas.cancelada::text<>'NO') ;

select a.calculo INTO temporary matrizcitasno3 from matrizcitas a where cumplida::text='NO' and cancelada::text='SI' and incumplida::text='NO' and sacar::text='SI' group by a.calculo having count(a.calculo)>=2;
update matrizcitas set sacar='' from (select b.calculo,max(b.secuencia) as mayor from matrizcitasno3 a, matrizcitas b where a.calculo=b.calculo group by b.calculo) as mlondono where matrizcitas.secuencia=mlondono.mayor;

select fecha_cita, hora_cita, especialidad, Profesional_atiende, fecha_asignacion_cita,
id_paciente, paciente, entidad, usuario_asigno_cita, tipo_consulta, asignada, cumplida,
incumplida,  cancelada, observacion
from matrizcitas where sacar::text<>'SI' order by fecha_cita,hora_cita