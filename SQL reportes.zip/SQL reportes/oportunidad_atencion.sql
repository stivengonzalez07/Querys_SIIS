select a.ingreso,
a.tipo_id_paciente,
a.paciente_id,
concat (f.primer_apellido,' ',f.segundo_apellido,' ',f.primer_nombre,' ',f.segundo_nombre) as Nombre_Completo,
TO_CHAR(a.fecha_registro,'YYYY-MM-DD HH24:MI') as fecha_ingreso,
TO_CHAR(b.fecha_registro_real,'YYYY-MM-DD HH24:MI') as fecha_motivo_consulta,
d.descripcion
from ingresos a
inner join pacientes f on(a.tipo_id_paciente=f.tipo_id_paciente and a.paciente_id=f.paciente_id)
inner join hc_motivo_consulta b on(b.ingreso=a.ingreso)
inner join departamentos d on(d.departamento=a.departamento)
where
a.fecha_registro::date BETWEEN _1 AND _2 order by a.fecha_registro asc
