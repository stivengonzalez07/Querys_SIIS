SELECT 	c.numerodecuenta,
        i.ingreso,
        i.tipo_id_paciente,
		i.paciente_id,
        p.plan_descripcion,
        c.total_cuenta,
        ce.descripcion as estado,
		c.fecha_registro,
        u.nombre,
        d.descripcion as departamento
FROM    cuentas c
    join 	ingresos i ON i.ingreso = c.ingreso
    join   cuentas_estados ce ON c.estado = ce.estado
    left join    departamentos d ON  c.departamento = d.departamento
	join    system_usuarios u ON c.usuario_id = u.usuario_id
    join   planes p ON  c.plan_id = p.plan_id
WHERE   NOT (c.estado ='5' )
AND     c.fecha_registro::date >= _1
AND     c.fecha_registro::date <= _2
ORDER BY numerodecuenta;


