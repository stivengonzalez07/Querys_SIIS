SELECT 	i.paciente_id,
		p.primer_nombre,
		p.segundo_nombre,
		p.primer_apellido,
		p.segundo_apellido,
		pl.plan_descripcion,
		to_char(i.fecha_ingreso, 'DD-MM-YYYY') as  fecha_ingreso,
		to_char(fac.fecha_registro, 'DD-MM-YYYY') as  fecha_factura,
		c.numerodecuenta,
		f.factura_fiscal,
		c.total_cuenta
FROM		cuentas c,
		ingresos i,
		pacientes p,
		fac_facturas_cuentas f,
		fac_facturas fac,
		planes pl
WHERE		c.ingreso = i.ingreso
AND		i.paciente_id = p.paciente_id
AND		i.tipo_id_paciente = p.tipo_id_paciente
AND		c.plan_id = pl.plan_id
AND		c.numerodecuenta = f.numerodecuenta
AND		f.factura_fiscal = fac.factura_fiscal
AND		i.fecha_ingreso::date >= _1 
AND 		i.fecha_ingreso::date <= _2	