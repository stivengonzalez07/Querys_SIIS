SELECT
 e.bodega AS Bodega_id,
bo.descripcion AS Bodega, 
ip.codigo_producto,
 ip.descripcion AS Producto,
 e.fecha_vencimiento,
 e.lote,
 ip.codigo_invima,
 u.descripcion AS unidad,
 ip.contenido_unidad_venta AS unidad_venta,
 m.cod_concentracion,
 COALESCE(i.costo,0) AS costo,
 COALESCE(e.existencia_actual,0) AS existencia
  --CASE WHEN (i.costo IS NOT NULL) THEN CASE WHEN (e.existencia IS NOT NULL) THEN ROUND((i.costo*e.existencia),2) ELSE 0 END ELSE 0 END AS total_costo,
  FROM
 inventarios_productos ip
 LEFT JOIN
 inventarios i ON ip.codigo_producto=i.codigo_producto
 JOIN
 empresas em ON em.empresa_id=i.empresa_id
 JOIN
 existencias_bodegas_lote_fv e ON i.codigo_producto=e.codigo_producto
 JOIN
 bodegas bo ON e.bodega=bo.bodega
 JOIN
 unidades u ON ip.unidad_id=u.unidad_id
 LEFT JOIN
 medicamentos m ON ip.codigo_producto=m.codigo_medicamento
 --WHERE e.bodega='29'
 --WHERE   CASE  WHEN $P{empresa} IS NOT NULL  THEN em.empresa_id=$P{empresa} ELSE TRUE END
 --AND ip.grupo_id IN ('04','06')
 AND COALESCE(e.existencia_actual,0) > 0
 ORDER BY em.empresa_id,em.razon_social,ip.descripcion