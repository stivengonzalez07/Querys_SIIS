SELECT
p.plan_id, p.num_contrato, p.plan_descripcion, p.fecha_inicio, p.fecha_final, p.monto_contrato, p.saldo_contrato, p.servicios_contratados,
p.lineas_atencion, t.descripcion AS tarifario, gt.grupo_tarifario_descripcion AS grupo_tarifario, sgt.subgrupo_tarifario_descripcion, pt.porcentaje as porcentaje,
CASE WHEN p.sw_solicita_autorizacion_admision='1' THEN 'REQUIERE AUTORIZACION'
     ELSE 'NO REQUIERE AUTORIZACION' END as autorizacion_admision
FROM
planes p
INNER JOIN plan_tarifario pt ON pt.plan_id=p.plan_id
INNER JOIN planes_servicios ps ON ps.plan_id=p.plan_id
INNER JOIN servicios s ON s.servicio=ps.servicio
INNER JOIN tarifarios t ON t.tarifario_id=pt.tarifario_id
INNER JOIN subgrupos_tarifarios sgt ON sgt.grupo_tarifario_id=pt.subgrupo_tarifario_id AND sgt.grupo_tarifario_id=pt.grupo_tarifario_id
INNER JOIN grupos_tarifarios gt ON gt.grupo_tarifario_id=sgt.grupo_tarifario_id
WHERE p.estado='1'