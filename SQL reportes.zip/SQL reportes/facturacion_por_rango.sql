select 
b.plan_descripcion,
b.paciente,
to_char(b.fecha_registro,'yyyy-mm-dd') as fecha,
case when b.prefijo = 'C' then 'CONTADO' else 'CREDITO' end as tipo_factura,
b.factura_fiscal,
round(b.total,0) as total_factura,
round(nc.valor_nota,0) as valor_nota,
round(b.total_paciente,0) as vr_paciente,
case when round(nc.valor_nota,0) is not null then round(round(b.total,0)-sum(nc.valor_nota),0) 
when round(b.total_paciente,0) > 0 then round(b.total,0)-sum(b.total_paciente)
else round(b.total,0) end as valor from (
SELECT  pl.plan_descripcion,
ff.prefijo,
ff.factura_fiscal,
ff.fecha_registro,
(primer_nombre||' '||segundo_nombre||' '||primer_apellido||' '||segundo_apellido) as paciente,
sum(cta.valor_cuota_paciente) as total_paciente,
sum(ff.total_factura) as total
           
FROM   fac_facturas_cuentas as ffc
INNER JOIN cuentas as cta ON ffc.numerodecuenta = cta.numerodecuenta
INNER JOIN fac_facturas as ff ON ffc.prefijo=ff.prefijo AND ffc.factura_fiscal=ff.factura_fiscal
INNER JOIN planes as pl ON cta.plan_id=pl.plan_id
INNER JOIN ingresos as ing ON cta.ingreso=ing.ingreso
INNER JOIN pacientes as pac ON ing.paciente_id=pac.paciente_id and ing.tipo_id_paciente=pac.tipo_id_paciente

WHERE   ff.fecha_registro >= _1
AND     ff.fecha_registro < _2
AND     NOT (ff.estado ='2' OR ff.estado ='3')
group by 1,2,3,4,5
ORDER BY 1) as b
left join notas_credito as nc ON b.prefijo = nc.prefijo_factura and b.factura_fiscal = nc.factura_fiscal
group by 1,2,3,4,5,6,7,8





