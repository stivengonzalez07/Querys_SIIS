SELECT DISTINCT b.bodega, ds.fecha_entrega, ds.codigo_producto as Codigo_producto_solicitado, i.descripcion, ds.codigo_producto_despachado, i.descripcion, ds.fecha_vencimiento, ds.lote, ds.cantidad_despachada, su.nombre
FROM ds_dispensaciones_externas_d ds,
inventarios_productos i,
ds_dispensaciones_externas d,
bodegas_documentos bd,
bodegas_doc_numeraciones b,
medicamentos m, system_usuarios su
WHERE ds.ds_dispensacion_externa_id = d.ds_dispensacion_externa_id
AND ds.codigo_producto=i.codigo_producto
AND ds.codigo_producto_despachado=i.codigo_producto
AND d.bodegas_doc_id = bd.bodegas_doc_id
AND bd.bodegas_doc_id=b.bodegas_doc_id
AND i.codigo_producto = m.codigo_medicamento
AND m.sw_refrigerado='1'
AND su.usuario_id = d.usuario_id
--AND ds.fecha_entrega::date BETWEEN _1 AND _2
ORDER BY ds.fecha_entrega;