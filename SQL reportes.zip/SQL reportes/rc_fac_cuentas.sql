SELECT r.prefijo ||' '|| r.recibo_caja as Recibo, r.fecha_ingcaja as Fecha_Documento, 
rd.prefijo_factura ||' '|| rd.factura_fiscal as Factura, rd.valor_abonado, fc.numerodecuenta as Cuenta
FROM recibos_caja r
JOIN rc_detalle_tesoreria_facturas rd ON (rd.prefijo=r.prefijo AND rd.recibo_caja=r.recibo_caja)
JOIN fac_facturas_cuentas fc ON (fc.factura_fiscal=rd.factura_fiscal AND fc.prefijo=rd.prefijo_factura)
WHERE r.estado='2' AND sw_recibo_tesoreria='1'
AND r.fecha_ingcaja::date BETWEEN _1 AND _2
ORDER BY rd.factura_fiscal