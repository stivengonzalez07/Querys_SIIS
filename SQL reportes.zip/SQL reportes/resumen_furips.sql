SELECT i.ingreso,i.fecha_ingreso,
PA.tipo_id_PAciente,PA.PAciente_id,PA.primer_nombre||' '||PA.segundo_nombre||' '||PA.primer_apellido||' '||PA.segundo_apellido AS Nombre_completo,
PA.fecha_nacimiento,PA.residencia_direccion,PA.sexo_id,PA.tipo_dpto_id,
se.evento,case when se.asegurado='1' then 'Asegurado'
               when se.asegurado='2' then 'No Asegurado'
               when se.asegurado='3' then 'Vehiculo Fantasma'
               when se.asegurado='4' then 'Poliza Falsa'
               when se.asegurado='5' then 'Vehiculo en Fuga' end condicion_de_la_victima,
se.condicion_accidentado,               
sp.poliza,sp.vigencia_desde,sp.vigencia_hasta,sp.placa_vehiculo,sp.marca_vehiculo,
sa.accidente_id,
sa.fecha_accidente,
sa.sitio_accidente,
sa.zona,
svp.apellidos_propietario || ' ' || svp.nombres_propietario AS nombres_propietario,svp.tipo_id_propietario,svp.propietario_id,svp.tipo_dpto_id,
svp.direccion_propietario,svp.telefono_propietario,
svc.apellidos_conductor || ' ' || svc.nombres_conductor AS nombres_conductor,svc.tipo_id_conductor,svc.conductor_id,svc.tipo_dpto_id,
svc.direccion_conductor,svc.telefono_conductor,
U1.nombre as usuario_realiza_ingreso,
U2.nombre as usuario_realiza_evento,
U3.nombre as usuario_realiza_datos_conductor,
sa.informe_accidente
FROM 
ingresos AS i
INNER JOIN  pacientes AS PA ON (i.paciente_id = PA.paciente_id AND i.tipo_id_paciente = PA.tipo_id_paciente)
INNER JOIN ingresos_soat AS iso ON iso.ingreso = i.ingreso
INNER JOIN soat_eventos AS se ON se.evento = iso.evento
LEFT JOIN soat_polizas AS sp ON sp.poliza = se.poliza
LEFT JOIN soat_accidente AS sa ON sa.accidente_id=se.accidente_id
LEFT JOIN soat_vehiculo_propietario AS svp ON svp.evento=se.evento
LEFT JOIN soat_vehiculo_conductor AS svc ON svc.evento=se.evento
LEFT JOIN system_usuarios AS U1 ON i.usuario_id=U1.usuario_id
LEFT JOIN system_usuarios AS U2 ON se.usuario_id=U2.usuario_id
LEFT JOIN system_usuarios AS U3 ON svc.usuario_id=U3.usuario_id 
WHERE 
i.fecha_ingreso::date between _1 AND _2


--1version//solo genera los eventos que ya estan completos; se reemplaza por el reporte que indica cuales estan diligenciados y cuales no!
--SELECT i.ingreso,i.fecha_ingreso,
--pa.tipo_id_paciente,pa.paciente_id,pa.primer_nombre||' '||pa.segundo_nombre||' '||pa.primer_apellido||' '||pa.segundo_apellido AS Nombre_completo,
--pa.fecha_nacimiento,pa.residencia_direccion,pa.sexo_id,pa.tipo_dpto_id,
--se.evento,case when se.asegurado='1' then 'Asegurado'
--               when se.asegurado='2' then 'No Asegurado'
--               when se.asegurado='3' then 'Vehiculo Fantasma'
--               when se.asegurado='4' then 'Poliza Falsa'
--               when se.asegurado='5' then 'Vehiculo en Fuga' end condicion_de_la_victima,
--sp.poliza,sp.vigencia_desde,sp.vigencia_hasta,sp.placa_vehiculo,sp.marca_vehiculo,
--sa.accidente_id,sa.fecha_accidente,sa.zona,sa.informe_accidente,
--svp.apellidos_propietario || ' ' || svp.nombres_propietario AS nombres_propietario,svp.tipo_id_propietario,svp.propietario_id,svp.tipo_dpto_id,
--svp.direccion_propietario,svp.telefono_propietario,
--svc.apellidos_conductor || ' ' || svc.nombres_conductor AS nombres_conductor,svc.tipo_id_conductor,svc.conductor_id,svc.tipo_dpto_id,
--svc.direccion_conductor,svc.telefono_conductor
--FROM  pacientes AS pa,
--ingresos AS i,
--ingresos_soat AS iso,
--soat_eventos AS se,
--soat_polizas AS sp,
--soat_accidente AS sa,
--soat_vehiculo_propietario AS svp,
--soat_vehiculo_conductor AS svc
--WHERE pa.paciente_id=i.paciente_id AND
--i.ingreso=iso.ingreso AND
--iso.evento=se.evento AND
--se.poliza=sp.poliza AND
--se.evento=svp.evento AND
--se.evento=svc.evento AND
--se.accidente_id=sa.accidente_id AND
--i.fecha_ingreso between _1 AND _2
