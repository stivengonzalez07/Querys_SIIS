SELECT
  cd.transaccion,
  cd.numerodecuenta,
  clqx.fecha_cirugia::date,
  c.cargo, c.descripcion AS procedimiento,
  e.descripcion AS especialidad,
  cqp.cirujano_id,
  clqx.anestesiologo_id,
  clqx.ayudante_id,
  clqx.duracion_cirugia ,
  cd.cargo,
  cd.consecutivo AS documento_despacho,
  bdd.codigo_producto,
  ip.descripcion AS producto,
  bdd.cantidad,
  bdd.total_costo,
  cd.departamento_al_cargar,
  i.ingreso,
  (pa.primer_nombre||' '||pa.segundo_nombre||' '||pa.primer_apellido||' '||pa.segundo_apellido) as paciente
--c.sw_new,case  c.sw_new when NULL THEN 'PERTENECE' else  'NO PERTENECE' end as resolucion

FROM
  cuentas_liquidaciones_qx clqx
  INNER JOIN cuentas_liquidaciones_qx_procedimientos cqp ON clqx.cuenta_liquidacion_qx_id=cqp.cuenta_liquidacion_qx_id
  INNER JOIN cuentas_detalle cd ON clqx.numerodecuenta=cd.numerodecuenta
  INNER JOIN cuentas cu ON cd.numerodecuenta=cu.numerodecuenta
  INNER JOIN ingresos i ON cu.ingreso=i.ingreso
  INNER JOIN pacientes pa ON i.paciente_id=pa.paciente_id
  INNER JOIN profesionales_especialidades pe ON cqp.cirujano_id=tercero_id
  INNER JOIN especialidades e ON pe.especialidad=e.especialidad
  LEFT OUTER JOIN bodegas_documentos_d bdd ON cd.consecutivo=bdd.consecutivo
  LEFT OUTER JOIN inventarios_productos ip ON bdd.codigo_producto=ip.codigo_producto
  LEFT OUTER JOIN cups c ON cqp.cargo_cups=c.cargo
WHERE 
  cd.departamento_al_cargar='CIRU01'
  AND clqx.fecha_cirugia::date BETWEEN _1 AND _2
order by 1

