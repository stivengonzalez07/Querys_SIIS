SELECT DISTINCT
  rc.fecha_ingcaja::date AS fecha_recibo,
  rc.total_abono,
  rc.fecha_registro::date AS fecha_registro_recibo,
  rc.prefijo||' '||rc.recibo_caja AS recibo_caja,
  t.nombre_tercero AS entidad,
  CASE
     WHEN rc.estado='1' THEN 'ANULADO'
     ELSE 'CERRADO' END AS estado_recibo,
  rcf.prefijo_factura||' '||rcf.factura_fiscal AS factura_fiscal,
  rcf.valor_abonado
--rcco.descripcion AS concepto,
--rcc.valor AS valor_concepto
FROM 
  recibos_caja rc
  LEFT JOIN rc_detalle_tesoreria_facturas rcf ON rc.prefijo=rcf.prefijo AND rc.recibo_caja=rcf.recibo_caja
  LEFT JOIN rc_detalle_tesoreria_conceptos rcc ON rc.prefijo= rcc.prefijo AND rc.recibo_caja=rcc.recibo_caja
--LEFT JOIN rc_conceptos_tesoreria rcco ON rcc.concepto_id=rcco.concepto_id
  LEFT JOIN terceros t ON rc.tipo_id_tercero=t.tipo_id_tercero AND rc.tercero_id=t.tercero_id
WHERE
  sw_recibo_tesoreria='1'
  AND rc.fecha_registro::date BETWEEN _1 AND _2
ORDER BY 1

