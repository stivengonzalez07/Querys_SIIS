SELECT 	c.numerodecuenta,
        i.ingreso,
        i.tipo_id_paciente,
		i.paciente_id,
        p.plan_descripcion,
        c.total_cuenta,
        ce.descripcion as estado,
		a.tipo_consulta_id,
		a.profesional_id,
		c.fecha_registro,
        u.nombre
        
		
FROM    cuentas c,
        cuentas_estados ce,
		ingresos i,
        system_usuarios u,
        cuentas_detalle cd,
		os_maestro_cargos omc, 
		os_cruce_citas oc, 
		agenda_citas_asignadas aca, 
		agenda_citas ac,
		agenda_turnos a,
        planes p
		
WHERE   c.estado = ce.estado
AND     NOT (c.estado ='0' OR c.estado ='5' OR c.estado ='3')
AND     c.usuario_id = u.usuario_id
AND     i.ingreso = c.ingreso
AND     c.plan_id = p.plan_id
AND     cd.transaccion = omc.transaccion
AND     omc.numero_orden_id = oc.numero_orden_id
AND     oc.agenda_cita_asignada_id = aca.agenda_cita_asignada_id
AND     aca.agenda_cita_id = ac.agenda_cita_id
AND     ac.agenda_turno_id = a.agenda_turno_id
AND     c.fecha_registro::date >= _1
AND     c.fecha_registro::date <= _2
GROUP BY c.numerodecuenta, i.ingreso, i.tipo_id_paciente, i.paciente_id, p.plan_descripcion, c.total_cuenta, ce.descripcion, a.tipo_consulta_id, a.profesional_id, c.fecha_registro, u.nombre
ORDER BY numerodecuenta;



