/*SELECT
em.razon_social AS EMPRESA,
c.numerodecuenta AS CUENTA,
CASE 
     WHEN c.estado = '0' THEN 'FACTURADA'
     WHEN c.estado = '1' THEN 'ACTIVA'
     WHEN c.estado = '2' THEN 'INACTIVA'
     WHEN c.estado = '3' THEN 'CUADRADA'
     WHEN c.estado = '5' THEN 'ANULADA'
          END AS ESTADO_CUENTA,
c.total_cuenta AS TOTAL_CUENTA,
i.ingreso AS INGRESO,
TO_CHAR(i.fecha_ingreso,'DD/MM/YYYY') AS FECHA_INGRESO,
CASE 
     WHEN ins.fecha_registro IS NOT NULL THEN TO_CHAR(ins.fecha_registro,'DD/MM/YYYY')
     WHEN ins.fecha_registro IS NULL AND he.fecha_egreso IS NOT NULL  THEN he.fecha_egreso
     ELSE TO_CHAR(i.fecha_registro,'DD/MM/YYYY')
          END AS FECHA_EGRESO,
TO_CHAR(c.fecha_cierre,'DD/MM/YYYY') AS FECHA_CIERRE,
ff.prefijo AS PREFIJO,
ff.factura_fiscal AS NO_FACTURA,
CASE 
     WHEN ff.estado = '0' THEN 'ACTIVA'
     WHEN ff.estado = '1' THEN 'PAGADA'
     WHEN ff.estado = '2' THEN 'ANULADA'
     WHEN ff.estado = '3' THEN 'ANULADA'
          END AS ESTADO_FACTURA,
t.tipo_id_tercero || ' ' || t.tercero_id AS NIT_ENTIDAD,
t.nombre_tercero AS NOMBRE_ENTIDAD,
pl.plan_descripcion AS PLAN,
p.primer_apellido ||' '|| p.segundo_apellido ||' '|| p.primer_nombre ||' '|| p.segundo_nombre AS NOMBRE_PACIENTE,
p.tipo_id_paciente AS TIPO_ID_PACIENTE,
p.paciente_id AS DOCUMENTO_IDENTIDAD,
cd.departamento AS DEPARTAMENTO_CARGO,
dp.descripcion AS DESCRIPCION_DEPARTAMENTO,
--cd.precio AS PRECIO_UNITARIO,
--cd.valor_cubierto AS VALOR_CUBIERTO,
--cd.valor_nocubierto AS VALOR_NOCUBIERTO,
CASE 
    WHEN cuqx.cargo IS NULL THEN cd.precio
ELSE
     case when ex.porcentaje is not null then round((((td.precio*ex.porcentaje)/100)+td.precio))
     else round((((td.precio*pt.porcentaje)/100)+td.precio))
     end
END AS PRECIO_UNITARIO,
CASE 
    WHEN cuqx.cargo IS NULL THEN cd.valor_cargo
ELSE 
    case when ex.porcentaje is not null then (round((((td.precio*ex.porcentaje)/100)+td.precio))*cd.cantidad)
    else (round((((td.precio*pt.porcentaje)/100)+td.precio))*cd.cantidad)
    end 
END AS VALOR_CARGO,
TO_CHAR(cd.fecha_cargo,'DD/MM/YYYY') AS FECHA_CARGO,
CASE 
     WHEN ser.servicio=  '0' THEN 'INDEFINIDO'
     WHEN ser.servicio= '99' THEN 'NO ASISTENCIAL'
     --WHEN ser.servicio=  '5' THEN 'PROMOCION Y PREVENCION'
     WHEN ser.servicio=  '7' THEN 'U.C.I.'
     WHEN ser.servicio=  '5' THEN 'APOYOS DIAGNOSTICOS'
     WHEN ser.servicio=  '4' THEN 'URGENCIAS'
     WHEN ser.servicio=  '1' THEN 'HOSPITALARIO'
     WHEN ser.servicio=  '3' THEN 'AMBULATORIO'
     --WHEN ser.servicio=  '9' THEN 'APOYO TERAPEUTICO'
     WHEN ser.servicio=  '2' THEN 'CIRUGIA'
     --WHEN ser.servicio=  '8' THEN 'ATENCION DOMICILIARIA' 
END  AS AMBITO,    
CASE WHEN clqx.cargo_cups IS NULL THEN cu.cargo 
     ELSE clqx.cargo_cups 
     END AS CUPS,
--,cu.descripcion AS DESCRIPCION_CUPS
'' AS COD_PRODUCTO,
'' AS DESCRIPCION_PRODUCTO,
cd.cantidad AS CANTIDAD,
'' AS POS,
--ta.descripcion AS MANUAL_TARIFARIO,
ta1.descripcion AS MANUAL_TARIFARIO,
su.nombre AS USUARIO_CARGUE,
cd.paquete_codigo_id::text AS CODIGO_PAQUETE,
ccqx.tipo_cargo_qx_id AS TIPO_CARGO_QX,
clqx.cargo_cups AS CARGO_QX,
--,cuqx.descripcion AS DESCRIPCION_CARGO
CASE 
    WHEN cuqx.cargo IS NOT NULL THEN cuqx.descripcion
    ELSE cu.descripcion 
        END AS DESCRIPCION_CARGO
FROM cuentas c
INNER JOIN ingresos i ON (c.ingreso = i.ingreso)
INNER JOIN pacientes p ON (i.paciente_id = p.paciente_id AND i.tipo_id_paciente = p.tipo_id_paciente)
INNER JOIN planes pl ON (pl.plan_id = c.plan_id)
INNER JOIN terceros t ON (pl.tercero_id = t.tercero_id AND pl.tipo_tercero_id = t.tipo_id_tercero)
LEFT JOIN fac_facturas_cuentas ffc ON (ffc.numerodecuenta = c.numerodecuenta AND c.empresa_id = ffc.empresa_id)
LEFT JOIN fac_facturas ff ON (ffc.factura_fiscal = ff.factura_fiscal AND ffc.prefijo = ff.prefijo AND ffc.empresa_id = ff.empresa_id)
INNER JOIN cuentas_detalle cd ON (c.numerodecuenta = cd.numerodecuenta)
INNER JOIN tarifarios_detalle td ON (cd.tarifario_id = td.tarifario_id AND cd.cargo = td.cargo)
INNER JOIN plan_tarifario pt ON (pt.tarifario_id = td.tarifario_id AND pt.grupo_tarifario_id = td.grupo_tarifario_id AND pt.subgrupo_tarifario_id = td.subgrupo_tarifario_id AND pt.plan_id = c.plan_id)
LEFT JOIN excepciones ex ON (ex.plan_id = c.plan_id and ex.tarifario_id = cd.tarifario_id and ex.cargo = cd.cargo)
INNER JOIN tarifarios ta ON (cd.tarifario_id = ta.tarifario_id)
INNER JOIN tarifarios ta1 ON (ta1.tarifario_id = pt.tarifario_id)
INNER JOIN cups cu ON (cd.cargo_cups = cu.cargo)
INNER JOIN departamentos dp ON (cd.departamento = dp.departamento)
INNER JOIN servicios ser ON (cd.servicio_cargo = ser.servicio)
LEFT JOIN ingresos_salidas ins ON (ins.ingreso = i.ingreso)
LEFT JOIN (select TO_CHAR(max(fecha),'DD/MM/YYYY') AS fecha_egreso, ingreso FROM hc_evoluciones GROUP BY ingreso) AS he ON (he.ingreso = i.ingreso)
INNER JOIN system_usuarios su ON (su.usuario_id = cd.usuario_id)
LEFT JOIN cuentas_cargos_qx_procedimientos ccqx ON (cd.transaccion = ccqx.transaccion)
LEFT JOIN cuentas_liquidaciones_qx_procedimientos clqx ON ( ccqx.consecutivo_procedimiento = clqx.consecutivo_procedimiento )
LEFT JOIN cups cuqx ON (cuqx.cargo = clqx.cargo_cups)
INNER JOIN empresas em ON (c.empresa_id = em.empresa_id)
WHERE pl.plan_id IN (1002,1003,1005)
AND ff.estado != '3'
--AND c.estado != '5'
AND i.fecha_registro::DATE BETWEEN _1 and _2
UNION 
SELECT
em.razon_social AS EMPRESA,
c.numerodecuenta AS CUENTA,
CASE 
     WHEN c.estado = '0' THEN 'FACTURADA'
     WHEN c.estado = '1' THEN 'ACTIVA'
     WHEN c.estado = '2' THEN 'INACTIVA'
     WHEN c.estado = '3' THEN 'CUADRADA'
     WHEN c.estado = '5' THEN 'ANULADA'
          END AS ESTADO_CUENTA,
c.total_cuenta AS TOTAL_CUENTA,
i.ingreso AS INGRESO,
TO_CHAR(i.fecha_ingreso,'DD/MM/YYYY') AS FECHA_INGRESO,
CASE 
     WHEN ins.fecha_registro IS NOT NULL THEN TO_CHAR(ins.fecha_registro,'DD/MM/YYYY')
     WHEN ins.fecha_registro IS NULL AND he.fecha_egreso IS NOT NULL  THEN he.fecha_egreso
     ELSE TO_CHAR(i.fecha_registro,'DD/MM/YYYY')
          END AS FECHA_EGRESO,
TO_CHAR(c.fecha_cierre,'DD/MM/YYYY') AS FECHA_CIERRE,
ff.prefijo AS PREFIJO,
ff.factura_fiscal AS NO_FACTURA,
CASE 
     WHEN ff.estado = '0' THEN 'ACTIVA'
     WHEN ff.estado = '1' THEN 'PAGADA'
     WHEN ff.estado = '2' THEN 'ANULADA'
     WHEN ff.estado = '3' THEN 'ANULADA'
          END AS ESTADO_FACTURA,
t.tipo_id_tercero || ' ' || t.tercero_id AS NIT_ENTIDAD,
t.nombre_tercero AS NOMBRE_ENTIDAD,
pl.plan_descripcion AS PLAN,
p.primer_apellido ||' '|| p.segundo_apellido ||' '|| p.primer_nombre ||' '|| p.segundo_nombre AS NOMBRE_PACIENTE,
p.tipo_id_paciente AS TIPO_ID_PACIENTE,
p.paciente_id AS DOCUMENTO_IDENTIDAD,
cd.departamento AS DEPARTAMENTO_CARGO,
dp.descripcion AS DESCRIPCION_DEPARTAMENTO,
cd.precio AS PRECIO_UNITARIO,
--cd.valor_cubierto AS VALOR_CUBIERTO,
--cd.valor_nocubierto AS VALOR_NOCUBIERTO,
cd.valor_cargo AS VALOR_CARGO,
'' AS FECHA_CARGO,
CASE 
     WHEN ser.servicio=  '0' THEN 'INDEFINIDO'
     WHEN ser.servicio= '99' THEN 'NO ASISTENCIAL'
     --WHEN ser.servicio=  '5' THEN 'PROMOCION Y PREVENCION'
     WHEN ser.servicio=  '7' THEN 'U.C.I.'
     WHEN ser.servicio=  '5' THEN 'APOYOS DIAGNOSTICOS'
     WHEN ser.servicio=  '4' THEN 'URGENCIAS'
     WHEN ser.servicio=  '1' THEN 'HOSPITALARIO'
     WHEN ser.servicio=  '3' THEN 'AMBULATORIO'
     --WHEN ser.servicio=  '9' THEN 'APOYO TERAPEUTICO'
     WHEN ser.servicio=  '2' THEN 'CIRUGIA'
     --WHEN ser.servicio=  '8' THEN 'ATENCION DOMICILIARIA'
END  AS AMBITO,    
'' AS CUPS,
--,cu.descripcion AS DESCRIPCION_CUPS
ip.codigo_producto AS COD_PRODUCTO,
ip.descripcion AS DESCRIPCION_PRODUCTO,
cd.cantidad AS CANTIDAD,
CASE 
     WHEN med.sw_pos= '0' THEN 'NO POS'
     WHEN med.sw_pos= '1' THEN 'POS'
          END AS POS,
'' AS MANUAL_TARIFARIO,
'' AS USUARIO_CARGUE,
'' AS CODIGO_PAQUETE,
'' AS TIPO_CARGO_QX,
'' AS CARGO_QX,
--,cuqx.descripcion AS DESCRIPCION_CARGO
'' AS DESCRIPCION_CARGO

FROM cuentas c

INNER JOIN ingresos i ON (c.ingreso = i.ingreso)
INNER JOIN pacientes p ON (i.paciente_id = p.paciente_id AND i.tipo_id_paciente = p.tipo_id_paciente)
INNER JOIN planes pl ON (pl.plan_id = c.plan_id)
INNER JOIN terceros t ON (pl.tercero_id = t.tercero_id AND pl.tipo_tercero_id = t.tipo_id_tercero)
LEFT JOIN fac_facturas_cuentas ffc ON (ffc.numerodecuenta = c.numerodecuenta AND c.empresa_id = ffc.empresa_id)
LEFT JOIN fac_facturas ff ON (ffc.factura_fiscal = ff.factura_fiscal AND ffc.prefijo = ff.prefijo AND ffc.empresa_id = ff.empresa_id)
INNER JOIN (
     select    bd.codigo_producto,
               ct.departamento,
               ct.numerodecuenta,
               MIN(ct.precio) as precio,
               SUM(case when ct.cargo = 'IMD' THEN ct.cantidad ELSE (ct.cantidad * (-1)) end) as cantidad,
               SUM(ct.valor_cargo) as valor_cargo
     from       cuentas_detalle ct
     INNER JOIN bodegas_documentos_d bd ON (ct.consecutivo = bd.consecutivo)
     where     ct.fecha_registro::date BETWEEN _1 and _2
     group by 1,2,3
) as cd on (cd.numerodecuenta = c.numerodecuenta)
INNER JOIN inventarios_productos ip ON (cd.codigo_producto = ip.codigo_producto)
INNER JOIN departamentos dp ON (cd.departamento = dp.departamento)
INNER JOIN servicios ser ON (dp.servicio = ser.servicio)
LEFT JOIN  medicamentos med ON (med.codigo_medicamento = cd.codigo_producto)
LEFT JOIN ingresos_salidas ins ON (ins.ingreso = i.ingreso)
LEFT JOIN (select TO_CHAR(max(fecha),'DD/MM/YYYY') AS fecha_egreso, ingreso FROM hc_evoluciones GROUP BY ingreso) AS he ON (he.ingreso = i.ingreso)
INNER JOIN empresas em ON (c.empresa_id = em.empresa_id)
WHERE pl.plan_id IN (1002,1003,1005)
AND ff.estado != '3'
--AND c.estado != '5'
AND i.fecha_registro::DATE BETWEEN _1 and _2
ORDER BY CUENTA
*/
SELECT
cd.transaccion AS TRANSACION
,em.razon_social AS EMPRESA
,c.numerodecuenta AS CUENTA
,CASE 
     WHEN c.estado = '0' THEN 'FACTURADA'
     WHEN c.estado = '1' THEN 'ACTIVA'
     WHEN c.estado = '2' THEN 'INACTIVA'
     WHEN c.estado = '3' THEN 'CUADRADA'
     WHEN c.estado = '5' THEN 'ANULADA'
          END AS ESTADO_CUENTA
,c.total_cuenta AS TOTAL_CUENTA
,i.ingreso AS INGRESO
,TO_CHAR(i.fecha_ingreso,'DD/MM/YYYY') AS FECHA_INGRESO
,CASE 
     WHEN ins.fecha_registro IS NOT NULL THEN TO_CHAR(ins.fecha_registro,'DD/MM/YYYY')
     WHEN ins.fecha_registro IS NULL AND he.fecha_egreso IS NOT NULL  THEN he.fecha_egreso
     ELSE TO_CHAR(i.fecha_registro,'DD/MM/YYYY')
          END AS FECHA_EGRESO
,TO_CHAR(c.fecha_cierre,'DD/MM/YYYY') AS FECHA_CIERRE
,ff.prefijo AS PREFIJO
,ff.factura_fiscal AS NO_FACTURA
,CASE 
     WHEN ff.estado = '0' THEN 'ACTIVA'
     WHEN ff.estado = '1' THEN 'PAGADA'
     WHEN ff.estado = '2' THEN 'ANULADA'
     WHEN ff.estado = '3' THEN 'ANULADA'
          END AS ESTADO_FACTURA
,t.tipo_id_tercero || ' ' || t.tercero_id AS NIT_ENTIDAD
,t.nombre_tercero AS NOMBRE_ENTIDAD
,pl.plan_descripcion AS PLAN
,p.primer_apellido ||' '|| p.segundo_apellido ||' '|| p.primer_nombre ||' '|| p.segundo_nombre AS NOMBRE_PACIENTE
,p.tipo_id_paciente AS TIPO_ID_PACIENTE
,p.paciente_id AS DOCUMENTO_IDENTIDAD
,cd.departamento AS DEPARTAMENTO_CARGO
,dp.descripcion AS DESCRIPCION_DEPARTAMENTO
,cd.precio AS PRECIO_UNITARIO
,cd.valor_cubierto AS VALOR_CUBIERTO
,cd.valor_nocubierto AS VALOR_NOCUBIERTO
,TO_CHAR(cd.fecha_cargo,'DD/MM/YYYY') AS FECHA_CARGO
,CASE 
     WHEN ser.servicio=  '0' THEN 'INDEFINIDO'
     WHEN ser.servicio= '99' THEN 'NO ASISTENCIAL'
     --WHEN ser.servicio=  '5' THEN 'PROMOCION Y PREVENCION'
     WHEN ser.servicio=  '7' THEN 'U.C.I.'
     WHEN ser.servicio=  '5' THEN 'APOYOS DIAGNOSTICOS'
     WHEN ser.servicio=  '4' THEN 'URGENCIAS'
     WHEN ser.servicio=  '1' THEN 'HOSPITALARIO'
     WHEN ser.servicio=  '3' THEN 'AMBULATORIO'
     --WHEN ser.servicio=  '9' THEN 'APOYO TERAPEUTICO'
     WHEN ser.servicio=  '2' THEN 'CIRUGIA'
     --WHEN ser.servicio=  '8' THEN 'ATENCION DOMICILIARIA'
          END  AS AMBITO
,    CASE WHEN clqx.cargo_cups IS NULL THEN cu.cargo 
     ELSE clqx.cargo_cups 
     END AS CUPS
--,cu.descripcion AS DESCRIPCION_CUPS
,ip.codigo_producto AS COD_PRODUCTO
,ip.descripcion AS DESCRIPCION_PRODUCTO
,cd.cantidad AS CANTIDAD
,CASE 
     WHEN med.sw_pos= '0' THEN 'NO POS'
     WHEN med.sw_pos= '1' THEN 'POS'
          END AS POS
,ta.descripcion AS MANUAL_TARIFARIO
,su.nombre AS USUARIO_CARGUE
,cd.paquete_codigo_id AS CODIGO_PAQUETE
,ccqx.tipo_cargo_qx_id AS TIPO_CARGO_QX
,clqx.cargo_cups AS CARGO_QX
--,cuqx.descripcion AS DESCRIPCION_CARGO
,CASE 
     WHEN cuqx.cargo IS NOT NULL THEN cuqx.descripcion
     ELSE cu.descripcion 
          END AS DESCRIPCION_CARGO

FROM cuentas c

INNER JOIN ingresos i ON (c.ingreso = i.ingreso)
INNER JOIN pacientes p ON (i.paciente_id = p.paciente_id AND i.tipo_id_paciente = p.tipo_id_paciente)
INNER JOIN planes pl ON (pl.plan_id = c.plan_id)
INNER JOIN terceros t ON (pl.tercero_id = t.tercero_id AND pl.tipo_tercero_id = t.tipo_id_tercero)
LEFT JOIN fac_facturas_cuentas ffc ON (ffc.numerodecuenta = c.numerodecuenta AND c.empresa_id = ffc.empresa_id)
LEFT JOIN fac_facturas ff ON (ffc.factura_fiscal = ff.factura_fiscal AND ffc.prefijo = ff.prefijo AND ffc.empresa_id = ff.empresa_id)
LEFT JOIN cuentas_detalle cd ON (c.numerodecuenta = cd.numerodecuenta)
LEFT JOIN tarifarios_detalle td ON (cd.tarifario_id = td.tarifario_id AND cd.cargo = td.cargo)
INNER JOIN tarifarios ta ON (cd.tarifario_id = ta.tarifario_id)
LEFT JOIN cups cu ON (cd.cargo_cups = cu.cargo)
INNER JOIN departamentos dp ON (cd.departamento = dp.departamento)
LEFT JOIN bodegas_documentos_d bd ON (cd.consecutivo = bd.consecutivo)
INNER JOIN servicios ser ON (cd.servicio_cargo = ser.servicio)
LEFT JOIN inventarios_productos ip ON (bd.codigo_producto = ip.codigo_producto)
LEFT JOIN medicamentos med ON (med.codigo_medicamento = ip.codigo_producto)
LEFT JOIN ingresos_salidas ins ON (ins.ingreso = i.ingreso)
LEFT JOIN (select TO_CHAR(max(fecha),'DD/MM/YYYY') AS fecha_egreso, ingreso FROM hc_evoluciones GROUP BY ingreso) AS he ON (he.ingreso = i.ingreso)
LEFT JOIN system_usuarios su ON (su.usuario_id = cd.usuario_id)
LEFT JOIN cuentas_cargos_qx_procedimientos ccqx ON (cd.transaccion = ccqx.transaccion)
LEFT JOIN cuentas_liquidaciones_qx_procedimientos clqx ON ( ccqx.consecutivo_procedimiento = clqx.consecutivo_procedimiento )
LEFT JOIN cups cuqx ON (cuqx.cargo = clqx.cargo_cups)
INNER JOIN empresas em ON (c.empresa_id = em.empresa_id)
WHERE 
pl.plan_id IN (342,341)
AND ff.estado != '3'
--AND c.estado != '5'
AND i.fecha_registro::DATE BETWEEN _1 AND _2
