Select su.nombre AS nombre_solicita
,ee.descripcion AS estacion
,ds.tipo_cama_id
,ds.ingreso_id
,p.tipo_id_paciente
,p.paciente_id
,p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS nombre_paciente
,dt.descripcion_solicitud AS tipo_de_solicitud
,td.descripcion AS tipo_dieta
,d.fecha_confirmacion::date AS fecha
,d.fecha_confirmacion::time AS hora
From dietas_solicitud_detalle AS ds
INNER JOIN ingresos AS i ON ds.ingreso_id=i.ingreso -- se hace la union con ingreso por que de ds va  ingreso y de ingreso a pacientes
INNER JOIN pacientes AS p ON i.paciente_id=p.paciente_id AND i.tipo_id_paciente=p.tipo_id_paciente -- pacientes se unde con ingreso
INNER JOIN system_usuarios AS su ON ds.usuario_id_registro=su.usuario_id
INNER JOIN estaciones_enfermeria AS ee ON ds.estacion_id=ee.estacion_id
INNER JOIN dietas_tipos_solicitud AS dt ON ds.tipo_solicitud_dieta_id=dt.tipo_solicitud_dieta_id
INNER JOIN hc_tipos_dieta AS td ON ds.hc_dieta_id=td.hc_dieta_id
INNER JOIN dietas_solicitud AS d ON ds.ingreso_id=d.ingreso_id
WHERE d.fecha_confirmacion::DATE BETWEEN '2019-11-20' AND '2019-12-08'
ORDER BY (d.fecha_confirmacion) DESC