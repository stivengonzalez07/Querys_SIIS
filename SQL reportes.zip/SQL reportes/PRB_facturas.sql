
SELECT
FF.fecha_registro
,FF.prefijo
,FF.factura_fiscal
,FF.total_factura
,FF.saldo
,FF.tipo_factura
,FF.estado_factura
,(FF.total_factura
- FF.nota_credito
- FF.nota_credito_anulacion
+ FF.nota_debito
- FF.nota_credito_glosa
- FF.nota_credito_ajuste
- FF.conciliacion
- FF.abono
+ FF.abono_anulado) AS saldo_reconstruido
,FF.nota_credito
,FF.nota_credito_anulacion
,FF.nota_debito
,FF.nota_credito_glosa
,FF.nota_credito_ajuste
,FF.conciliacion
,FF.abono
,FF.abono_anulado
FROM
(
SELECT
FF.fecha_registro
,FF.prefijo
,FF.factura_fiscal
,FF.total_factura
,CASE WHEN FF.tipo_factura = '0' THEN 'PACIENTE'
WHEN FF.tipo_factura = '1' THEN 'CLIENTE'
WHEN FF.tipo_factura = '2' THEN 'PARTICULAR'
WHEN FF.tipo_factura = '3' THEN 'AGRUPADA CAPITACION'
WHEN FF.tipo_factura = '4' THEN 'AGRUPADA NO CAPITACION'
WHEN FF.tipo_factura = '5' THEN 'CONCEPTOS'
ELSE 'PRODUCTOS INVENTARIOS' END AS tipo_factura
,CASE WHEN FF.estado = '0' THEN 'ACTIVA'
WHEN FF.tipo_factura = '1' THEN 'PAGADA'
ELSE 'ANULADA' END AS estado_factura
,FF.saldo
,COALESCE((SELECT SUM(NC.valor_nota) FROM nc_credito NC WHERE NC.prefijo_factura = FF.prefijo AND NC.factura_fiscal = FF.factura_fiscal), 0) AS nota_credito
,COALESCE((SELECT SUM(NC.valor_anulacion) FROM nc_anulacion NC WHERE NC.prefijo_factura = FF.prefijo AND NC.factura_fiscal = FF.factura_fiscal), 0) AS nota_credito_anulacion
,COALESCE((SELECT SUM(NC.valor_nota_d) FROM nd_debito NC WHERE NC.prefijo_factura = FF.prefijo AND NC.factura_fiscal = FF.factura_fiscal), 0) AS nota_debito
,COALESCE((SELECT SUM(NC.valor_nc_glosa) FROM nc_glosa NC WHERE NC.prefijo_factura = FF.prefijo AND NC.factura_fiscal = FF.factura_fiscal), 0) AS nota_credito_glosa
,COALESCE((SELECT SUM(NC.valor_nc_ajuste) FROM nc_ajuste NC WHERE NC.prefijo_factura = FF.prefijo AND NC.factura_fiscal = FF.factura_fiscal), 0) AS nota_credito_ajuste
,COALESCE((SELECT SUM(NC.valor_aceptado) FROM conciliacion NC WHERE NC.prefijo = FF.prefijo AND NC.factura_fiscal = FF.factura_fiscal),0) AS conciliacion
,COALESCE((SELECT SUM(NC.valor_abono) FROM rc_abono NC WHERE NC.prefijo_factura = FF.prefijo AND NC.factura_fiscal = FF.factura_fiscal), 0) AS abono
,COALESCE((SELECT SUM(NC.valor_anulado_abono) FROM rc_abono_anulado NC WHERE NC.prefijo_factura = FF.prefijo AND NC.factura_fiscal = FF.factura_fiscal), 0) AS abono_anulado
,(SELECT ED.fecha_radicacion FROM numero_envio ED WHERE (FF.prefijo = ED.prefijo AND FF.factura_fiscal = ED.factura_fiscal)) AS fecha_radicacion
,(SELECT ED.envio_id FROM numero_envio ED WHERE (FF.prefijo = ED.prefijo AND FF.factura_fiscal = ED.factura_fiscal)) AS fecha_radicacion
,(SELECT ED.sw_estado FROM numero_envio ED WHERE (FF.prefijo = ED.prefijo AND FF.factura_fiscal = ED.factura_fiscal)) AS fecha_radicacion

FROM fac_facturas FF
--LEFT JOIN numero_envio ED ON (FF.prefijo = ED.prefijo AND FF.factura_fiscal = ED.factura_fiscal)
ORDER BY 1
) AS FF