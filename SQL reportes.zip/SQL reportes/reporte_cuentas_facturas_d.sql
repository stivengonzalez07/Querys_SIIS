SELECT
cu.numerodecuenta, 
ce.descripcion AS cuenta_estado,
pl.plan_descripcion,
cu.fecha_registro as fecha_cuenta,
cu.ingreso,
p.tipo_id_paciente||' '||p.paciente_id AS paciente_id,
p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||
p.segundo_nombre AS nombre_paciente,
ffc.prefijo,
ffc.factura_fiscal,
CASE WHEN ff.estado = '0' THEN 'ACTIVA'
     WHEN ff.estado = '1' THEN 'PAGADA'
     WHEN ff.estado = '2' THEN 'AGRUPADA ANULADA'
     WHEN ff.estado = '3' THEN 'ANULADA'
     ELSE 'SIN ESTADO' END AS estado_factura,
ff.fecha_registro AS fecha_factura,
e.envio_id,
e.fecha_radicacion
FROM cuentas cu
LEFT JOIN fac_facturas_cuentas ffc ON (cu.numerodecuenta = ffc.numerodecuenta)
LEFT JOIN fac_facturas ff ON (ffc.prefijo=ff.prefijo AND ffc.factura_fiscal=ff.factura_fiscal)
LEFT JOIN ingresos i ON (cu.ingreso=i.ingreso)
LEFT JOIN pacientes p ON ( i.paciente_id=p.paciente_id )
LEFT JOIN cuentas_estados ce ON ( cu.estado = ce.estado )   
LEFT JOIN planes pl ON ( cu.plan_id = pl.plan_id )
LEFT JOIN envios_detalle ed ON (ff.prefijo=ed.prefijo AND ff.factura_fiscal=ed.factura_fiscal )
LEFT JOIN envios e ON (ed.envio_id=e.envio_id)
WHERE
cu.fecha_registro::date BETWEEN _1 AND _2
--'2016-09-01' AND '2021-11-09'