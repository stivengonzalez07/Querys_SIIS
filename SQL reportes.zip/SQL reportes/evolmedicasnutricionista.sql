select b.tipo_id_paciente,b.paciente_id,f.fecha_registro,e.plan_descripcion,c.descripcion 

from hc_evoluciones a, ingresos b, departamentos c, cuentas d, 
planes e, hc_evolucion_descripcion f 
where a.ingreso=b.ingreso 
and a.departamento=c.departamento 
and a.numerodecuenta=d.numerodecuenta 
and d.plan_id=e.plan_id 
and a.evolucion_id=f.evolucion_id 
and f.fecha_registro::date BETWEEN _1 AND _2 

order by f.fecha_registro asc