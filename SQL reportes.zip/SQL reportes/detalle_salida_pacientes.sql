SELECT 	i.ingreso, 
c.numerodecuenta, 
p.tipo_id_paciente||' '|| p.paciente_id AS paciente_id,
p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS paciente,
p.residencia_telefono as Telefono,
pl.plan_descripcion,
s.evento,
to_char(i.fecha_ingreso, 'dd/mm/YYYY') as fecha_ingreso,
to_char(i.fecha_ingreso, 'hh:mi:ss' ) as hora_ingreso,
dpt.descripcion AS departamento_ingreso,
eb.tipo_diagnostico_id as dx_egreso,
eb.diagnostico_nombre,
to_char(sal.fecha_registro, 'dd/mm/YYYY') AS fecha_egreso,
to_char(sal.fecha_registro, 'HH24:MI:SS') AS hora_egreso,
dept.descripcion AS departamento_egreso
FROM ingresos i
INNER JOIN pacientes p ON (i.paciente_id=p.paciente_id AND i.tipo_id_paciente=p.tipo_id_paciente)
INNER JOIN (select	min(numerodecuenta) as cuenta,ingreso from cuentas where estado!='5' group by 2) ab ON (ab.ingreso=i.ingreso)
INNER JOIN cuentas c ON (ab.cuenta=c.numerodecuenta)
INNER JOIN planes pl ON (c.plan_id=pl.plan_id)
LEFT JOIN ingresos_soat s ON (i.ingreso=s.ingreso)
INNER JOIN ingresos_salidas sal ON (i.ingreso=sal.ingreso)
LEFT JOIN (select dx.tipo_diagnostico_id, d.diagnostico_nombre, he.ingreso, dx.evolucion_id 
  from hc_diagnosticos_egreso dx, hc_evoluciones he, diagnosticos d
  where he.evolucion_id=dx.evolucion_id and dx.tipo_diagnostico_id=d.diagnostico_id 
  and dx.sw_principal='1') as eb ON (eb.ingreso=i.ingreso)
INNER JOIN departamentos dpt ON (i.departamento = dpt.departamento)
INNER JOIN departamentos dept ON (sal.departamento_egreso = dept.departamento)
WHERE sal.fecha_registro::date BETWEEN _1 AND _2
ORDER BY 1

