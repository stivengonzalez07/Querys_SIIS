select 
i.prefijo,
i.numero,
id.bodega,
d.descripcion AS departamento,
id.grupo_id,
id.clase_id,
id.subclase_id,
id.codigo_producto,
id.cantidad,
id.devolucion,
id.costo_cargos,
id.costo_devoluciones,
id.cantidad_total,
id.costo_total,
id.porcentaje_iva,
i.fecha_documento,
i.fecha_registro

from 
inv_bodegas_movimiento_costo_por_lapso_d id,
inv_bodegas_movimiento_costo_por_lapso i,
departamentos d

where id.prefijo=i.prefijo and 
id.numero=i.numero and
id.departamento=d.departamento and
--i.fecha_documento between '2016-09-01'and '2017-05-30'
i.fecha_documento between _1 and _2

