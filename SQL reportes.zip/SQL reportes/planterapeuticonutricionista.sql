SELECT b.tipo_id_paciente,
b.paciente_id,
a.fecha_registro,
e.plan_descripcion,
c.descripcion as departamento, a.evolucion_id
FROM hc_evoluciones a, ingresos b, departamentos c, cuentas d, planes e, hc_plan_terapeutico f, profesionales p, profesionales_especialidades pe
WHERE a.ingreso=b.ingreso
AND a.departamento=c.departamento 
AND a.numerodecuenta=d.numerodecuenta 
AND d.plan_id=e.plan_id 
AND a.evolucion_id=f.evolucion_id
AND a.usuario_id = p.usuario_id
AND p.tercero_id = pe.tercero_id
AND pe.especialidad = '025'
AND a.fecha_registro::date BETWEEN _1 AND _2
order by a.fecha_registro asc
