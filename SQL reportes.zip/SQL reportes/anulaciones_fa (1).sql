select a.prefijo,a.nota_credito_id,a.prefijo_factura,a.factura_fiscal,a.valor_nota,b.observacion,a.fecha_registro from notas_credito_anulacion_facturas a, 
auditoria_anulacion_fac_facturas b where a.prefijo_factura=b.prefijo and a.factura_fiscal=b.factura_fiscal and a.fecha_registro::date BETWEEN _1 AND _2 order by
a.fecha_registro asc
