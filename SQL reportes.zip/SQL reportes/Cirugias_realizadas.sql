SELECT cl.fecha_cirugia::date,i.tipo_id_paciente, i.paciente_id, 
p.primer_nombre, p.segundo_nombre, p.primer_apellido, p.segundo_apellido, 
ts.descripcion as Sexo_paciente,
p.fecha_nacimiento,
edad(p.fecha_nacimiento) as edad,
pl.plan_descripcion,
c.descripcion as cargo,
a.descripcion as ambito
FROM ingresos i,pacientes p,qx_ambitos_cirugias a,cuentas_liquidaciones_qx cl,cups c
,cuentas cu , tipo_sexo ts, planes pl
WHERE i.tipo_id_paciente=p.tipo_id_paciente
AND i.paciente_id=p.paciente_id
AND ts.sexo_id = p.sexo_id
AND i.ingreso=cl.ingreso
AND cl.estado!='3'
AND cl.ambito_cirugia_id=a.ambito_cirugia_id
AND cl.numerodecuenta = cu.numerodecuenta
AND cl.cargo_principal=c.cargo
AND cu.plan_id = pl.plan_id
AND cl.fecha_cirugia::date>=_1
AND cl.fecha_cirugia::date<=_2
ORDER BY 1