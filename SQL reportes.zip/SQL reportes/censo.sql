SELECT

C.numerodecuenta
,I.ingreso
,P.tipo_id_paciente AS tipo_identificacion
,P.paciente_id  AS documento
,P.primer_nombre
,P.segundo_nombre
,P.primer_apellido
,P.segundo_apellido
,TA.tipo_afiliado_nombre AS afliciacion
,I.fecha_ingreso
,I.departamento
,D.descripcion AS departamento_ingreso
,I.departamento_actual
,DA.descripcion AS departamento_actual
,PL.plan_descripcion AS plan
,CE.descripcion AS estado_cuenta
,CEE.descripcion AS estado_ingreso
,S.fecha_registro AS fecha_egreso
,MH.cama
,c.total_cuenta



,CASE WHEN S.fecha_registro IS NULL THEN date_part('days', now() - I.fecha_ingreso )
  ELSE   date_part('days', S.fecha_registro - I.fecha_ingreso ) END AS dias_hospitalizados

FROM
cuentas C
INNER JOIN ingresos I ON C.ingreso = I.ingreso
INNER JOIN pacientes P ON I.paciente_id = P.paciente_id
INNER JOIN tipos_afiliado TA ON C.tipo_afiliado_id = TA.tipo_afiliado_id
INNER JOIN planes PL ON C.plan_id = PL.plan_id
LEFT JOIN ingresos_salidas S ON I.ingreso = S.ingreso
INNER JOIN cuentas_estados CE ON C.estado = CE.estado
INNER JOIN cuentas_estados CEE ON I.estado = CEE.estado
INNER JOIN departamentos D ON I.departamento = D.departamento
INNER JOIN departamentos DA ON I.departamento_actual = DA.departamento
INNER JOIN movimientos_habitacion MH ON MH.ingreso = I.ingreso


WHERE
MH.fecha_egreso is NULL
AND C.estado IN('0','1','3')
AND I.estado='1'

--AND I.fecha_ingreso BETWEEN _1 AND _2
--AND I.fecha_ingreso BETWEEN '2020-01-01' AND '2020-05-20'

