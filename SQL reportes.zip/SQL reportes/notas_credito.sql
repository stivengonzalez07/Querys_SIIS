select a.prefijo,a.nota_credito_id,a.prefijo_factura,
a.factura_fiscal,a.valor_nota,a.tipo_id_tercero,
a.tercero_id,b.nombre_tercero,
case when a.estado='0' then 
'ANULADA' when a.estado='1' then 'ACTIVA' end as Estado,
d.descripcion as Concepto,a.fecha_registro,
a.observacion 
from notas_credito a, terceros b, 
notas_credito_detalle_conceptos c,
notas_credito_ajuste_conceptos d 
where a.tercero_id=b.tercero_id 
and a.tipo_id_tercero=b.tipo_id_tercero 
and a.nota_credito_id=c.nota_credito_id 
and c.concepto_id=d.concepto_id and a.fecha_registro::date  
between _1 AND _2
