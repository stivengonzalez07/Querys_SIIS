SELECT DISTINCT tf.toma_fisica_id, 
tf.bodega, 
tf.descripcion, 
tf.fecha_inicio, 
tfd.codigo_producto, 
tdi.existencia,
tdi.costo

FROM inv_toma_fisica tf,
inv_toma_fisica_d tfd,
inv_toma_fisica_detalle_inicial tdi

WHERE tf.toma_fisica_id = tfd.toma_fisica_id
AND tfd.toma_fisica_id = tdi.toma_fisica_id
AND tfd.codigo_producto = tdi.codigo_producto
AND existencia != 0
AND tf.fecha_inicio::date BETWEEN _1 AND _2 

GROUP BY 1,2,3,4,5,6,7
ORDER BY 1
