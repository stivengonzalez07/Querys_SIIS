--INGRESOS POR COMPRA E INICIAL DE INVENTARIOS ALMACEN
SELECT DISTINCT
invr.numero_remision,
invm.fecha_registro::date AS fecha_documento, 
invm.prefijo||' '||invm.numero AS num_documento,
invm.observacion,
invcd.documento_compra AS factura_prov, 
t.nombre_tercero AS proveedor_compra, 
tr.nombre_tercero AS proveedor_consigna, b.descripcion AS bodega_destino, 
ip.codigo_producto, ip.descripcion AS producto, 
ip.codigo_invima,
ip.referencia,
invmd.cantidad, invmd.total_costo ,
invmd.fecha_vencimiento, 
invmd.lote, 
su.nombre AS usuario_registro
FROM
--inv_bodegas_movimiento_traslados invt
inv_bodegas_movimiento invm 
INNER JOIN inv_bodegas_movimiento_d invmd ON invm.prefijo=invmd.prefijo AND invm.numero=invmd.numero
INNER JOIN inventarios_productos ip ON invmd.codigo_producto=ip.codigo_producto
INNER JOIN inv_bodegas_documentos invd ON invm.documento_id=invd.documento_id
INNER JOIN bodegas b ON invm.bodega=b.bodega
LEFT OUTER JOIN inv_bodegas_movimiento_compras_directas invcd ON invm.prefijo=invcd.prefijo AND invm.numero=invcd.numero
LEFT OUTER JOIN terceros t ON invcd.tipo_id_tercero=t.tipo_id_tercero AND invcd.tercero_id=t.tercero_id
LEFT OUTER JOIN inv_bodegas_movimiento_ig_remision invr ON invm.prefijo=invr.prefijo AND invm.numero=invr.numero
LEFT OUTER JOIN terceros tr ON invr.tipo_id_tercero=tr.tipo_id_tercero AND invr.tercero_id=tr.tercero_id
INNER JOIN system_usuarios su ON invm.usuario_id=su.usuario_id
WHERE 
invd.documento_id IN ('17','20', '18', '19')
AND invd.bodega='BP'
AND invm.fecha_registro::date BETWEEN _1 AND _2

