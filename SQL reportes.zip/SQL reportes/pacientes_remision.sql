SELECT 
pr.paciente_remitido_id, pr.tipo_id_paciente, 
pr.paciente_id, p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido as nombre,
pr.centro_remision, cr.descripcion, pr.numero_remision, pr.diagnostico_id, d.diagnostico_nombre, pr.fecha_remision, 
pr.hora_remision, pr.observacion, pr.fecha_registro, pr.usuario_id as usuario_remite, su.nombre,  pr.triage_id, pr.ingreso
FROM pacientes_remitidos pr
INNER JOIN pacientes p ON p.paciente_id=pr.paciente_id
INNER JOIN diagnosticos d ON pr.diagnostico_id=d.diagnostico_id
INNER JOIN centros_remision cr ON pr.centro_remision=cr.centro_remision
INNER JOIN system_usuarios su ON pr.usuario_id=su.usuario_id
WHERE pr.fecha_registro::DATE BETWEEN _1 AND _2
ORDER BY pr.fecha_registro

