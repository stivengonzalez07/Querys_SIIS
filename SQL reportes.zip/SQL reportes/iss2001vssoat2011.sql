SELECT 
td.cargo AS cod_tarifario, 
c.cargo AS cod_cups, 
c.descripcion AS descripcion_cups, 
t.descripcion AS tarifario, 
td.precio,
CASE
WHEN td.tipo_unidad_id = '01' THEN 'PESOS'
WHEN td.tipo_unidad_id = '02' THEN 'UVRS PARA DERECHOS'
WHEN td.tipo_unidad_id = '03' THEN 'SMMLV'
WHEN td.tipo_unidad_id = '04' THEN 'GRUPOS QX SOAT'
WHEN td.tipo_unidad_id = '05' THEN 'UVRS PARA PAQUETES'
WHEN td.tipo_unidad_id = '06' THEN 'PESOS X MIN'
ELSE 'PESOS X HORA' END AS unidad_valor
FROM 
tarifarios_equivalencias te
INNER JOIN cups c ON c.cargo=te.cargo_base
INNER JOIN tarifarios t ON t.tarifario_id=te.tarifario_id
INNER JOIN tarifarios_detalle td ON td.cargo=te.cargo
WHERE td.tarifario_id IN ('0002')