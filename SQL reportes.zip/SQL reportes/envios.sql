SELECT e.envio_id as envio,e.fecha_registro as fecha,p.plan_descripcion, 
CASE WHEN e.sw_estado='0' THEN 'ACTIVO'
     WHEN e.sw_estado='1' THEN 'RADICADO'
     WHEN e.sw_estado='2' THEN 'ANULADO'
     WHEN e.sw_estado='3' THEN 'DESPACHADO'
END
AS estado
FROM envios e,planes p,envios_planes ep
WHERE e.envio_id=ep.envio_id
AND ep.plan_id=p.plan_id
AND e.fecha_registro>=_1
AND e.fecha_registro<=_2
ORDER BY 1