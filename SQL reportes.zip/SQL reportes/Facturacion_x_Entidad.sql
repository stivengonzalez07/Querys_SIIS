SELECT         t.nombre_tercero,
               SUM(CD.valor_cargo::integer) as valor
FROM         fac_facturas a,
               fac_facturas_cuentas f,
               cuentas b,
               cuentas_detalle CD,
               departamentos DE,
               documentos as dc,
               terceros t
WHERE         f.empresa_id=a.empresa_id
AND         t.tercero_id=a.tercero_id
AND         dc.documento_id=3
AND         b.estado<>'5'
AND         dc.prefijo =a.prefijo
AND         f.prefijo=a.prefijo
AND         f.factura_fiscal=a.factura_fiscal
AND         b.numerodecuenta=f.numerodecuenta
AND                CD.numerodecuenta = b.numerodecuenta
AND                DE.departamento = CD.departamento
--AND         a.sw_clase_factura='1'
AND         a.tipo_factura='1'
AND         a.estado NOT IN ('2','3')
AND         a.fecha_registro::date >=_1
AND         a.fecha_registro::date <=_2
GROUP BY t.nombre_tercero
ORDER BY t.nombre_tercero