SELECT p.tipo_id_paciente, p.paciente_id, p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS nombre_paciente
,p.fecha_nacimiento::date
,p.residencia_direccion
,p.residencia_telefono
,mpio.municipio
,dpto.departamento
,pl.plan_descripcion
,d.descripcion as Departamento_cita
,aca.fecha_registro::date AS fecha_registro_cita 
,agt.fecha_turno AS fecha_asignacion_cita
,aca.fecha_deseada AS fecha_deseada_usuario
,sy.nombre AS Usuario_asigno_cita
,CASE WHEN om.fecha_cumplimiento IS NOT NULL THEN 'SI' ELSE 'NO' END AS cita_cumplida 
,CASE WHEN acc.fecha_registro IS NOT NULL THEN 'SI' ELSE 'NO' END AS cita_cancelada 
,acc.fecha_registro::date AS fecha_cancelacion 
,tca.descripcion AS motivo_cancelacion
,om.fecha_cumplimiento::date 
,aca.cargo_cita 
,c.descripcion
,tci.descripcion AS tipo_cita
,tco.descripcion AS especialidad
,pr.nombre AS especialista
,ac.sw_estado
,aca.ultima_cirugia
FROM agenda_citas_asignadas aca
INNER JOIN agenda_citas ac ON ac.agenda_cita_id=aca.agenda_cita_id
INNER JOIN agenda_turnos agt ON agt.agenda_turno_id=ac.agenda_turno_id
INNER JOIN tipos_cita tci ON tci.tipo_cita=aca.tipo_cita
INNER JOIN tipos_consulta tco ON tco.tipo_consulta_id=agt.tipo_consulta_id
INNER JOIN departamentos d ON tco.departamento=d.departamento
INNER JOIN profesionales pr ON pr.tipo_id_tercero=agt.tipo_id_profesional AND pr.tercero_id=agt.profesional_id
INNER JOIN pacientes p ON p.paciente_id=aca.paciente_id AND p.tipo_id_paciente=p.tipo_id_paciente
INNER JOIN os_cruce_citas osc ON osc.agenda_cita_asignada_id=aca.agenda_cita_asignada_id
INNER JOIN os_maestro om ON om.numero_orden_id=osc.numero_orden_id
INNER JOIN planes pl ON pl.plan_id=aca.plan_id
INNER JOIN system_usuarios sy ON sy.usuario_id=agt.usuario_id
INNER JOIN cups c ON c.cargo=aca.cargo_cita
INNER JOIN tipo_mpios mpio ON mpio.tipo_mpio_id=p.tipo_mpio_id
INNER JOIN tipo_dptos dpto ON dpto.tipo_dpto_id=mpio.tipo_dpto_id AND dpto.tipo_dpto_id=p.tipo_dpto_id
INNER JOIN tipo_pais pais ON pais.tipo_pais_id=mpio.tipo_pais_id AND pais.tipo_pais_id=p.tipo_pais_id
LEFT JOIN agenda_citas_asignadas_cancelacion acc ON acc.agenda_cita_asignada_id=aca.agenda_cita_asignada_id
LEFT JOIN tipos_cancelacion tca ON tca.tipo_cancelacion_id=acc.tipo_cancelacion_id
WHERE tco.departamento IN('CEXTER','ATEDOM','REHABI')
AND agt.fecha_turno::DATE BETWEEN _1 AND _2
