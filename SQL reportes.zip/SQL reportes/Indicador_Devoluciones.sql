select x.descripcion,x.estado_case as estado,sum(x.contador) as cantidad from (select 
hsd.documento,
igi.descripcion,
hsd.estado,
case when hsd.estado = '0' then 'Pendiente'
when hsd.estado = '1' then 'Aceptado'
else 'Cancelado' end as estado_case,
count(hsd.documento)/count(hsd.documento) as contador
from inv_solicitudes_devolucion as hsd
inner join inv_solicitudes_devolucion_d as isdd ON isdd.documento = hsd.documento
inner join inventarios_productos as ip ON ip.codigo_producto = isdd.codigo_producto
inner join inv_subclases_inventarios as isi ON ip.grupo_id = isi.grupo_id and ip.clase_id = isi.clase_id and ip.subclase_id = isi.subclase_id
inner join inv_clases_inventarios as ici ON ici.grupo_id = isi.grupo_id
inner join inv_grupos_inventarios as igi ON igi.grupo_id = ici.grupo_id
where hsd.fecha::date between _1 and _2

--to_date(hsd.fecha, 'YYYY-MM-DD') between _1 and _2
and bodega IN ('BF')
group by 1,2,3) as x
group by 1,2
order by 1,2
