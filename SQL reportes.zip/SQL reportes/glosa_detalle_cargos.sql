SELECT
g.prefijo_glosa ||' '|| g.numero AS Prefijo_y_numero_glosa, 
g.prefijo ||' '|| g.factura_fiscal AS factura, 
ff.fecha_registro as fecha_factura,
g.glosa_id,
p.tipo_id_paciente ||' '|| p.paciente_id AS id_paciente,
c.numerodecuenta,
i.ingreso, 
t.nombre_tercero AS entidad,
g.fecha_glosa, g.fecha_registro::date, 
gtc.descripcion AS Clasificacion_Glosa, 
g.codigo_concepto_general AS cod_concepto_gral, 
gcg.descripcion_concepto_general AS concepto_general,  
g.codigo_concepto_especifico AS cod_concepto_especifico, 
gce.descripcion_concepto_especifico AS concepto_especifico, 
CASE WHEN g.sw_estado= '0' THEN 'ANULADA'
     WHEN g.sw_estado='1' THEN 'SIN RESPUESTA'
     WHEN g.sw_estado= '2' THEN 'CON RESPUESTA'
     WHEN g.sw_estado= '3' THEN 'CERRADA'
     WHEN g.sw_estado= '4' THEN 'RATIFICADA'
     END AS estado_glosa, 
ff.total_factura, 
su.nombre AS usuario_factura,
g.valor_glosa, 
ips.valor_aceptado AS valor_aceptado_ips,
eps.valor_aceptado AS valor_aceptado_eps,
cd.cargo, 
cd.cargo_cups, 
cd.fecha_cargo, 
gdc.valor_glosa as valor_glosa_cargo,
td.descripcion,
ccq.cargo as cargo_qx,
tdd.descripcion as descripcion_cargo_qx,
gdc.codigo_concepto_general AS cod_concepto_gral, 
cg.descripcion_concepto_general AS concepto_general,  
gdc.codigo_concepto_especifico AS cod_concepto_especifico, 
ce.descripcion_concepto_especifico AS concepto_especifico
FROM
glosas g
INNER JOIN glosas_detalle_cargos gdc ON g.glosa_id=gdc.glosa_id  
LEFT  JOIN (SELECT g.glosa_id, SUM(gr.valor_aceptado) as valor_aceptado FROM glosas g, glosas_respuestas gr
WHERE g.glosa_id=gr.glosa_id GROUP BY 1) ips ON g.glosa_id=ips.glosa_id
LEFT  JOIN (SELECT g.glosa_id, SUM(gre.valor_aceptado) as valor_aceptado FROM glosas g, glosas_respuestas_eps gre
WHERE g.glosa_id=gre.glosa_id GROUP BY 1) eps ON g.glosa_id=eps.glosa_id
LEFT OUTER JOIN cuentas_detalle cd ON gdc.transaccion=cd.transaccion
LEFT OUTER JOIN tarifarios_detalle td ON cd.tarifario_id=td.tarifario_id and cd.cargo=td.cargo 
LEFT OUTER JOIN fac_facturas ff ON ff.factura_fiscal=g.factura_fiscal and ff.prefijo=g.prefijo
LEFT OUTER JOIN fac_facturas_cuentas ffc ON ffc.factura_fiscal=ff.factura_fiscal and ffc.prefijo=ff.prefijo and ffc.empresa_id=ff.empresa_id 
LEFT OUTER JOIN cuentas c ON c.numerodecuenta=ffc.numerodecuenta
LEFT OUTER JOIN terceros t ON ff.tipo_id_tercero=t.tipo_id_tercero AND ff.tercero_id=t.tercero_id AND t.tipo_id_tercero IN ('NI','NIT')
LEFT OUTER JOIN ingresos i ON i.ingreso=c.ingreso
LEFT OUTER JOIN pacientes p ON p.paciente_id=i.paciente_id AND p.tipo_id_paciente=i.tipo_id_paciente
LEFT OUTER JOIN glosas_tipos_clasificacion gtc ON gtc.glosa_tipo_clasificacion_id=g.glosa_tipo_clasificacion_id
LEFT OUTER JOIN glosas_concepto_general gcg ON gcg.codigo_concepto_general=g.codigo_concepto_general
LEFT OUTER JOIN glosas_concepto_especifico gce ON gce.codigo_concepto_especifico=g.codigo_concepto_especifico
LEFT OUTER JOIN cuentas_cargos_qx_procedimientos ccq ON gdc.transaccion=ccq.transaccion
LEFT OUTER JOIN tarifarios_detalle tdd ON ccq.tarifario_id=tdd.tarifario_id and ccq.cargo=tdd.cargo  
LEFT OUTER JOIN glosas_concepto_general cg ON cg.codigo_concepto_general=gdc.codigo_concepto_general
LEFT OUTER JOIN glosas_concepto_especifico ce ON ce.codigo_concepto_especifico=gdc.codigo_concepto_especifico
INNER JOIN system_usuarios su ON su.usuario_id=ff.usuario_id
WHERE g.sw_estado != '0'
AND g.fecha_glosa BETWEEN _1 AND _2
ORDER BY 1,2

