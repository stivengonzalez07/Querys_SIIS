SELECT SUM(e.existencia_actual) AS Existencia_Total_Productos,
e.codigo_producto AS codigo_producto,
ip.descripcion AS Nombre_producto

FROM
 inventarios_productos ip, existencias_bodegas_lote_fv e, bodegas bo

 WHERE e.bodega = bo.bodega
 AND ip.codigo_producto=e.codigo_producto
 AND bo.descripcion like '%FARMACIA%'
 
 --AND ip.fecha_registro::date BETWEEN '2017-01-01' AND '2021-09-01'
 --AND ip.fecha_registro::date BETWEEN _1 AND _2

 GROUP BY e.codigo_producto,ip.descripcion