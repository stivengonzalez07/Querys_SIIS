SELECT
hs.hc_os_solicitud_id,
c.descripcion,
hs.evolucion_id,
p.plan_descripcion,
hs.os_tipo_solicitud_id,
su.nombre AS nombre_medico,
hs.paciente_id,
hs.tipo_id_paciente,
s.descripcion,
hs.fecha_solicitud
FROM 
hc_os_solicitudes hs
INNER JOIN hc_os_solicitudes_interconsultas hci ON hs.hc_os_solicitud_id=hci.hc_os_solicitud_id
INNER JOIN hc_evoluciones h ON hs.evolucion_id=h.evolucion_id
INNER JOIN cups c ON hs.cargo = c.cargo
INNER JOIN planes p ON hs.plan_id=p.plan_id
INNER JOIN servicios s ON hs.servicio=s.servicio
INNER JOIN system_usuarios su ON h.usuario_id=su.usuario_id

WHERE hs.os_tipo_solicitud_id = 'INT'
AND HS.fecha_solicitud::date BETWEEN _1 AND _2
--BETWEEN '2021-09-07 08:31:09' AND '2021-09-08 10:45:16'