SELECT DISTINCT (fsm.suministro_id),
fsm.fecha_realizado as fecha,
p.primer_apellido || ' '|| p.segundo_apellido || ' ' || p.primer_nombre || ' ' || p.segundo_nombre as Nombre_Paciente,
p.tipo_id_paciente as tipo_Identificacion,
p.paciente_id as Identificacion,
pl.plan_descripcion as Plan,
di.tipo_diagnostico_id as Diagnostico,
ip.codigo_producto,
ip.sw_pos,
ip.pos_nopos,
ip.descripcion as Descripcion,
u.descripcion as Unidad_medida,
fsm.cantidad_suministrada
-- ,
-- pr.nombre as Nombre_Medico,
-- he.ingreso,
-- pr.registro_medico

FROM
hc_formulacion_suministro_medicamentos fsm
--JOIN hc_formulacion_medicamentos_eventos fme ON ( fsm.num_reg_formulacion = fme.num_reg ) --NUEVO
JOIN ingresos ig ON ( fsm.ingreso = ig.ingreso )
JOIN pacientes p ON ( ig.paciente_id = p.paciente_id AND ig.tipo_id_paciente = p.tipo_id_paciente )
JOIN cuentas c ON ( ig.ingreso = c.ingreso )
JOIN planes pl ON ( c.plan_id = pl.plan_id )
JOIN hc_evoluciones he ON ( ig.ingreso = he.ingreso )
JOIN hc_diagnosticos_ingreso di ON ( he.evolucion_id = di.evolucion_id )
JOIN inventarios_productos ip ON ( fsm.codigo_producto = ip.codigo_producto )
JOIN unidades u ON ( ip.unidad_id = u.unidad_id )
--LEFT JOIN profesionales pr ON ( fme.usuario_id = pr.usuario_id )

WHERE
--AND fme.usuario_id = pr.usuario_id
di.sw_principal = '1'
--AND m.sw_pos='0'
AND fsm.fecha_realizado BETWEEN _1 AND _2

--AND fsm.fecha_realizado BETWEEN '2022-02-18' AND '2022-02-18'
order by ip.codigo_producto