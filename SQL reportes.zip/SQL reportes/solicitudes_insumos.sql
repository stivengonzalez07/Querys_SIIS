SELECT hsm.solicitud_id, 
hsm.ingreso, 
i.tipo_id_paciente,
i.paciente_id,
CONCAT( p.primer_apellido, ' ', p.segundo_apellido,' ', p.primer_nombre, ' ',p.segundo_nombre) AS nombre,
hsm.bodega, 
su.nombre as usuario_solicita,
su.descripcion as especialidad, 
hsm.fecha_solicitud,
ee.descripcion as estacion, 
hsm.tipo_solicitud,
hsmd.codigo_producto,
ip.descripcion,
hsmd.cantidad,
CASE WHEN hsm.sw_estado = '0' THEN 'SIN DESPACHO'
     WHEN hsm.sw_estado = '1' THEN 'DESPACHADO'
     WHEN hsm.sw_estado = '2' THEN 'RECIBIDO'
     WHEN hsm.sw_estado = '3' THEN 'CANCELADO'
	 WHEN hsm.sw_estado = '4' THEN 'CONSUMO DIRECTO'
     WHEN hsm.sw_estado = '5' THEN 'RECIBIDO PARCIAL'
     ELSE 'CANCELADO ESTACION' END AS estado
FROM hc_solicitudes_medicamentos as hsm
INNER JOIN system_usuarios su ON hsm.usuario_id=su.usuario_id
INNER JOIN hc_solicitudes_insumos_d hsmd ON hsm.solicitud_id=hsmd.solicitud_id
INNER JOIN inventarios_productos ip ON hsmd.codigo_producto=ip.codigo_producto
INNER JOIN estaciones_enfermeria ee ON hsm.estacion_id=ee.estacion_id
INNER JOIN ingresos i ON  i.ingreso=hsm.ingreso
INNER JOIN pacientes p ON  i.paciente_id=p.paciente_id and i.tipo_id_paciente=p.tipo_id_paciente
WHERE hsm.fecha_solicitud BETWEEN _1 AND _2
ORDER BY hsm.fecha_solicitud DESC