select td.tarifario_id, td.grupo_tarifario_id, td.subgrupo_tarifario_id, td.cargo, td.descripcion, td.precio, t.descripcion_corta
from tarifarios_detalle td, tipos_unidades_cargos t
where td.tipo_unidad_id=t.tipo_unidad_id
group by 1,2,3,4,5,6,7
order by 1;
