---- Reporte de Escala de Riesgos 
SELECT he.ingreso, ig.fecha_registro, 
ig.tipo_id_paciente || ' ' || ig.paciente_id as identificacion, 
p.primer_apellido || ' ' || p.segundo_apellido || ' ' || p.primer_nombre || ' ' || p.segundo_nombre as Nombre_Paciente, 
he.departamento, gai.grupo_alergia_item_descripcion as Riesgo, 
su.nombre as Usuario_Registra, he.fecha_registro
FROM hc_gra_alergias_pacientes hap, hc_evoluciones as he, ingresos as ig, pacientes as p, grupo_alergias_items as gai, system_usuarios as su
WHERE hap.evolucion_id = he.evolucion_id
AND ig.ingreso = he.ingreso
AND p.paciente_id = ig.paciente_id
AND he.usuario_id = su.usuario_id
AND hap.grupo_alergia_item_id = gai.grupo_alergia_item_id