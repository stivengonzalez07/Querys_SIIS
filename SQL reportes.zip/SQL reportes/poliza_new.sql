--POLIZA MODIFICADO
Select
sp.poliza
, sp.vigencia_hasta as fecha_vencimiento
, tip.descripcion as tipo_id_victima --ANADIDO
, i.paciente_id as id_victima
, sa.fecha_accidente as fecha_siniestro
, sp.tipo_id_tercero as id
, sp.tercero_id as id_pagador
, ff.prefijo as prefijo_factura
, ff.factura_fiscal as id_factura
, ff.fecha_registro as fecha_factura
, e.fecha_radicacion 
, ff.total_factura --ANADIDO
, glsm.motivo_glosa_descripcion -- ANADIDO

FROM fac_facturas ff

LEFT JOIN envios_detalle ed ON (ed.prefijo = ff.prefijo and ed.factura_fiscal = ff.factura_fiscal)
LEFT JOIN envios e ON (e.envio_id = ed.envio_id)
INNER JOIN fac_facturas_cuentas ffc ON (ffc.prefijo = ff.prefijo and ffc.factura_fiscal = ff.factura_fiscal)
INNER JOIN cuentas c ON (c.numerodecuenta = ffc.numerodecuenta)
LEFT JOIN glosas gls ON (ff.prefijo = gls.prefijo and ff.factura_fiscal = gls.factura_fiscal) --ANADIDO
LEFT JOIN glosas_motivos glsm ON (gls.motivo_glosa_id = glsm.motivo_glosa_id ) --ANADIDO
INNER JOIN ingresos i ON (i.ingreso = c.ingreso)
LEFT JOIN ingresos_soat ins ON (ins.ingreso = i.ingreso)
LEFT JOIN soat_eventos se ON (se.evento = ins.evento)
INNER JOIN soat_polizas sp ON (sp.poliza = se.poliza)
INNER JOIN terceros_soat ts ON (ts.tipo_id_tercero = sp.tipo_id_tercero AND ts.tercero_id = sp.tercero_id)
LEFT JOIN soat_accidente sa ON (sa.accidente_id = se.accidente_id)
INNER JOIN cuentas_detalle cd ON (cd.numerodecuenta = c.numerodecuenta)
INNER JOIN tarifarios_detalle td ON (td.tarifario_id = cd.tarifario_id AND td.cargo = cd.cargo)
LEFT JOIN tipos_id_pacientes tip ON ( i.tipo_id_paciente=tip.tipo_id_paciente ) --ANADIDO

WHERE ff.fecha_registro::date BETWEEN _1 AND _2
--WHERE ff.fecha_registro::date BETWEEN '2016-01-01' AND '2021-11-09'
AND cd.cargo NOT IN ('IMD','DIMD')
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13
ORDER BY ff.factura_fiscal