SELECT 	c.numerodecuenta,
	    c.ingreso,
		i.tipo_id_paciente ||' '|| i.paciente_id AS paciente,
		ff.prefijo ||' '|| ff.factura_fiscal AS factura, 
		qx.tarifario_id, 
		qx.tipo_cargo_qx_id, 
		cd.cargo_cups,
		cd.cargo, 
		td.descripcion, 
		cd.precio,
		qx.cargo AS cargo_procedimiento,
		tdq.descripcion,
		qx.porcentaje,
		pro.nombre as Cirujano,
		esp.descripcion as especialidad
FROM 	cuentas_detalle cd
LEFT JOIN cuentas c ON (cd.numerodecuenta=c.numerodecuenta)
LEFT JOIN fac_facturas_cuentas fc ON (c.numerodecuenta=fc.numerodecuenta)
LEFT JOIN fac_facturas ff ON (ff.factura_fiscal=fc.factura_fiscal AND ff.prefijo=fc.prefijo)
LEFT JOIN ingresos i ON (c.ingreso=i.ingreso)
INNER JOIN cuentas_cargos_qx_procedimientos qx ON (cd.transaccion=qx.transaccion)
LEFT JOIN tarifarios_detalle td ON (cd.cargo=td.cargo AND cd.tarifario_id=td.tarifario_id)
LEFT JOIN tarifarios_detalle tdq ON (qx.cargo=tdq.cargo AND qx.tarifario_id=tdq.tarifario_id)
LEFT JOIN cuentas_liquidaciones_qx_procedimientos clq ON (qx.consecutivo_procedimiento=clq.consecutivo_procedimiento)
LEFT JOIN profesionales  pro ON (pro.tercero_id = clq.cirujano_id AND clq.tipo_id_cirujano = pro.tipo_id_tercero)
LEFT JOIN profesionales_especialidades  pe ON (pe.tercero_id = pro.tercero_id AND pe.tipo_id_tercero = pro.tipo_id_tercero)
LEFT JOIN especialidades  esp ON (esp.especialidad = pe.especialidad)
WHERE c.fecha_registro::date  between _1 AND _2
ORDER BY  2
		