SELECT mov.*
FROM (
SELECT a.fecha_registro,
a.prefijo,
a.numero,
a.bodega,
bg.descripcion as descrip_bodega,
b.codigo_producto,
ip.descripcion as desc_producto,
b.cantidad,
abs(b.total_costo)::int as debito,
0 as credito,
cc.centro_de_costo_id,
CASE WHEN cpex.cuenta IS NOT NULL THEN cpex.cuenta
WHEN cp.cuenta IS NOT NULL THEN cp.cuenta
ELSE 'Sin Parametrizacion'
END AS cuenta,
a.observacion
FROM inv_bodegas_movimiento a
join inv_bodegas_movimiento_d b on (a.empresa_id = b.empresa_id AND a.prefijo = b.prefijo AND a.numero = b.numero)
join inv_bodegas_movimiento_consumo c on (a.empresa_id = c.empresa_id AND a.prefijo = c.prefijo AND a.numero = c.numero)
join inventarios iv on (b.empresa_id = iv.empresa_id and b.codigo_producto = iv.codigo_producto)
join bodegas bg on (b.bodega = bg.bodega)
join inventarios_productos ip on (iv.codigo_producto = ip.codigo_producto)
join cg_conf.centros_de_costo_departamentos cc on (c.departamento = cc.departamento)
left join cg_conf.doc_inv_e006_costos_parametros_excepciones cpex on (b.empresa_id = cpex.empresa_id and c.departamento = cpex.departamento and b.codigo_producto = cpex.codigo_producto)
left join cg_conf.doc_inv_e006_costos_parametros cp on (b.empresa_id = cp.empresa_id and c.departamento = cp.departamento and ip.grupo_id = cp.grupo_id and ip.clase_id = cp.clase_id and ip.subclase_id = cp.subclase_id)
WHERE a.fecha_registro::date >= _1
and a.fecha_registro::date <= _2
AND a.total_costo <> 0
UNION ALL
SELECT a.fecha_registro,
a.prefijo,
a.numero,
a.bodega,
bg.descripcion as descrip_bodega,
b.codigo_producto,
ip.descripcion as desc_producto,
b.cantidad,
0 as debito,
abs(b.total_costo)::int as credito,
cc.centro_de_costo_id,
CASE WHEN cpex.cuenta IS NOT NULL THEN cpex.cuenta
WHEN cp.cuenta IS NOT NULL THEN cp.cuenta
ELSE 'Sin Parametrizacion'
END AS cuenta,
a.observacion
FROM inv_bodegas_movimiento a
join inv_bodegas_movimiento_d b on (a.empresa_id = b.empresa_id AND a.prefijo = b.prefijo AND a.numero = b.numero)
join inv_bodegas_movimiento_consumo c on (a.empresa_id = c.empresa_id AND a.prefijo = c.prefijo AND a.numero = c.numero)
join inventarios iv on (b.empresa_id = iv.empresa_id and b.codigo_producto = iv.codigo_producto)
join bodegas bg on (b.bodega = bg.bodega)
join inventarios_productos ip on (iv.codigo_producto = ip.codigo_producto)
join cg_conf.centros_de_costo_departamentos cc on (c.departamento = cc.departamento)
left join cg_conf.doc_inv_e006_parametros_excepciones cpex on (b.empresa_id = cpex.empresa_id and c.departamento = cpex.departamento and b.codigo_producto = cpex.codigo_producto)
left join cg_conf.doc_inv_e006_parametros cp on (b.empresa_id = cp.empresa_id and c.departamento = cp.departamento and ip.grupo_id = cp.grupo_id and ip.clase_id = cp.clase_id and ip.subclase_id = cp.subclase_id)
WHERE a.fecha_registro::date >= _1
and a.fecha_registro::date <= _2
AND a.total_costo <> 0
) as mov
ORDER BY mov.prefijo,mov.numero, mov.codigo_producto,mov.cuenta