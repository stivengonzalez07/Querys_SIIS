SELECT DISTINCT cl.lapso,
		b.descripcion AS bodega,
       cld.codigo_producto,
       ip.descripcion as producto,
       u.descripcion as unidad,
       cie.existencia_inicial::integer,
       i.costo::bigint as costounitario,
       (i.costo::bigint*cie.existencia_inicial)::bigint as costoinicial,
       cie.ingresos as entradas,
       (i.costo::bigint*cie.ingresos)::bigint as costoentradas,
       cie.egresos::bigint as Salidas,
       (i.costo::bigint*cie.egresos)::bigint as costosalidas,
       cie.existencia_final::bigint,
       (i.costo::bigint*cie.existencia_final)::bigint as costofinal,
       eb.existencia::bigint as existenciaactual
FROM inventarios_productos ip,
     inv_bodegas_movimiento_costo_por_lapso_d cld,
     unidades u,
     inv_bodegas_movimiento_costo_por_lapso cl,
     inv_bodegas_movimiento_cierres_por_lapso cie,
     inventarios i,
     existencias_bodegas eb,
	 bodegas b
WHERE cld.codigo_producto=ip.codigo_producto
AND  ip.codigo_producto=i.codigo_producto
AND  i.codigo_producto = cld.codigo_producto
AND  cie.codigo_producto = cld.codigo_producto
AND  i.codigo_producto = cie.codigo_producto
AND  i.codigo_producto = eb.codigo_producto
AND  eb.codigo_producto = cie.codigo_producto
AND  ip.codigo_producto = eb.codigo_producto
AND  eb.codigo_producto = cld.codigo_producto
AND  u.unidad_id=ip.unidad_id
AND  cl.lapso=cie.lapso
AND  eb.bodega IN ('BC','BF','OU')
AND  eb.bodega=b.bodega
AND  eb.estado='1'
AND  eb.bodega=cie.bodega
AND  cl.fecha_documento::date>=_1
AND  cl.fecha_documento::date<=_2
ORDER BY 3