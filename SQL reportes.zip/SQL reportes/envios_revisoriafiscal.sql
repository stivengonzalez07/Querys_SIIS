select a.fecha_registro,a.envio_id,
CASE WHEN a.sw_estado='0' THEN 'Activo'
            WHEN a.sw_estado='1' THEN 'Radicado'
            WHEN a.sw_estado='2' THEN 'Anulado'
            ELSE 'Despachado'
END as Estado,b.factura_fiscal,
c.total_factura as valor_factura,
(c.valor_cuota_paciente + c.valor_cuota_moderadora) as valor_paciente,
d.nombre_tercero 
from envios a,
 envios_detalle b, fac_facturas c,terceros d 
 where  a.envio_id=b.envio_id and b.prefijo=c.prefijo and 
 b.factura_fiscal=c.factura_fiscal and 
c.tipo_id_tercero=d.tipo_id_tercero and c.tercero_id=d.tercero_id and a.fecha_registro::date 
BETWEEN _1 and _2 order by a.envio_id asc
