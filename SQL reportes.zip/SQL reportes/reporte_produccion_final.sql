SELECT distinct c.numerodecuenta,
i.fecha_ingreso,
s.fecha_registro,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
ffc.factura_fiscal,
cd.cargo,
c.total_cuenta,
d.descripcion,
'Medicamentos' as tipo_producto,
SUM(COALESCE(a.total_costo,0))as costo,
SUM(cd.valor_cargo) as total_x_rango_cargo,
(SELECT SUM(valor_cargo) FROM cuentas_detalle cd2 WHERE cd2.numerodecuenta=c.numerodecuenta AND cd2.fecha_cargo BETWEEN _1 AND _2) as total_cuenta_x_rango


FROM pacientes P,
planes pl,
ingresos_salidas s,
cuentas c LEFT JOIN fac_facturas_cuentas ffc ON(c.numerodecuenta=ffc.numerodecuenta),
cuentas_detalle cd
LEFT JOIN bodegas_documentos_d as a ON(cd.consecutivo = a.consecutivo),
ingresos i,
departamentos d,
bodegas_documentos_d bdd,
inventarios_productos ip

WHERE   c.plan_id = pl.plan_id
AND     p.paciente_id = i.paciente_id
AND     d.departamento = i.departamento
AND     c.numerodecuenta = cd.numerodecuenta
AND     i.ingreso = c.ingreso
AND     i.ingreso = s.ingreso
AND     c.estado != '5'
AND     cd.cargo = 'IMD'
AND     cd.fecha_cargo BETWEEN _1 AND _2 AND     cd.consecutivo = bdd.consecutivo
AND     bdd.codigo_producto = ip.codigo_producto
AND     ip.grupo_id='01'
GROUP BY c.numerodecuenta,
i.fecha_ingreso,
s.fecha_registro,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
cd.cargo,
c.total_cuenta,
d.descripcion,
ffc.factura_fiscal

UNION

SELECT distinct c.numerodecuenta,
i.fecha_ingreso,
s.fecha_registro,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
ffc.factura_fiscal,
cd.cargo,
c.total_cuenta,
d.descripcion,
'Insumos' as tipo_producto,
SUM(COALESCE(a.total_costo,0))as costo,
SUM(cd.valor_cargo) as total_x_rango_cargo,
(SELECT SUM(valor_cargo) FROM cuentas_detalle cd2 WHERE cd2.numerodecuenta=c.numerodecuenta AND cd2.fecha_cargo BETWEEN _1 AND _2) as total_cuenta_x_rango


FROM pacientes P,
planes pl,
ingresos_salidas s,
cuentas c LEFT JOIN fac_facturas_cuentas ffc ON(c.numerodecuenta=ffc.numerodecuenta),
cuentas_detalle cd
LEFT JOIN bodegas_documentos_d as a ON(cd.consecutivo = a.consecutivo),
ingresos i,
departamentos d,
bodegas_documentos_d bdd,
inventarios_productos ip

WHERE   c.plan_id = pl.plan_id
AND     p.paciente_id = i.paciente_id
AND     d.departamento = i.departamento
AND     c.numerodecuenta = cd.numerodecuenta
AND     i.ingreso = c.ingreso
AND     i.ingreso = s.ingreso
AND     c.estado != '5'
AND     cd.cargo = 'IMD'
AND     cd.fecha_cargo BETWEEN _1 AND _2
AND     cd.consecutivo = bdd.consecutivo
AND     bdd.codigo_producto = ip.codigo_producto
AND     ip.grupo_id='02'
GROUP BY c.numerodecuenta,
i.fecha_ingreso,
s.fecha_registro,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
cd.cargo,
c.total_cuenta,
d.descripcion,
ffc.factura_fiscal

UNION

SELECT distinct c.numerodecuenta,
i.fecha_ingreso,
s.fecha_registro,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
ffc.factura_fiscal,
'Oxigeno' as cargo,
c.total_cuenta,
d.descripcion,
'Oxigeno' as tipo_producto,
SUM(COALESCE(a.total_costo,0))as costo,
SUM(cd.valor_cargo) as total_x_rango_cargo,
(SELECT SUM(valor_cargo) FROM cuentas_detalle cd2 WHERE cd2.numerodecuenta=c.numerodecuenta AND cd2.fecha_cargo BETWEEN _1 AND _2) as total_cuenta_x_rango


FROM pacientes P,
planes pl,
ingresos_salidas s,
cuentas c LEFT JOIN fac_facturas_cuentas ffc ON(c.numerodecuenta=ffc.numerodecuenta),
cuentas_detalle cd
LEFT JOIN bodegas_documentos_d as a ON(cd.consecutivo = a.consecutivo),
ingresos i,
departamentos d

WHERE   c.plan_id = pl.plan_id
AND     p.paciente_id = i.paciente_id
AND     d.departamento = i.departamento
AND     c.numerodecuenta = cd.numerodecuenta
AND     i.ingreso = c.ingreso
AND     i.ingreso = s.ingreso
AND     c.estado != '5'
AND     cd.cargo IN ('S55201', 'S55206', 'S55208')
AND     cd.fecha_cargo BETWEEN _1 AND _2
GROUP BY c.numerodecuenta,
i.fecha_ingreso,
s.fecha_registro,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
c.total_cuenta,
d.descripcion,
ffc.factura_fiscal

UNION

SELECT distinct c.numerodecuenta,
i.fecha_ingreso,
s.fecha_registro,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
ffc.factura_fiscal,
'Habitaci�n' as cargo,
c.total_cuenta,
d.descripcion,
'Habitaci�n' as tipo_producto,
SUM(COALESCE(a.total_costo,0))as costo,
SUM(cd.valor_cargo) as total_x_rango_cargo,
(SELECT SUM(valor_cargo) FROM cuentas_detalle cd2 WHERE cd2.numerodecuenta=c.numerodecuenta AND cd2.fecha_cargo BETWEEN _1 AND _2) as total_cuenta_x_rango


FROM pacientes P,
planes pl,
ingresos_salidas s,
cuentas c LEFT JOIN fac_facturas_cuentas ffc ON(c.numerodecuenta=ffc.numerodecuenta),
cuentas_detalle cd
LEFT JOIN bodegas_documentos_d as a ON(cd.consecutivo = a.consecutivo),
ingresos i,
departamentos d

WHERE   c.plan_id = pl.plan_id
AND     p.paciente_id = i.paciente_id
AND     d.departamento = i.departamento
AND     c.numerodecuenta = cd.numerodecuenta
AND     i.ingreso = c.ingreso
AND     i.ingreso = s.ingreso
AND     c.estado != '5'
AND     cd.cargo IN (' S11302', 'S12103', 'S11301', 'S12203')
AND     cd.fecha_cargo BETWEEN _1 AND _2
GROUP BY c.numerodecuenta,
i.fecha_ingreso,
s.fecha_registro,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
c.total_cuenta,
d.descripcion,
ffc.factura_fiscal

