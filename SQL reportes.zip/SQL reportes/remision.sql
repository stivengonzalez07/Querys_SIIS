Select tidp.departamento as Departamento_Afiliado, 
timp.municipio as Municipio_Afiliado, 
regimen_descripcion as Regimen,
pl.tercero_id as NIT_Prestador,
p.primer_apellido,
p.segundo_apellido, 
p.primer_nombre, 
p.segundo_nombre,
hos.paciente_id as Identificacion, 
hos.tipo_id_paciente as Tipo_Identificacion,
pl.plan_descripcion as EPS_Afiliado, 
p.fecha_nacimiento, 
hde.tipo_diagnostico_id as CodigoCIE10, 
d.diagnostico_nombre as Nombre_Diagnostico, 
hos.cargo as Codigo_Cups, 
cups.descripcion as Procedimiento_o_Servicio, 
hos.fecha_solicitud as Fecha_Remision,
s.descripcion as servicio


from hc_os_solicitudes as hos
left join hc_os_solicitudes_interconsultas as hosi on hosi.hc_os_solicitud_id = hos.hc_os_solicitud_id
left join hc_evoluciones as he on hos.evolucion_id = he.evolucion_id
inner join pacientes as p on hos.paciente_id = p.paciente_id and hos.tipo_id_paciente = p.tipo_id_paciente
left join tipo_dptos as tidp on p.tipo_dpto_id = tidp.tipo_dpto_id
left join tipo_mpios as timp on p.tipo_mpio_id = timp.tipo_mpio_id and p.tipo_dpto_id = timp.tipo_dpto_id
left join planes as pl on hos.plan_id = pl.plan_id
left join tipos_cliente as tc on pl.tipo_cliente = tc.tipo_cliente
left join regimenes as r on tc.regimen_id = r.regimen_id
left join hc_diagnosticos_egreso as hde on hos.evolucion_id = hde.evolucion_id
left join diagnosticos as d on hde.tipo_diagnostico_id = d.diagnostico_id
left join cups as cups on hos.cargo = cups.cargo
left join departamentos as dp on he.departamento = dp.departamento
left join servicios as s on dp.servicio = s.servicio

where hos.os_tipo_solicitud_id = 'INT'
AND hde.sw_principal = '1'
--and hos.fecha_solicitud::date between '2016-02-01' and '2016-02-15'
and hos.fecha_solicitud::date between _1 and _2
