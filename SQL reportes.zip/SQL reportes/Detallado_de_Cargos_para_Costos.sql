select a.transaccion,c.numerodecuenta,c.ingreso,a.cargo,b.codigo_producto,a.valor_cargo,
a.valor_cubierto,mh.departamento as deparatmentoCama,a.departamento, a.fecha_cargo
from cuentas_detalle a 
 left join bodegas_documentos_d b on a.consecutivo=b.consecutivo
left join cuentas c on a.numerodecuenta=c.numerodecuenta
left join movimientos_habitacion mh on a.numerodecuenta=mh.numerodecuenta
where a.departamento in('DIRMED',
'UCI005',
'CIRU01',
'UCI006',
'IMAGEN',
'HOS004',
'LABCLI',
'HOS003',
'HOS005',
'HOS006',
'ESTERI',
'CEXTER',
'UCI003',
'UCI07A',
'UCI07B',
'UCI07C',
'UCIN04',
'TENTER',
'FARMAC',
'HEMODI',
'ANGIOG',
'URGENC',
'ENDOSC',
'LABPAT',
'CTMEZC',
'REHABI') and a.fecha_cargo::date BETWEEN _1 AND _2