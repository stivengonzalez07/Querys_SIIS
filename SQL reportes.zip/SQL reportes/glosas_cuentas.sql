SELECT  g.glosa_id,
        g.prefijo,
        g.factura_fiscal,
        g.fecha_glosa,
        fc.numerodecuenta,
	c.ingreso,
	c.total_cuenta
     
FROM glosas g
INNER JOIN fac_facturas_cuentas fc ON (g.factura_fiscal=fc.factura_fiscal AND g.prefijo=fc.prefijo)
INNER JOIN cuentas c ON (fc.numerodecuenta=c.numerodecuenta)

WHERE
g.fecha_glosa::date BETWEEN _1 AND _2
ORDER BY g.glosa_id
