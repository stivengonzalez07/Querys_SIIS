SELECT p.plan_descripcion as plan,SUM(cd.valor_cargo::integer)as valor
FROM cuentas_detalle cd,planes p,cuentas c
WHERE c.plan_id=p.plan_id
AND c.estado != '5'
AND c.numerodecuenta=cd.numerodecuenta
AND cd.fecha_cargo>=_1
AND cd.fecha_cargo<=_2
GROUP BY p.plan_descripcion
ORDER BY 1;