SELECT g.prefijo,g.factura_fiscal,g.fecha_registro, g.fecha_glosa, to_char(gl.fecha_registro, 'YYYY-MM-DD') as fecha_registro_respuesta, (to_date(to_char(gl.fecha_registro, 'YYYY-MM-DD'),'YYYY-MM-DD')-g.fecha_glosa) as diferencia_dias, g.valor_glosa, 
g.sw_devolucion_factura, p.plan_descripcion, s.nombre,g.sw_glosa_total_factura
FROM glosas g
INNER JOIN glosas_respuestas gl ON (g.glosa_id = gl.glosa_id)
LEFT JOIN fac_facturas f ON (g.prefijo=f.prefijo AND g.factura_fiscal=f.factura_fiscal)
LEFT JOIN planes p ON (f.plan_id=p.plan_id)
LEFT JOIN system_usuarios s ON (gl.usuario_id=s.usuario_id)
WHERE g.sw_estado!='0'
AND p.tipo_cliente='20'
ANd gl.fecha_registro::date between _1 and _2
GROUP BY 1,2,3,4,5,6,7,8,9,10,11
ORDER BY 2,3