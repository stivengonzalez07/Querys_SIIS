SELECT  cuentas.ingreso,
        ingresos.tipo_id_paciente,
        ingresos.paciente_id,
        pacientes.primer_nombre ||' '|| pacientes.segundo_nombre ||' '|| pacientes.primer_apellido ||' '|| pacientes.segundo_apellido as nombre_paciente,
        cups.descripcion, 
        cuentas_detalle.cantidad, 
        cuentas_detalle.precio, 
        planes.plan_descripcion, 
        cuentas.numerodecuenta, 
        cuentas_detalle.fecha_cargo, 
        departamentos.descripcion

FROM   (((cups cups INNER JOIN cuentas_detalle cuentas_detalle ON cups.cargo=cuentas_detalle.cargo_cups) 
          INNER JOIN cuentas cuentas ON cuentas_detalle.numerodecuenta=cuentas.numerodecuenta) 
          INNER JOIN departamentos departamentos ON cuentas_detalle.departamento=departamentos.departamento) 
          INNER JOIN planes planes ON cuentas.plan_id=planes.plan_id
          INNER JOIN ingresos ingresos ON cuentas.ingreso=ingresos.ingreso
          INNER JOIN pacientes pacientes ON ingresos.tipo_id_paciente = pacientes.tipo_id_paciente
          AND ingresos.paciente_id = pacientes.paciente_id

WHERE  ingresos.tipo_id_paciente = pacientes.tipo_id_paciente
AND     cuentas_detalle.fecha_cargo::date >= _1
AND     cuentas_detalle.fecha_cargo::date <= _2
AND    ingresos.paciente_id = pacientes.paciente_id
AND    departamentos.descripcion='LABORATORIO CLINICO'
ORDER BY ingresos.tipo_id_paciente, ingresos.paciente_id, cuentas.numerodecuenta, cups.descripcion;





