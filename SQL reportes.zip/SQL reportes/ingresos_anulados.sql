SELECT ig.ingreso,cu.numerodecuenta,ig.tipo_id_paciente,ig.paciente_id,ig.fecha_ingreso::date

FROM ingresos as ig,cuentas as cu

WHERE ig.estado= '5' 
and cu.ingreso=ig.ingreso
and ig.fecha_ingreso::date BETWEEN _1 AND _2

order by ig.ingreso asc