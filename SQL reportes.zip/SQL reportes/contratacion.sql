select pl.plan_descripcion, pt.tarifario_id, t.descripcion as descripcion_tarifario, pt.grupo_tarifario_id, pt.subgrupo_tarifario_id, pt.porcentaje,
pt.por_cobertura as porcentaje_cobertura
from plan_tarifario pt, planes pl, tarifarios t
where pt.plan_id = pl.plan_id
and pt.tarifario_id =  t.tarifario_id
and pl.estado = '1'
group by 1,2,3,4,5, 6, 7
order by 1;