     SELECT b.descripcion as Bodega,
            dp.codigo_producto,
			ip.descripcion,
            sum(dp.cantidad_despachada) AS cantidad,
            dp.fecha_vencimiento,
            dp.lote,
            ig.tipo_id_paciente,
            ig.paciente_id,
	    su.nombre as nombre_usuario,
		sm.fecha_solicitud

           FROM tm_despachos_productos as dp
		   INNER JOIN system_usuarios as su ON su.usuario_id = dp.usuario_id
           INNER JOIN inventarios_productos as ip ON dp.codigo_producto = ip.codigo_producto
           INNER JOIN bodegas as b ON b.bodega = dp.bodega
           INNER JOIN hc_solicitudes_medicamentos as sm ON sm.solicitud_id = dp.solicitud_id
           INNER JOIN ingresos as ig ON ig.ingreso = sm.ingreso
          GROUP BY b.descripcion, dp.codigo_producto, ip.descripcion, dp.fecha_vencimiento, 
		  dp.lote, ig.tipo_id_paciente, ig.paciente_id, su.nombre, sm.fecha_solicitud
