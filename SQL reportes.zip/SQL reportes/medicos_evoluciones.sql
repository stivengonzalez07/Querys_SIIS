SELECT 
c.nombre AS MEDICO, d.descripcion AS DEPARTAMENTO, g.descripcion AS ESPECIALIDAD, a.fecha_cierre AS FECHA_EVOL, e.tipo_id_paciente ||' '|| e.paciente_id AS ID_PACIENTE, e.primer_nombre ||' '||e.segundo_nombre||' '||e.primer_apellido||' '||e.segundo_apellido AS nom_PACIENTE
FROM
hc_evoluciones a
INNER JOIN ingresos b ON a.ingreso=b.ingreso
INNER JOIN profesionales c ON c.usuario_id=a.usuario_id
INNER JOIN departamentos d ON d.departamento=a.departamento
INNER JOIN pacientes e ON e.paciente_id=b.paciente_id
INNER JOIN profesionales_especialidades f ON f.tercero_id=c.tercero_id
INNER JOIN especialidades g ON g.especialidad=f.especialidad
WHERE a.fecha_cierre::date BETWEEN _1 AND _2
AND c.tipo_profesional IN ('1', '2', '9', '11', '12')