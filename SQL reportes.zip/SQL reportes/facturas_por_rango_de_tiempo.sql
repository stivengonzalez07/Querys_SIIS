SELECT  fac_facturas.prefijo, 
        fac_facturas.factura_fiscal,
        fac_facturas.fecha_registro,
        fac_facturas.total_factura,
        planes.plan_descripcion,
        pacientes.tipo_id_paciente,
        pacientes.paciente_id, 
        pacientes.primer_apellido,
        pacientes.segundo_apellido,
        pacientes.primer_nombre,
        pacientes.segundo_nombre
       
FROM   ((((public.fac_facturas_cuentas fac_facturas_cuentas 
           INNER JOIN public.cuentas cuentas ON fac_facturas_cuentas.numerodecuenta = cuentas.numerodecuenta) 
           INNER JOIN public.fac_facturas fac_facturas ON (fac_facturas_cuentas.prefijo=fac_facturas.prefijo) 
           AND (fac_facturas_cuentas.factura_fiscal=fac_facturas.factura_fiscal)) 
           INNER JOIN public.planes planes ON cuentas.plan_id=planes.plan_id) 
           INNER JOIN public.ingresos ingresos ON cuentas.ingreso=ingresos.ingreso) 
           INNER JOIN public.pacientes pacientes ON (ingresos.paciente_id=pacientes.paciente_id) 
           AND (ingresos.tipo_id_paciente=pacientes.tipo_id_paciente)

WHERE   fac_facturas.fecha_registro >= _1
AND     fac_facturas.fecha_registro <= _2 
AND     NOT (fac_facturas.estado ='2' OR fac_facturas.estado ='3')
ORDER BY planes.plan_descripcion	







