select bdd.codigo_producto,
ip.descripcion as producto,
(AVG(bdd.total_costo)* SUM (bdd.cantidad)) as total_costo,
--((bdd.total_costo)* SUM (bdd.cantidad)) as total_costo,
SUM (bdd.cantidad) as cantidad,
--SUM (bdd.total_costo) as total_costo,
SUM (cd.valor_cargo) as valor_facturado
--SUM (bdd.total_costo * bdd.cantidad)) as total_costo,
--SUM (bdd.total_costo) as total_costo,
--bdd.cantidad,
--bdd.total_costo,
--cd.valor_cargo
--SUM (bdd.total_costo) as total_costo,

from cuentas_detalle as cd
inner join cuentas as cta 
ON cta.numerodecuenta = cd.numerodecuenta
inner join bodegas_documentos_d as bdd 
ON bdd.consecutivo = cd.consecutivo
inner join inventarios_productos as ip 
ON ip.codigo_producto = bdd.codigo_producto
inner join bodegas_documentos as bd 
ON bd.bodegas_doc_id = bdd.bodegas_doc_id 
and bd.numeracion = bdd.numeracion
inner join bodegas_doc_numeraciones as bdn 
ON bdn.bodegas_doc_id = bd.bodegas_doc_id

where cd.fecha_registro::date >= _1 and cd.fecha_registro::date<=_2
and bdn.bodegas_doc_id = '1'
group by bdd.codigo_producto, ip.descripcion
order by 1;

