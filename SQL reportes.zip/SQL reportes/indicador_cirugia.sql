select
a.plan_descripcion,
a.total_cirugias,
a.total_dias,
count(dia) as festivos_periodo,
((a.total_dias)-count(dia)) as dias_habiles,
(round(((a.total_dias)-count(dia))/a.total_cirugias)/100,0)  as indicador

 from
(select
plan_descripcion,
sum((to_char(qqp.hora_inicio::date,'yyyy-mm-dd')::date-to_char(qp.fecha_registro::date,'yyyy-mm-dd')::date)) as total_dias,
count(qp.programacion_id) as total_cirugias
from qx_programaciones as qp
inner join qx_quirofanos_programacion as qqp ON qqp.programacion_id = qp.programacion_id
inner join pacientes as pac ON pac.tipo_id_paciente = qp.tipo_id_paciente and pac.paciente_id = qp.paciente_id
inner join planes as pl ON pl.plan_id = qp.plan_id
where 
qqp.qx_tipo_reserva_quirofano_id <> 0
and qqp.hora_inicio between _1 
and _2
group by 1) as a
left join dias_festivos as fes ON fes.dia between _1 and _2
group by 1,2,3
order by 1
