select qp.fecha_registro as fecha_programacion,
su.nombre as usuario_programa,
pac.paciente_id as cedula,
(pac.primer_nombre||' '||pac.segundo_nombre||' '||pac.primer_apellido||' '||pac.segundo_apellido) as paciente,
(select nombre from system_usuarios as su1 where su1.usuario_id = pc.usuario_id) as usuario_cancela,
pc.fecha_registro as fecha_cancelacion,
pc.observacion

from qx_programaciones_canceladas as pc
inner join qx_programaciones as qp ON pc.programacion_id =qp.programacion_id
inner join pacientes as pac ON pac.tipo_id_paciente = qp.tipo_id_paciente and pac.paciente_id = qp.paciente_id
inner join system_usuarios as su ON su.usuario_id = qp.usuario_id
where pc.fecha_registro >= _1
and pc.fecha_registro <= _2
