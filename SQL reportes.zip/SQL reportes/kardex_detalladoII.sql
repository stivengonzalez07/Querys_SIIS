SELECT	vc.empresa_id, 
		vc.centro_utilidad,
		vc.bodega,
		b.descripcion,
		vc.codigo_producto,
		vc.cantidad, 
		SUM(vc.ingresos) as ingresos, 
		SUM(vc.egresos) as egresos,  
		ip.descripcion,  
		vc.fecha_vencimiento, 
		vc.lote,  
		vc.fecha_registro::date, 
		vc.prefijo, 
		vc.numero, 
		vc.tipo_id_tercero, 
		vc.tercero_id, 
		t.nombre_tercero, 
		vc.total_costo 
		FROM	view_consulta_productos vc, 
				inventarios_productos ip, 
				terceros t,
				bodegas b 
		WHERE  vc.empresa_id = '01' 
		AND    vc.codigo_producto = ip.codigo_producto 
		AND    vc.tipo_id_tercero = t.tipo_id_tercero 
		AND    vc.tercero_id = t.tercero_id 
		AND    vc.bodega = b.bodega
		AND    vc.bodega IN('AB','AF','AN','AP','BA','BC','BF','BI','BO','BP','BT','CF','CI','CL','CM','CP','CR','CT','GH','HE','JJ',
			'LA','LB','LH','MC','ME','MN','MO','MR','NP','OU','PM','PP','RP','RS','SG','SP','SS','ST','TE','TI','TM','TR')      
		AND    vc.fecha_registro::date BETWEEN _1 AND _2
		GROUP BY 1,2,3,4,5,6,9,10,11,12,13,14,15,16,17,18
		ORDER BY  vc.fecha_registro::date