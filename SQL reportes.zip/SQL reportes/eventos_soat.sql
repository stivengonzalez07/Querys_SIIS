SELECT si.ingreso, 
se.evento, 
se.poliza, 
sp.vigencia_desde,
sp.vigencia_hasta,
sp.placa_vehiculo,
se.tipo_id_paciente, 
se.paciente_id, 
sa.fecha_accidente, 
sa.sitio_accidente, 
sa.informe_accidente,
t.nombre_tercero
FROM ingresos_soat si, 
soat_eventos se, 
soat_accidente sa, 
soat_polizas sp,
terceros t,
ingresos i
WHERE si.evento = se.evento
AND se.accidente_id = sa.accidente_id
AND i.ingreso = si.ingreso
AND se.poliza = sp.poliza
AND sp.tercero_id = t.tercero_id
AND i.fecha_ingreso::date BETWEEN _1 AND _2

