SELECT
ip.codigo_producto,
ip.descripcion,
ig.grupo_id,
ig.descripcion AS GRUPO,
ic.clase_id,
ic.descripcion AS CLASE,
isi.subclase_id,
isi.descripcion AS SUBCLASE
FROM 
inv_grupos_inventarios ig
INNER JOIN inv_clases_inventarios ic ON ( ig.grupo_id=ic.grupo_id )
INNER JOIN inv_subclases_inventarios isi ON ( ic.clase_id=isi.clase_id AND ic.grupo_id=isi.grupo_id )
INNER JOIN inventarios_productos ip ON ( ig.grupo_id=ip.grupo_id AND ic.clase_id=ip.clase_id AND isi.subclase_id=ip.subclase_id )