SELECT 	i.tipo_id_paciente,
        i.paciente_id,
		p.primer_nombre,
		p.segundo_nombre,
		p.primer_apellido,
		p.segundo_apellido,
		pl.plan_descripcion,
		to_char(fac.fecha_registro, 'DD-MM-YYYY') as  fecha_factura,
		to_char(i.fecha_ingreso, 'DD-MM-YYYY') as  fecha_ingreso,
		to_char(c.fecha_registro, 'DD-MM-YYYY') AS fecha_cuenta,
		c.numerodecuenta AS cuenta,
		c.fecha_registro AS fecha_cuenta,
		f.prefijo,
		f.factura_fiscal,
		c.total_cuenta,
		c.abono_efectivo AS cuota_paciente,
		u.nombre
		
FROM	cuentas c,
		ingresos i,
		pacientes p,
		fac_facturas_cuentas f,
		fac_facturas fac,
		planes pl,
		system_usuarios u
		
WHERE	c.ingreso = i.ingreso
AND		i.paciente_id = p.paciente_id
AND		i.tipo_id_paciente = p.tipo_id_paciente
AND		c.plan_id = pl.plan_id
--AND     f.sw_tipo = '1'
AND     NOT (fac.estado ='3' OR fac.estado ='2')
AND		c.numerodecuenta = f.numerodecuenta
AND		f.factura_fiscal = fac.factura_fiscal
AND     f.prefijo = fac.prefijo
AND     u.usuario_id=fac.usuario_id
AND		fac.fecha_registro::date >= _1 
AND 	fac.fecha_registro::date <= _2	
ORDER BY f.factura_fiscal