select distinct
c.numerodecuenta,
i.fecha_ingreso,
ce.descripcion,
su.usuario,
d.descripcion as dep_descripcion,
ta.tipo_afiliado_nombre,
p.plan_descripcion,
p.plan_id,
c.valor_nocubierto,
c.valor_cubierto,
c.total_cuenta,
pa.tipo_id_paciente,
pa.paciente_id,
pa.primer_nombre ||' '|| pa.segundo_nombre ||' '||
 pa.primer_apellido ||' '|| pa.segundo_apellido AS nombre,
ig.fecha_registro as fecha_egreso,
date_part('days', now() - ig.fecha_registro ) as dias,
edad(pa.fecha_nacimiento) as edad,
(CASE WHEN ce.estado = '0' THEN ffc.factura_fiscal ELSE NULL END) as factura,
(CASE WHEN ce.descripcion <> 'FACTURADA' THEN CASE WHEN ce.descripcion IS NULL THEN 'ABIERTO' ELSE ce.descripcion END ELSE NULL END) as estado_cuenta,
dep_e.descripcion as dep_egreso,
c.fecha_cierre,
fact.fecha_registro as fecha_fact,
fact.prefijo,
--fc_cantidad_dias_habiles(CAST(c.fecha_registro AS DATE),CAST(now() AS DATE))+
--fc_cantidad_dias_sabado(CAST(c.fecha_registro AS DATE),CAST(now() AS DATE))as vencimiento,
--fc_cantidad_dias_habiles(CAST(ig.fecha_registro AS DATE),CAST(now() AS DATE))+
--fc_cantidad_dias_sabado(CAST(ig.fecha_registro AS DATE),CAST(now() AS DATE))as egreso_habiles,
(SELECT municipio FROM tipo_mpios tm WHERE tm.tipo_mpio_id=pa.tipo_mpio_id AND tm.tipo_dpto_id=pa.tipo_dpto_id AND tm.tipo_pais_id=pa.tipo_pais_id) as municipio,
(SELECT departamento FROM tipo_dptos td WHERE td.tipo_dpto_id=pa.tipo_dpto_id AND td.tipo_pais_id=pa.tipo_pais_id) as departamento,
CASE WHEN d.servicio= '7' or d.servicio= '9' or d.servicio= '3' then 'ATENCION DE ORDENES DE SERVICIO'
     WHEN d.servicio= '4' then 'ADMISION URGENCIA'
     WHEN i.sw_apertura_admision='1' then 'ADMISION SIN HC'
     ELSE ser.descripcion END AS origen_de_ingreso,
CASE WHEN fact.estado = '0' THEN 'FACTURADO'
     WHEN fact.estado = '1' THEN 'PAGADO'
     WHEN fact.estado = '2' THEN 'ANULADO'
     WHEN fact.estado = '3' THEN 'ANULADA CON NOTA'
     WHEN fact.estado IS NULL THEN 'SIN FACTURA'
     ELSE 'SIN ESTADO' END AS estado_factura

from
ingresos i
left join ingresos_salidas ig on (i.ingreso = ig.ingreso)
left join departamentos dep_e on ig.departamento_egreso= dep_e.departamento,
cuentas c
left join fac_facturas_cuentas ffc on (c.numerodecuenta = ffc.numerodecuenta)
left join fac_facturas fact on (ffc.empresa_id=fact.empresa_id and ffc.prefijo=fact.prefijo and ffc.factura_fiscal=fact.factura_fiscal) ,
cuentas_estados ce,
system_usuarios su,
departamentos d
left join servicios ser on (d.servicio=ser.servicio),
tipos_afiliado ta,
planes p,
pacientes pa


where
i.ingreso = c.ingreso and
pa.paciente_id=i.paciente_id and
pa.tipo_id_paciente = i.tipo_id_paciente and
c.estado = ce.estado and
-- c.empresa_id = '02' and
su.usuario_id = c.usuario_id and
d.departamento = i.departamento_actual and
ta.tipo_afiliado_id = c.tipo_afiliado_id and
p.plan_id = c.plan_id and
c.fecha_registro::date BETWEEN _1 AND _2
--c.empresa_id = $P{empresa} and
--$X{  IN ,ce.estado, estado_cuenta   } and
--CASE WHEN $P{planes}  IS NOT  NULL THEN p.plan_id like $P{planes} ELSE TRUE END and
--CASE WHEN $P{centro_utilidad} IS NOT NULL THEN c.centro_utilidad = $P{centro_utilidad} ELSE TRUE END and
--CASE WHEN $P{unidad_funcional} IS NOT NULL THEN d.unidad_funcional = $P{unidad_funcional} ELSE TRUE END and
--CASE WHEN $P{departamentos} IS NOT NULL THEN d.departamento = $P{departamentos} ELSE TRUE END