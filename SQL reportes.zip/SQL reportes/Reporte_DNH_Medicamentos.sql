SELECT e.codigo_sgsss
	  ,'0' AS codigo_habilitacion
	  ,ip.fecha_factura::DATE
	  ,'2' AS rol_actor
	  ,'04' AS tipo_transaccion
	  ,m.codigo_medicamento
      ,invp.descripcion
	  ,m.codigo_ium
	  ,m.codigo_cum AS expediente_consecutivo_invima
	  ,'C' AS unidad_factura
	  ,copd.numero_unidades AS cant_fab_dnh
	  ,copd.numero_unidades2 AS cant_dnh_prvfinal
	  ,copd.valor AS valor_dnh_fabilu
	  ,copd.valor2 AS valor_prvfinal_dnh
	  ,ibr.numero_remision AS factura_tercero
	  ,ibr.fecha_remision::DATE AS fecha_remision
	  ,ir.prefijo_factura ||' '|| ir.numero_factura AS factura_DNH
FROM compras_ordenes_pedidos cop
LEFT JOIN compras_ordenes_pedidos_detalle copd ON (cop.orden_pedido_id = copd.orden_pedido_id)
LEFT JOIN terceros_proveedores tp ON (cop.codigo_proveedor_id = tp.codigo_proveedor_id)
LEFT JOIN terceros t ON (tp.tipo_id_tercero = t.tipo_id_tercero AND tp.tercero_id = t.tercero_id)
INNER JOIN medicamentos m ON (copd.codigo_producto = m.codigo_medicamento)
INNER JOIN inventarios_productos invp ON (m.codigo_medicamento = invp.codigo_producto ) 
INNER JOIN empresas e ON (cop.empresa_id = e.empresa_id)
INNER JOIN inv_bodegas_movimiento_ordenes_compra_i008 ip ON (cop.orden_pedido_id = ip.orden_pedido_id)
INNER JOIN inv_bodegas_movimiento_d ibmd ON (ip.empresa_id = ibmd.empresa_id AND ip.prefijo = ibmd.prefijo AND ip.numero = ibmd.numero)
INNER JOIN inv_bodegas_movimiento_ig_remision ibr ON (ip.empresa_id = ibr.empresa_id AND ip.prefijo = ibr.prefijo AND ip.numero = ibr.numero)
INNER JOIN inv_bodegas_movimiento_fr_remision fr ON (fr.prefijo_remision = ibr.prefijo AND fr.numero_remision = ibr.numero)
INNER JOIN inv_bodegas_movimiento_factura_remision ir ON (ir.prefijo = fr.prefijo AND ir.numero = fr.numero)
WHERE t.tipo_id_tercero = 'NI'
AND t.tercero_id = '901380846'
AND ip.fecha_factura::date BETWEEN _1 AND _2
--AND cop.orden_pedido_id=18946