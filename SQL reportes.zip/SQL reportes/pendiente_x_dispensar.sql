SELECT      b.descripcion as Bodega,
            dm.codigo_producto,
            ip.descripcion,
            sum(dm.cantidad_despachada) AS cantidad,
            dm.fecha_vencimiento,
            dm.lote,
			dfe.tipo_id_paciente,
            dfe.paciente_id,
			su.nombre as nombre_usuario,
			dfe.fecha_formula
			
           FROM ds_dispensacion_medicamentos_tmp as dm
           INNER JOIN ds_formulas_externas as dfe ON dfe.ds_formula_externa_id = dm.ds_formula_externa_id
           INNER JOIN system_usuarios as su ON su.usuario_id = dm.usuario_id
           INNER JOIN inventarios_productos as ip ON dm.codigo_producto = ip.codigo_producto
           INNER JOIN bodegas as b ON b.bodega = dm.bodega
          GROUP BY b.descripcion, dm.codigo_producto, ip.descripcion, dm.fecha_vencimiento, dm.lote, dfe.tipo_id_paciente, 
		  dfe.paciente_id, su.nombre, dfe.fecha_formula
