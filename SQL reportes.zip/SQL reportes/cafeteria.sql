SELECT ds.fecha_solicitud, dts.descripcion_solicitud, ds.estacion_id, dsd.tipo_cama_id, ds.fecha_confirmacion
from dietas_solicitud as ds, dietas_tipos_solicitud as dts, dietas_solicitud_detalle as dsd
WHERE ds.tipo_solicitud_dieta_id = dts.tipo_solicitud_dieta_id
AND dsd.ingreso_id = ds.ingreso_id
AND ds.fecha_confirmacion >= _1
AND ds.fecha_confirmacion <= _2
Group by ds.fecha_solicitud, dts.descripcion_solicitud, ds.estacion_id, dsd.tipo_cama_id, ds.fecha_confirmacion
