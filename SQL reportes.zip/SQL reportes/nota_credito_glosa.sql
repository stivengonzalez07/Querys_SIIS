SELECT ncg.prefijo, ncg.numero, ncg.fecha_registro, ncg.glosa_id, ncg.valor_glosa, 
ncg.valor_aceptado, g.prefijo, g.factura_fiscal,
(SELECT CASE WHEN ncg.sw_anular_factura='1' THEN 'SI'
	ELSE 'NO' END AS Devolucion_factura)
FROM notas_credito_glosas ncg
INNER JOIN glosas g ON(ncg.glosa_id=g.glosa_id)
WHERE ncg.fecha_registro::date BETWEEN _1 AND _2
ORDER BY(ncg.numero)