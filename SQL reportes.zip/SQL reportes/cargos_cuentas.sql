SELECT 
  a.numerodecuenta,
  CASE WHEN a.estado = '0' THEN 'FACTURADA'
       WHEN a.estado = '1' THEN 'ACTIVA'
       WHEN a.estado = '2' THEN 'INACTIVA'
       WHEN a.estado = '3' THEN 'CUADRADA'
       WHEN a.estado = '4' THEN 'ANTICIPOS'
       ELSE 'ANULADA' END AS estado_cta,
  a.fecha_registro::date AS fecha_cuenta, 
  a.fecha_cierre::date AS fec_cierre_cta, 
  d.descripcion AS departamento, e.cargo AS cod_tarifario,
  e.descripcion AS Actividad,
  bd.codigo_producto,
  ip.descripcion as nombre_producto,
  f.descripcion AS Grupo_actividad,
  g.plan_descripcion AS ENTIDAD,
  c.cantidad AS cant_cargo,
  cu.cargo, cu.descripcion,
  c.precio AS vlr_unt,
  c.valor_cargo AS vlr_total,
  c.valor_nocubierto,
  c.valor_cubierto, 
  c.fecha_cargo::date,
  c.fecha_registro::date as fecha_registro_cargo,
  (select max(fecha_registro)::date from auditoria_inactivar_cuentas where a.numerodecuenta=numerodecuenta) as fecha_registro_inactivo,
  i.fecha_registro::date as fecha_registro_salida,
  su.nombre AS usuario_cargo,
  CASE WHEN c.facturado = '0' THEN 'NO'
       WHEN c.facturado = '1' THEN 'SI'
       ELSE c.facturado END  AS cargo_facturado,
  c.paquete_codigo_id,
  CASE WHEN c.sw_paquete_facturado = '0' THEN 'NO'
       WHEN c.sw_paquete_facturado = '1' THEN 'SI'
       END  AS cargo_paquete_facturado,
  qx.cargo AS cargo_procedimiento,
  tdq.descripcion,
  qx.porcentaje,
  qx.tipo_cargo_qx_id
FROM 
  cuentas_detalle c
  LEFT JOIN cuentas_cargos_qx_procedimientos qx ON (c.transaccion=qx.transaccion)
  INNER JOIN cuentas a  ON c.numerodecuenta=a.numerodecuenta
  INNER JOIN departamentos d ON d.departamento=c.departamento_al_cargar
  INNER JOIN tarifarios_detalle e ON e.cargo=c.cargo AND c.tarifario_id=e.tarifario_id
  LEFT JOIN tarifarios_detalle tdq ON (qx.cargo=tdq.cargo AND qx.tarifario_id=tdq.tarifario_id)
  INNER JOIN grupos_tipos_cargo f ON f.grupo_tipo_cargo=e.grupo_tipo_cargo
  INNER JOIN planes g ON g.plan_id=a.plan_id
  LEFT JOIN system_usuarios su ON c.usuario_id=su.usuario_id
  LEFT JOIN ingresos_salidas i ON a.ingreso=i.ingreso
  LEFT JOIN bodegas_documentos_d bd ON c.consecutivo = bd.consecutivo
  LEFT JOIN inventarios_productos ip ON ip.codigo_producto = bd.codigo_producto
  LEFT JOIN cups cu ON c.cargo_cups=cu.cargo
WHERE
  a.estado!='5'
  and c.fecha_cargo::date BETWEEN _1 AND _2

