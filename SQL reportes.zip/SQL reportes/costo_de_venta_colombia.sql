SELECT      
            c.transaccion,
            c.cargo,
            a.fecha,
            a.numeracion,
            c.paquete_cargo_principal,
            a.observacion,
            b.total_costo_inv,
            b.codigo_producto,
            e.descripcion as descripcion_producto,
            b.fecha_vencimiento,
            b.lote,
            u.nombre AS usuario_transaccion,
            d.empresa_id,
            d.centro_utilidad,
            d.bodega,
            c.departamento,
            dpto.descripcion as descripcion_departamentos,
            ccd.centro_de_costo_id,
            c.numerodecuenta,
            e.grupo_id, 
            e.clase_id,
            e.subclase_id,         
            gcp.cuenta AS cuenta_contable,
            gcpe.cuenta as cuenta_excp,
            SUM(CASE WHEN c.cargo = 'IMD'  
            	THEN c.cantidad ELSE 0 END) as cantidad,
            SUM(CASE WHEN c.cargo = 'DIMD' 
            	THEN c.cantidad ELSE 0 END) as devolucion,
            SUM((CASE WHEN c.cargo = 'IMD'  
            	THEN  (b.cantidad * b.total_costo)  
            	ELSE 0 END)) as  costo_cargos,
            SUM((CASE WHEN c.cargo = 'DIMD'  
            	THEN  (b.cantidad * b.total_costo)  
            	ELSE 0 END)) as costo_devoluciones,
            e.porc_iva AS porcentaje_iva,
            p.plan_id,
            p.plan_descripcion,
            p.tipo_tercero_id,
            p.tercero_id

        FROM
            bodegas_documentos a
            INNER JOIN bodegas_documentos_d b ON (b.bodegas_doc_id = a.bodegas_doc_id AND b.numeracion = a.numeracion)
            INNER JOIN cuentas_detalle c ON (c.consecutivo = b.consecutivo)
            INNER JOIN departamentos dpto ON (c.departamento =dpto.departamento)
            INNER JOIN cuentas cu ON (c.numerodecuenta = cu.numerodecuenta)
            INNER JOIN planes p ON (cu.plan_id = p.plan_id)
            INNER JOIN bodegas_doc_numeraciones d ON (d.bodegas_doc_id = a.bodegas_doc_id)
            INNER JOIN inventarios_productos e ON (e.codigo_producto = b.codigo_producto)
            INNER JOIN system_usuarios u ON (a.usuario_id=u.usuario_id)
            INNER JOIN cg_conf.centros_de_costo_departamentos ccd ON (ccd.departamento=c.departamento)
            INNER JOIN cg_conf.doc_inv_cv01_03_costos_parametros gcp ON (e.grupo_id=gcp.grupo_id AND e.clase_id=gcp.clase_id AND e.subclase_id=gcp.subclase_id AND gcp.centro_de_costo_id=ccd.centro_de_costo_id )
 		    LEFT JOIN cg_conf.doc_inv_cv01_03_costos_parametros_excepciones gcpe ON (b.codigo_producto=gcpe.codigo_producto AND gcpe.centro_de_costo_id=ccd.centro_de_costo_id)
        WHERE
             a.fecha::date between _1 AND _2
            --a.fecha::date between '2021-05-18' AND '2021-06-19'
            AND c.cargo IN ('IMD','DIMD')
            AND d.empresa_id = '01'
        GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,29,30,31,32,33

        