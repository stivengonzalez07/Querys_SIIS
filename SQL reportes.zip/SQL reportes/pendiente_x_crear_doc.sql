SELECT      b.descripcion as Bodega,
            tm.codigo_producto,
            ip.descripcion,
            sum(tm.cantidad) AS cantidad,
            tm.fecha_vencimiento,
            tm.lote,
            su.nombre as nombre_usuario
           FROM inv_bodegas_movimiento_tmp_d tm
           INNER JOIN system_usuarios as su ON su.usuario_id = tm.usuario_id
           INNER JOIN inventarios_productos as ip ON tm.codigo_producto = ip.codigo_producto
           INNER JOIN bodegas as b ON b.bodega = tm.bodega
          GROUP BY b.descripcion, tm.codigo_producto, ip.descripcion, tm.fecha_vencimiento, tm.lote, su.nombre
