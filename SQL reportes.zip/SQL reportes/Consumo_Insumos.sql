SELECT        A.fecha_cargo,
               MAX (DP.descripcion) as descripcion_departamento,
               SUM (A.total_costo::integer) as total_costo
FROM        
               (
               SELECT        TO_CHAR(CD.fecha_cargo, 'YYYY-MM-DD') as fecha_cargo,
                               CD.departamento_al_cargar,
                               BDD.codigo_producto,
                               IP.descripcion as descripcion_producto,
                               IP.grupo_id as grupo_inventario,
                               CD.cargo,
                               CASE WHEN CD.cargo = 'IMD' THEN (BDD.total_costo * BDD.cantidad)
                               ELSE -(BDD.total_costo * BDD.cantidad) END AS total_costo
               FROM        cuentas_detalle CD,
                               bodegas_documentos_d BDD,
                               inventarios_productos IP
               WHERE        CD.consecutivo = BDD.consecutivo
               AND     BDD.codigo_producto = IP.codigo_producto
               AND     IP.grupo_id IN ('02','04')
               AND     CD.valor_cargo <> 0
	       AND     CD.fecha_cargo>=_1
               AND     CD.fecha_cargo<=_2
               
               ORDER BY CD.transaccion, fecha_cargo, CD.departamento_al_cargar, IP.grupo_id
               ) as A,
               departamentos DP
WHERE        A.departamento_al_cargar = DP.departamento
GROUP BY A.fecha_cargo, A.departamento_al_cargar, A.grupo_inventario
ORDER BY A.fecha_cargo, A.departamento_al_cargar, A.grupo_inventario