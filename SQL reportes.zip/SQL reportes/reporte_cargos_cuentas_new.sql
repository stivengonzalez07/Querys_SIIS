SELECT DISTINCT
ffc.factura_fiscal as nro_factura,
fc.fecha_registro as fecha_factura,
a.numerodecuenta,
CASE WHEN a.estado = '0' THEN 'FACTURADA'
     WHEN a.estado = '1' THEN 'ACTIVA'
     WHEN a.estado = '2' THEN 'INACTIVA'
     WHEN a.estado = '3' THEN 'CUADRADA'
     WHEN a.estado = '4' THEN 'ANTICIPOS'
     ELSE 'ANULADA' END AS estado_cta,
g.plan_descripcion AS plan_descripcion,
su.nombre AS usuario_cargo,
d.descripcion,
e.cargo,
e.descripcion AS Cargo, 
moc.numero as cuenta_contable,
c.centro_de_costo_id,
cc.descripcion, ---centro de costo descripcion
c.valor_cargo AS vlr_total,
c.cantidad AS cant_cargo
FROM 
cuentas_detalle c 
INNER JOIN cuentas a  ON (c.numerodecuenta=a.numerodecuenta)
LEFT JOIN fac_facturas_cuentas as ffc ON (ffc.numerodecuenta = a.numerodecuenta)
INNER JOIN fac_facturas as fc ON (fc.factura_fiscal = ffc.factura_fiscal)
INNER JOIN departamentos d ON (d.departamento=c.departamento_al_cargar)
INNER JOIN tarifarios_detalle e ON (e.cargo=c.cargo AND c.tarifario_id=e.tarifario_id)
INNER JOIN grupos_tipos_cargo f ON (f.grupo_tipo_cargo=e.grupo_tipo_cargo)
INNER JOIN planes g ON (g.plan_id=a.plan_id)
INNER JOIN system_usuarios su ON (c.usuario_id=su.usuario_id)
INNER JOIN ingresos ig ON (a.ingreso = ig.ingreso)
LEFT JOIN ingresos_salidas i ON (a.ingreso=i.ingreso)
LEFT JOIN cg_conf.centros_de_costo cc ON (c.centro_de_costo_id=cc.centro_de_costo_id)
LEFT JOIN cg_mov_01.cg_mov_contable_01 moc ON (fc.factura_fiscal = moc.numero AND fc.prefijo = moc.prefijo)
--WHERE  a.estado!='5' and a.fecha_registro::date BETWEEN _1 AND _2
WHERE  a.estado!='5' and a.fecha_registro::date BETWEEN '2021-09-01 08:31:09' AND '2021-09-08 10:45:16'