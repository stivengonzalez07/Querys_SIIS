SELECT 
 a.fecha_registro,
 b.codigo_producto,
 b.descripcion,
 a.ingreso,
 c.numerodecuenta,
 c.estado,
 e.primer_nombre,
 e.segundo_nombre,
 e.primer_apellido,e.segundo_apellido,
 e.tipo_id_paciente,
 e.paciente_id
FROM
 hc_justificaciones_no_pos_hospitalaria_medicamentos as a,
 inventarios_productos as b,
 ingresos as d,
 pacientes as e,
 cuentas as c
WHERE
 a.codigo_producto=b.codigo_producto
 AND a.ingreso=d.ingreso
 AND d.paciente_id=e.paciente_id
 AND c.ingreso=a.ingreso
 AND a.fecha_registro between _1 and _2

