SELECT
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
hcos.tipo_id_paciente,
hcos.paciente_id,
he.ingreso,
c.numerodecuenta,
c.estado,
CASE WHEN cu.sw_pos ='1' THEN 'POS'
    when  cu.sw_pos='0' THEN 'NO POS'  END,
hcos.fecha_solicitud,
cu.cargo,
cu.descripcion

FROM
hc_os_solicitudes hcos
INNER JOIN hc_evoluciones he ON he.evolucion_id=hcos.evolucion_id
INNER JOIN ingresos i ON i.ingreso=he.ingreso
INNER JOIN pacientes p ON i.paciente_id=p.paciente_id
INNER JOIN cuentas c ON c.ingreso=i.ingreso
LEFT JOIN cups cu  ON cu.cargo=hcos.cargo

WHERE hcos.fecha_solicitud BETWEEN _1 AND _2

