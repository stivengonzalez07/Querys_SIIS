SELECT
   b.prefijo,
   b.factura_fiscal,
   n.numerodecuenta AS cuenta,
   b.total_factura,
   pp.primer_nombre,
   pp.segundo_nombre,
   pp.primer_apellido,
   pp.segundo_apellido,
   i.paciente_id,
   i.tipo_id_paciente,
   d.nombre AS usuario_facturo,
   to_char (b.fecha_registro, 'YYYY-MM-DD') AS fecha_factura,
   p.plan_descripcion,
   a.observacion AS Motivo_Anulacion,
   to_char (a.fecha_registro, 'YYYY-MM-DD') AS fecha_anulacion,
   c.nombre AS usuario_anulo,
   acaf.nota_credito_id AS NCA_ID
FROM
   auditoria_anulacion_fac_facturas a 
   JOIN
      fac_facturas b 
      ON (a.empresa_id = b.empresa_id 
      AND a.prefijo = b.prefijo 
      AND a.factura_fiscal = b.factura_fiscal) 
   JOIN
      planes p 
      ON (p.plan_id = b.plan_id) 
   JOIN
      system_usuarios c 
      ON (a.usuario_id = c.usuario_id) 
   JOIN
      system_usuarios d 
      ON (b.usuario_id = d.usuario_id) 
   JOIN
      fac_facturas_cuentas n 
      ON(n.empresa_id = b.empresa_id 
      AND n.prefijo = b.prefijo 
      AND n.factura_fiscal = b.factura_fiscal) 
   JOIN
      cuentas cc 
      ON(cc.numerodecuenta = n.numerodecuenta) 
   JOIN
      ingresos i 
      ON(i.ingreso = cc.ingreso) 
   JOIN
      pacientes pp 
      ON(pp.paciente_id = i.paciente_id 
      AND pp.tipo_id_paciente = i.tipo_id_paciente)
   JOIN
      notas_credito_anulacion_facturas acaf
      ON (a.prefijo = acaf.prefijo_factura
      AND a.factura_fiscal = acaf.factura_fiscal)
WHERE
   a.fecha_registro::DATE BETWEEN _1 AND _2;

