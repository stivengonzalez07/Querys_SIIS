SELECT
dn.empresa_id,
dn.centro_utilidad,
dn.bodega,
f.descripcion as descripcion_bodega,
cd.departamento,
g.descripcion as descripcion_departamento,
ep.grupo_id,
ep.clase_id,
ep.subclase_id,
bdd.codigo_producto,
ep.descripcion as descripcion_producto,

case    when a.cuenta is not null then a.cuenta
                when b.cuenta is not null then b.cuenta
                when c.cuenta is not null then c.cuenta
                when d.cuenta is not null then d.cuenta
                when a.cuenta is null then (select xx.cuenta from cg_conf.doc_fv01_inv_grupos_productos_por_cc xx where cd.empresa_id = xx.empresa_id and ip.grupo_id = xx.grupo_id and ip.clase_id = xx.clase_id and ip.subclase_id = xx.subclase_id  limit 1)
            else 'Sin Parametrizacion'
        end as cuenta,
        case    when a.cuenta is not null then ccp.centro_de_costo_id
                when b.cuenta is not null then b.centro_costo_destino
                when c.cuenta is not null then ccp.centro_de_costo_id
                when d.cuenta is not null then d.centro_costo_destino
                when d.cuenta is null then (select xx.centro_costo_destino from cg_conf.doc_fv01_inv_grupos_productos_por_cc xx where cd.empresa_id = xx.empresa_id and ip.grupo_id = xx.grupo_id and ip.clase_id = xx.clase_id and ip.subclase_id = xx.subclase_id  limit 1)
            else 'Sin Parametrizacion'
        end as centro_costo
FROM
bodegas_documentos ad
INNER JOIN bodegas_documentos_d bdd ON (ad.bodegas_doc_id=bdd.bodegas_doc_id AND  ad.numeracion=bdd.numeracion)
INNER JOIN cuentas_detalle cd ON (bdd.consecutivo = cd.consecutivo)
join tarifarios_detalle td on (cd.tarifario_id = td.tarifario_id and cd.cargo = td.cargo)--nuevo
join bodegas_documentos_d bd on (cd.consecutivo = bd.consecutivo)--nuevo
join inventarios_productos ip on (bd.codigo_producto = ip.codigo_producto)--nuevo
INNER JOIN bodegas_doc_numeraciones dn ON (ad.bodegas_doc_id= dn.bodegas_doc_id)
INNER JOIN inventarios_productos ep ON ( bd.codigo_producto=ep.codigo_producto)
INNER JOIN bodegas f ON (dn.bodega=f.bodega)
INNER JOIN departamentos g ON (cd.departamento = g.departamento) 
join cg_conf.centros_de_costo_departamentos ccp on (cd.departamento = ccp.departamento)
join cuentas cu on (cd.numerodecuenta = cu.numerodecuenta)
left join cg_conf.doc_fv01_inv_productos a on (cd.empresa_id = a.empresa_id and ip.codigo_producto = a.codigo_producto)
left join cg_conf.doc_fv01_inv_productos_por_cc b on (cd.empresa_id = b.empresa_id and ip.codigo_producto = b.codigo_producto and ccp.centro_de_costo_id = b.centro_de_costo_id)
left join cg_conf.doc_fv01_inv_grupos_productos c on (cd.empresa_id = c.empresa_id and ip.grupo_id = c.grupo_id and ip.clase_id = c.clase_id and ip.subclase_id = c.subclase_id)
left join cg_conf.doc_fv01_inv_grupos_productos_por_cc d on (cd.empresa_id = d.empresa_id and ip.grupo_id = d.grupo_id and ip.clase_id = d.clase_id and ip.subclase_id = d.subclase_id and ccp.centro_de_costo_id = d.centro_de_costo_id)

WHERE
ad.fecha >= _1 AND ad.fecha <= _2
--ad.fecha >= '2021-01-18' AND ad.fecha <= '2021-11-19'
AND ((cd.paquete_codigo_id IS NULL AND cd.facturado = '1') OR (cd.paquete_codigo_id IS NOT NULL AND cd.sw_paquete_facturado = '1'))
AND cd.cargo IN ('IMD','DIMD')
AND dn.empresa_id = '01'
AND ad.sw_existencias = '1'
AND cu.estado != '5'
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13