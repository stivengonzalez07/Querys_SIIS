SELECT 
ffc.numerodecuenta, ffc.prefijo, ffc.factura_fiscal, ff.total_factura, c.fecha_registro AS fecha_cuenta
,
CASE  
WHEN ff.estado = '0' THEN 'ACTIVA'
WHEN ff.estado = '1' THEN 'PAGADA'
WHEN ff.estado = '2' THEN 'FACTURA AGRUPADA ANULADA'
WHEN ff.estado = '3' THEN 'ANULADA'
WHEN ff.estado IS NULL THEN 'SIN FACTURA'
ELSE 'SIN ESTADO'
END AS estado_factura

FROM 
fac_facturas_cuentas ffc, fac_facturas ff, cuentas c

WHERE ffc.factura_fiscal = ff.factura_fiscal
AND ffc.prefijo = ff.prefijo
AND ffc.numerodecuenta = c.numerodecuenta
--AND ff.estado != '1'
--AND ff.estado != '2'
AND c.fecha_registro::date BETWEEN _1 AND _2