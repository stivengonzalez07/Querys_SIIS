SELECT c.numerodecuenta AS Cuenta, 
	p.paciente_id, 
	p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS Nombre,
	pl.plan_descripcion AS Plan,
	ce.descripcion AS Estado, 
	c.total_cuenta::integer, 
	d.descripcion AS Departamento,
	tc.descripcion AS Especialidad,
	su.nombre AS Usuario
FROM cuentas c
      LEFT JOIN os_maestro os
      ON c.numerodecuenta=os.numerodecuenta
      LEFT JOIN tipos_consultas_cargos tcc
      ON os.cargo_cups = tcc.cargo_cita
      LEFT JOIN tipos_consulta tc
      ON tc.tipo_consulta_id = tcc.tipo_consulta_id,  
     cuentas_estados ce, 
     pacientes p, 
     planes pl, 
     departamentos d, 
     ingresos i, 
     system_usuarios su
WHERE p.paciente_id=i.paciente_id
AND c.ingreso=i.ingreso
AND i.departamento_actual=d.departamento
AND c.plan_id=pl.plan_id
AND c.estado=ce.estado
AND i.usuario_id=su.usuario_id
AND i.fecha_ingreso::date >= _1 
AND i.fecha_ingreso::date <= _2
ORDER BY 1