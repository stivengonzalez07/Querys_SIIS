SELECT a.bodega,
d.bodega_destino,
b.descripcion,
a.prefijo,
SUM (a.total_costo)::INTEGER as costo
FROM inv_bodegas_movimiento as a inner join documentos as b on a.documento_id=b.documento_id and a.prefijo=b.prefijo
     inner join tipos_doc_generales as c on b.tipo_doc_general_id=c.tipo_doc_general_id
     inner join inv_bodegas_movimiento_traslados as d on a.prefijo=d.prefijo and a.numero=d.numero
                                       
WHERE a.fecha_registro::date >= _1
AND   a.fecha_registro::date <= _2 
GROUP BY a.bodega,d.bodega_destino,b.descripcion,a.prefijo 
ORDER BY 1