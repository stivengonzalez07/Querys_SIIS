SELECT
n.prefijo,
n.nota_credito_id,
n.prefijo_factura,
n.factura_fiscal,
n.valor_nota,
n.fecha_registro,
n.observacion,
n.tipo_id_tercero,
n.tercero_id,
t.nombre_tercero
FROM
notas_credito AS n
LEFT JOIN terceros AS t ON ( n.tipo_id_tercero=t.tipo_id_tercero AND n.tercero_id=t.tercero_id ) 
WHERE n.fecha_registro::date BETWEEN 
_1 AND _2
--'2021-09-07' AND '2021-11-09'