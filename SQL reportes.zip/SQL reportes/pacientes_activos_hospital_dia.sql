SELECT 		p.primer_nombre,
			p.segundo_nombre,
			p.primer_apellido,
			p.segundo_apellido,
			os.paciente_id,
			omc.cantidad,
			omc.cantidad_pendiente
FROM		os_maestro_cargos omc,
			os_maestro om,
			os_ordenes_servicios os,
			pacientes p
WHERE		omc.numero_orden_id = om.numero_orden_id
AND			omc.cantidad_pendiente != 0
AND			om.orden_servicio_id = os.orden_servicio_id
AND			os.paciente_id = p.paciente_id
AND			os.departamento IN('HOS003','HOS004','HOS005','HOS006')
GROUP BY 1,2,3,4,5,6,7