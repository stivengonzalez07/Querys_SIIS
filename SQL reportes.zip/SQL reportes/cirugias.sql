select distinct a.ingreso,
		i.tipo_id_paciente, 
		i.paciente_id,
		j.primer_apellido || j.segundo_apellido || j.primer_nombre || j.segundo_nombre as nombre_paciente,
		a.plan_id,
		b.fecha_cirugia,
		b.duracion_cirugia,
		b.fecha_registro,
		c.cargo_cups,
		d.descripcion,
		f.descripcion as via_acceso,
		k.descripcion as descripcion_cirugia,
		l.descripcion as hallazgo_cirugia
  
 from cuentas as a inner join cuentas_liquidaciones_qx as b on a.ingreso=b.ingreso and a.numerodecuenta=b.numerodecuenta
      inner join cuentas_liquidaciones_qx_procedimientos as c on b.cuenta_liquidacion_qx_id=c.cuenta_liquidacion_qx_id
      inner join cups as d on c.cargo_cups=d.cargo
      inner join qx_vias_acceso as f on b.via_acceso=f.via_acceso
      inner join ingresos as i on a.ingreso = i.ingreso
      inner join hc_descripcion_cirugia as k on k.ingreso = i.ingreso
      left join hc_hallazgos_quirurgicos l on l.ingreso = i.ingreso
      inner join pacientes as j on i.tipo_id_paciente = j.tipo_id_paciente and i.paciente_id  = j.paciente_id

where b.fecha_cirugia::date >= _1
AND   b.fecha_cirugia::date <= _2
AND   b.estado  != '3' and a.estado != '5' 

