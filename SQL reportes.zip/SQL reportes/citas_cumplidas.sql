SELECT  DISTINCT i.ingreso,
      	i.paciente_id,
      	i.tipo_id_paciente,
		p.fecha_nacimiento,
		edad(p.fecha_nacimiento) as edad,
      	to_char(i.fecha_ingreso, 'DD-MM-YYYY') as  fecha_ingreso,
      	to_char(i.fecha_ingreso,'HH24:MI:SS') as hora,
      	p.primer_apellido,
        p.segundo_apellido,
        p.primer_nombre,
        p.segundo_nombre,
      	pl.plan_descripcion,
	    s.nombre as doctor,
		es.descripcion as especialidad,
      	c.valor_total_paciente
FROM    pacientes p,
      	planes pl,
      	ingresos i,
      	hc_evoluciones e,
      	cuentas c,
	    system_usuarios s,
		especialidades es,
	    profesionales pro,
		profesionales_especialidades proe,
	    tipos_profesionales tpro
WHERE   i.paciente_id = p.paciente_id
AND     i.tipo_id_paciente = p.tipo_id_paciente
AND     c.ingreso = i.ingreso
AND     pro.tercero_id = proe.tercero_id
AND     proe.especialidad = es.especialidad
AND     c.plan_id = pl.plan_id
AND		i.departamento = 'CEXTER'
AND     i.ingreso = e.ingreso
AND		e.usuario_id = s.usuario_id
AND		e.usuario_id = pro.usuario_id
AND		s.usuario_id = pro.usuario_id
AND		pro.tipo_profesional = tpro.tipo_profesional
AND		i.fecha_ingreso::date >= _1 
AND 	i.fecha_ingreso::date <= _2
ORDER BY    pl.plan_descripcion
