select
p.tipo_id_paciente as tipo_identificacion,
p.paciente_id as numero_identificacion,
(pc.primer_apellido||' '|| pc.segundo_apellido||' '|| pc.primer_nombre|| ' ' ||pc.segundo_nombre) AS nombre_paciente,
e.plan_descripcion As plan,
p.fecha_registro AS fecha_programacion,
su.nombre as usuario_cancelo,
c.observacion,
c.fecha_registro::date AS fecha_cancelacion,
m.descripcion as motivo_cancelacion
from
qx_programaciones p,
qx_programaciones_canceladas c,
qx_motivos_cancelacion_programaciones m,
pacientes pc,
system_usuarios su,
planes e
where p.programacion_id=c.programacion_id and
p.paciente_id=pc.paciente_id and
su.usuario_id=c.usuario_id and
c.qx_motivo_cancelacion_programacion_id=m.qx_motivo_cancelacion_programacion_id and p.plan_id=e.plan_id and
c.fecha_registro::date BETWEEN _1 AND _2
--c.fecha_registro::date BETWEEN '2021-01-01' AND '2021-01-30'
order by fecha_cancelacion

