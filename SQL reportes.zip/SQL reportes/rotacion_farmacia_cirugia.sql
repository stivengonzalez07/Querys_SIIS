SELECT SUM(e.existencia_actual) AS Existencias_Productos,
e.codigo_producto AS codigo_producto,
ip.descripcion AS Nombre_producto,
e.bodega AS codigo_bodega,
bo.descripcion AS descripcion_bodega,

--DEVOLUCION
idd.cantidad AS devoluciones,

--EGRESO
ibm.cantidad AS EGRESOS,

--DEVOLUCIONES + EGRESO = SALIDAS
ibm.cantidad + idd.cantidad AS SALIDAS,

--DESPACHOS
dmed.cantidad AS DESPACHOS,

--TOTAL 
(ibm.cantidad + idd.cantidad) - (dmed.cantidad) AS TOTAL

FROM
 inventarios_productos ip, existencias_bodegas_lote_fv e, bodegas bo, 
 inv_solicitudes_devolucion id, inv_solicitudes_devolucion_d idd,  --PARA SACAR DEVOLUCIONES
 inv_bodegas_movimiento_d ibm, --EGRESO

 bodegas_documento_despacho_med bdm , bodegas_documento_despacho_med_d dmed

 WHERE ip.codigo_producto=e.codigo_producto
 AND e.bodega = bo.bodega
 
 AND idd.codigo_producto = e.codigo_producto  --RELACION PARA SACAR DEVOLUCIONES
 AND idd.documento = id.documento
 
 AND ibm.codigo_producto = e.codigo_producto  --RELACION EGRESOS
 AND ibm.bodega = bo.bodega

 AND bdm.documento_despacho_id=dmed.documento_despacho_id --RELACION DESPACHOS
 AND dmed.codigo_producto=e.codigo_producto

 AND bo.bodega = 'BC'
 --AND ip.fecha_registro::date BETWEEN '2021-04-15' AND '2021-08-30'
 AND ip.fecha_registro::date BETWEEN _1 AND _2

 GROUP BY e.codigo_producto,ip.descripcion , e.bodega, bo.descripcion
 ,idd.cantidad , ibm.cantidad  , dmed.cantidad
