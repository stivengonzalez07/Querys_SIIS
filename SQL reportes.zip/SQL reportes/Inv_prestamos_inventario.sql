SELECT
i.prefijo,
i.numero,
i.observacion,
mo.tercero_id,
t.nombre_tercero AS nombre_proveedor,
i.fecha_registro,
i.total_costo

FROM
inv_bodegas_movimiento i

LEFT JOIN cg_mov_01.cg_mov_contable_01 mo ON i.prefijo=mo.prefijo AND i.numero=mo.numero 
LEFT JOIN terceros t ON mo.tercero_id=t.tercero_id

WHERE i.fecha_registro BETWEEN _1 AND _2
AND i.prefijo in ( 'EPE', 'IPE' )