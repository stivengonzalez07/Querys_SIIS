SELECT 
c.numerodecuenta
,p.tipo_id_paciente
,p.paciente_id
,p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS Nombre
,ipd.codigo_producto
,ipd.descripcion
,cd.cantidad
,cd.precio AS Valor_unitario
,cd.valor_cargo AS Valor_total
,bd.lote
,ipd.referencia AS referencia
,ipd.codigo_barras AS codigo_barras
,isub.descripcion AS Casa_medica
FROM cuentas_detalle cd
INNER JOIN cuentas c ON (c.numerodecuenta=cd.numerodecuenta)
INNER JOIN ingresos i ON (i.ingreso=c.ingreso)
INNER JOIN pacientes p ON (p.tipo_id_paciente=i.tipo_id_paciente AND p.paciente_id=i.paciente_id)
INNER JOIN bodegas_documentos_d bd ON (bd.consecutivo=cd.consecutivo)
INNER JOIN inventarios_productos ipd ON (ipd.codigo_producto = bd.codigo_producto)
INNER JOIN inv_grupos_inventarios igub ON (igub.grupo_id = ipd.grupo_id)
INNER JOIN inv_clases_inventarios icub ON (icub.clase_id = ipd.clase_id AND icub.grupo_id=igub.grupo_id)
INNER JOIN inv_subclases_inventarios isub ON (isub.subclase_id = ipd.subclase_id AND isub.clase_id = icub.clase_id AND isub.grupo_id = igub.grupo_id)
WHERE
igub.grupo_id='03'
AND icub.clase_id='01'
AND cd.facturado = '1'
AND cd.fecha_cargo::DATE BETWEEN '2021-11-30' AND '2021-12-31'
