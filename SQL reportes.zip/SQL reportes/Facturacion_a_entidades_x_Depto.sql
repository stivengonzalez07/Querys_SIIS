SELECT de.departamento,
de.descripcion,
SUM(cd.valor_cubierto::integer) as valor,
c.numerodecuenta,
ff.prefijo||' '||ff.factura_fiscal as factura,
ff.total_factura,
ff.tipo_id_tercero||' '||ff.tercero_id as tercero_id,
t.nombre_tercero			   
FROM  cuentas_detalle cd 
INNER JOIN cuentas c ON cd.numerodecuenta=c.numerodecuenta
INNER JOIN fac_facturas_cuentas ffc ON c.numerodecuenta=ffc.numerodecuenta
INNER JOIN fac_facturas ff ON ffc.prefijo=ff.prefijo AND ffc.factura_fiscal=ff.factura_fiscal
INNER JOIN departamentos de ON cd.departamento=de.departamento
INNER JOIN terceros t ON ff.tipo_id_tercero=t.tipo_id_tercero AND ff.tercero_id=t.tercero_id
WHERE  cd.facturado='1'
AND (cd.sw_paquete_facturado IS NULL OR cd.sw_paquete_facturado='1')
AND ff.estado NOT IN ('2','3')
AND ff.tipo_factura != '0'
AND ff.fecha_registro::DATE BETWEEN _1 AND _2
GROUP BY 1,2,4,5,6,7,8
ORDER BY 5

