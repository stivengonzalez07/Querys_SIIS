SELECT
hoc.hc_nota_operatoria_cirugia_id,
qq.descripcion,
hoc.hora_inicio,
hoc.hora_fin,
su.nombre AS usuario_creacion,
hoc.programacion_id,
hoc.tipo_id_anestesiologo,
hoc.anestesiologo_id AS anestesiologo_identificacion,
hoc.tipo_id_instrumentista,
hoc.instrumentista_id AS instrumentista_identificacion,
hoc.tipo_id_circulante,
hoc.circulante_id AS circulante_identificacion,
hoc.tipo_id_ayudante,
hoc.ayudante_id AS ayudante_identificacion,
hoc.tipo_id_cirujano,
hoc.cirujano_id AS cirujano_identificacion,
hoc.acto_quiru

FROM
hc_notas_operatorias_cirugias AS hoc
INNER JOIN system_usuarios AS su ON ( hoc.usuario_id = su.usuario_id )
INNER JOIN qx_quirofanos AS qq ON ( hoc.quirofano_id=qq.quirofano )

WHERE hoc.fecha_registro::date
 BETWEEN _1 AND _2
--BETWEEN '2021-09-07 08:31:09' AND '2021-09-08 10:45:16'


