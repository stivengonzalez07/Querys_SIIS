SELECT * 
FROM cg_conf.cg_plan_de_cuentas