SELECT i.ingreso,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
de.tipo_diagnostico_id

FROM ingresos i,
ingresos_salidas s,
pacientes p,
planes pl,
hc_diagnosticos_egreso de,
cuentas c,
hc_evoluciones he

WHERE   i.ingreso = s.ingreso
AND     c.plan_id = pl.plan_id
AND     i.ingreso = c.ingreso
AND     i.ingreso = he.ingreso
AND     p.paciente_id = i.paciente_id
AND     de.evolucion_id = he.evolucion_id
AND     i.fecha_ingreso::date <= _1
AND     s.fecha_registro::date <= _2
ORDER BY i.ingreso
	