SELECT
a.prefijo, a.factura_fiscal, g.plan_descripcion AS ENTIDAD,
CASE WHEN b.sw_tipo = '0' THEN 'FACTURA PACIENTE'
     WHEN b.sw_tipo = '1' THEN 'CLIENTE'
     ELSE 'PARTICULAR' END AS tipo_factura,
a.fecha_registro AS fecha_factura, c.numerodecuenta, ins.fecha_registro AS fecha_salida, d.descripcion AS departamento,
e.descripcion AS Actividad,
f.descripcion AS Grupo_actividad,
c.cantidad AS cant_cargo, c.precio AS vlr_unt, c.valor_cargo AS vlr_total, c.valor_nocubierto, c.valor_cubierto, c.fecha_cargo
FROM
fac_facturas a
INNER JOIN fac_facturas_cuentas b ON a.factura_fiscal=b.factura_fiscal AND a.prefijo=b.prefijo
INNER JOIN cuentas_detalle c ON c.numerodecuenta=b.numerodecuenta
INNER JOIN departamentos d ON d.departamento=c.departamento_al_cargar
INNER JOIN tarifarios_detalle e ON e.cargo=c.cargo AND c.tarifario_id=e.tarifario_id
INNER JOIN grupos_tipos_cargo f ON f.grupo_tipo_cargo=e.grupo_tipo_cargo
INNER JOIN planes g ON g.plan_id=a.plan_id
INNER JOIN cuentas cue ON c.numerodecuenta=cue.numerodecuenta
INNER JOIN ingresos ing ON cue.ingreso=ing.ingreso
INNER JOIN ingresos_salidas ins ON ins.ingreso=ing.ingreso


WHERE
a.estado IN ('0', '1')
AND
a.fecha_registro::date BETWEEN _1 AND _2

