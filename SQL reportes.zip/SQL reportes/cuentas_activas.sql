SELECT 	i.ingreso,
        i.fecha_ingreso,
        i.tipo_id_paciente,
	i.paciente_id,       
        pt.primer_nombre,
        pt.segundo_nombre,
        pt.primer_apellido,
        pt.segundo_apellido,
        p.plan_descripcion,
        c.numerodecuenta,
        c.fecha_registro as fecha_cuenta,
        c.total_cuenta as precio_cargo,
        c.valor_descuento_empresa,
        c.valor_descuento_paciente,
        C.Valor_cuota_paciente as valor_copago,
        c.valor_cuota_moderadora,
        c.valor_total_empresa as total_neto, 
        ce.descripcion as estado,
        d.descripcion as departamento
      
     
FROM    cuentas c,
        cuentas_estados ce,
        departamentos d,
	ingresos i,
        pacientes pt,
        planes p

WHERE   c.estado = ce.estado
AND     NOT (c.estado ='0' OR c.estado ='4' OR  c.estado ='5' OR c.estado ='6')
AND     c.departamento = d.departamento
AND     pt.paciente_id = i.paciente_id
AND     i.ingreso = c.ingreso
AND     c.plan_id = p.plan_id
AND     c.fecha_registro::date >= _1
AND     c.fecha_registro::date <= _2
ORDER BY numerodecuenta;
