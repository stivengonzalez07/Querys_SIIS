SELECT FD.factura_fiscal as Factura,F.fecha_registro::date as Fecha, DD.codigo_producto,DD.lote,IV.descripcion as Producto,DD.cantidad::integer,(LP.precio*DD.cantidad)::integer as Valor
FROM   facturas_documentos_bodega FD,
      bodegas_documentos_d DD,
      inventarios_productos IV,
      fac_facturas F,
      listas_precios_detalle LP
WHERE  FD.bodegas_doc_id = DD.bodegas_doc_id
AND    FD.bodegas_numeracion = DD.numeracion
AND    DD.codigo_producto = IV.codigo_producto
AND    FD.factura_fiscal=F.factura_fiscal
AND    LP.codigo_producto=DD.codigo_producto
AND    LP.codigo_producto=IV.codigo_producto
AND    F.fecha_registro::date >= _1
AND    F.fecha_registro::date <= _2
ORDER BY F.fecha_registro,IV.descripcion