SELECT SUM(e.existencia_actual) AS Existencias_Productos,
e.codigo_producto AS codigo_producto,
ip.descripcion AS Nombre_producto,
e.bodega AS codigo_bodega,
bo.descripcion AS descripcion_bodega

FROM
 inventarios_productos ip, existencias_bodegas_lote_fv e, bodegas bo

 WHERE ip.codigo_producto=e.codigo_producto
 AND e.bodega = bo.bodega
 AND bo.bodega = 'BC' --FARMACIA CIRUGIA
 --AND ip.fecha_registro::date BETWEEN '2017-01-01' AND '2021-09-01'
 --AND ip.fecha_registro::date BETWEEN _1 AND _2
 
 GROUP BY e.codigo_producto,ip.descripcion , e.bodega, bo.descripcion