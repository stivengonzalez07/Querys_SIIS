SELECT lpd.empresa_id, lpd.codigo_producto, ip.descripcion, lpd.precio, lpd.codigo_lista, lp.descripcion as descripcion_lista, 
lpd.fecha_registro, lpd.codigo_alterno, lpd.descripcion_alterna
FROM listas_precios_detalle lpd 
join listas_precios lp ON(lp.codigo_lista=lpd.codigo_lista)
join inventarios_productos ip ON(ip.codigo_producto=lpd.codigo_producto)
