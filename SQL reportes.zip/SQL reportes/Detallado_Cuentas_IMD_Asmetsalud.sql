select  a.numerodecuenta,c.ingreso,g.fecha_ingreso,
a.departamento,
f.descripcion,
a.tarifario_id,
a.cargo,
a.cantidad,
a.precio,
a.valor_cargo,
d.codigo_producto,
d.descripcion,
a.fecha_cargo as fecha_cargo_producto
 from 
 cuentas_detalle a,
 bodegas_documentos_d b,
 cuentas c,
 inventarios_productos d,
 planes e,
 departamentos f,
 ingresos g
 where
c.plan_id=e.plan_id AND
a.numerodecuenta=c.numerodecuenta AND
a.consecutivo=b.consecutivo AND
b.codigo_producto=d.codigo_producto AND
c.estado!='5' and
a.departamento=f.departamento and 
e.tercero_id='817000248' and 
c.ingreso=g.ingreso and
c.fecha_registro::date BETWEEN _1 AND _2