 select h.fecha_solicitud,c.descripcion_solicitud,j.descripcion,count(*)
 from dietas_solicitud_detalle a, ingresos b, dietas_tipos_solicitud c,  
 estaciones_enfermeria g,dietas_solicitud h, pacientes i,hc_tipos_dieta j where a.tipo_solicitud_dieta_id=c.tipo_solicitud_dieta_id and
 a.ingreso_id=b.ingreso and a.estacion_id=g.estacion_id and a.ingreso_id=h.ingreso_id and 
 a.fecha_solicitud=h.fecha_solicitud and a.tipo_solicitud_dieta_id=h.tipo_solicitud_dieta_id and b.tipo_id_paciente=i.tipo_id_paciente  and
 b.paciente_id=i.paciente_id and h.fecha_solicitud BETWEEN _1 AND _2 and a.hc_dieta_id=j.hc_dieta_id and h.estado_dieta in ('1','2')
group by h.fecha_solicitud,c.descripcion_solicitud,j.descripcion order by h.fecha_solicitud,c.descripcion_solicitud,j.descripcion