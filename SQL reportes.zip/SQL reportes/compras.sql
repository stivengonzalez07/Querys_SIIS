select * from(
select
cr.requisicion_id,
cr.fecha_requisicion as fecha_recepcion_requisicion,
d.descripcion as area_solicitante,
ip.codigo_producto as codigo,
ip.descripcion as descripcion_producto,
u.descripcion as unidad_de_manejo, 
crd.cantidad::int as cantidad_requisicion,
cro.orden_pedido_id as orden_de_compra

from 
compras_requisiciones_detalle crd  
LEFT OUTER JOIN compras_requisiciones cr ON cr.requisicion_id=crd.requisicion_id
LEFT OUTER JOIN inventarios_productos ip ON crd.codigo_producto=ip.codigo_producto
LEFT OUTER JOIN unidades u ON ip.unidad_id=u.unidad_id
LEFT OUTER JOIN departamentos d ON d.departamento=cr.departamento

join compras_requisiciones_ordenes cro ON cro.requisicion_id=crd.requisicion_id) a

left join (
select 
cop.orden_pedido_id as orden_de_compra,
copd.numero_unidades::int as cantidad_solicitada_oc,
copd.valor as precio_unitario_oc,
copd.porc_iva as iva,
(nullif(ibmocd.total_costo,0)/nullif(ibmocd.cantidad,0)) as precio_factura,
((nullif(ibmocd.total_costo,0)/nullif(ibmocd.cantidad,0)) - copd.valor) as diferencia,
(copd.numero_unidades*copd.valor) as valor_total_oc_enviada,
t.nombre_tercero as proveedor,
copd.codigo_producto as codigo,
cop.fecha_envio as fecha_envio_oc,
cop.fecha_registro,
(case when copd.numero_unidades_recibidas is not null then copd.numero_unidades_recibidas else 0 end )::int as cantidad_recibida,
(copd.numero_unidades - (case when copd.numero_unidades_recibidas is not null then copd.numero_unidades_recibidas else 0 end )):: int as faltantes,
ibmoc.fecha_factura  as fecha_recibido,
ibm.fecha_registro:: date as fecha_ingreso_al_sistema,
ibm.prefijo as prefijo_documento_ingreso,
ibm.numero as numero_doc_ingreso

from
compras_ordenes_pedidos cop
LEFT OUTER JOIN compras_ordenes_pedidos_detalle copd on copd.orden_pedido_id=cop.orden_pedido_id
LEFT OUTER JOIN terceros_proveedores tp on cop.codigo_proveedor_id=tp.codigo_proveedor_id
LEFT OUTER JOIN terceros t on tp.tercero_id= t.tercero_id
LEFT OUTER JOIN inv_bodegas_movimiento_ordenes_compra ibmoc on cop.orden_pedido_id= ibmoc.orden_pedido_id
LEFT OUTER JOIN inv_bodegas_movimiento ibm on ibmoc.prefijo=ibm.prefijo and ibmoc.numero=ibm.numero
LEFT OUTER JOIN inv_bodegas_movimiento_d ibmocd on ibm.prefijo=ibmocd.prefijo and ibm.numero=ibmocd.numero) b
on  (a.orden_de_compra=b.orden_de_compra and a.codigo=b.codigo)
WHERE b.fecha_registro::date BETWEEN _1 AND _2