SELECT g.prefijo, g.factura_fiscal, g.fecha_glosa, g.valor_glosa, f.total_factura, gr.fecha_registro as fecha_respuesta,
CASE WHEN g.sw_estado= '0' THEN 'ANULADA'
     WHEN g.sw_estado='1' THEN 'SIN RESPUESTA'
     WHEN g.sw_estado= '2' THEN 'CON RESPUESTA'
     WHEN g.sw_estado= '3' THEN 'CERRADA'
     WHEN g.sw_estado= '4' THEN 'RATIFICADA'
     END AS estado_glosa
FROM glosas g
LEFT JOIN glosas_respuestas gr ON (g.glosa_id = gr.glosa_id),
fac_facturas f
WHERE g.prefijo = f.prefijo
AND g.factura_fiscal = f.factura_fiscal
AND g.sw_estado != '0'
AND g.fecha_glosa BETWEEN _1 AND _2
ORDER BY 1,2

