SELECT DISTINCT cf.ingreso,
p.tipo_id_paciente||' '||p.paciente_id AS identificacion_pacte,
p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS paciente,
to_char(i.fecha_ingreso, 'dd/mm/YYYY hh24:mi') as fecha_ingreso,
d.descripcion AS depto_ingreso,
he.numerodecuenta,
pl.plan_descripcion,
cf.numero_certificado,
pr.nombre as nombre_medico,
tp.descripcion as tipo_profesional,
he.departamento,
ee.descripcion as estacion_enfermeria,
to_char(cf.fecha, 'dd/mm/YYYY hh24:mi') as fecha_registro_defuncion,
cdf.diagnostico_defuncion_id,
dd.diagnostico_nombre

FROM hc_conducta_defuncion cf
INNER JOIN ingresos i ON (cf.ingreso=i.ingreso)
INNER JOIN pacientes p ON (i.tipo_id_paciente = p.tipo_id_paciente AND i.paciente_id = p.paciente_id)
INNER JOIN departamentos d ON (i.departamento=d.departamento) 
INNER JOIN hc_evoluciones he ON (cf.evolucion_id=he.evolucion_id)
INNER JOIN cuentas ct ON (he.numerodecuenta=ct.numerodecuenta)
INNER JOIN planes pl ON (ct.plan_id=pl.plan_id)
INNER JOIN profesionales_usuarios pu ON (cf.usuario_id=pu.usuario_id)
INNER JOIN profesionales pr ON (pu.tipo_tercero_id=pr.tipo_id_tercero AND pu.tercero_id=pr.tercero_id)
INNER JOIN tipos_profesionales tp ON (pr.tipo_profesional=tp.tipo_profesional)
LEFT JOIN estaciones_enfermeria ee ON (he.estacion_id=ee.estacion_id)
LEFT JOIN (select ingreso,diagnostico_defuncion_id from hc_conducta_diagnosticos_defuncion where sw_principal='1')cdf
ON (cdf.ingreso=cf.ingreso)
LEFT JOIN diagnosticos dd ON (cdf.diagnostico_defuncion_id=dd.diagnostico_id)
WHERE cf.fecha::date BETWEEN _1 AND _2
ORDER BY cf.ingreso

