SELECT 
a.fecha_registro::date AS fecha_documento,
a.prefijo||' '||a.numero AS CONSECUTIVO,
a.bodega,
bo.descripcion,
a.observacion,
ip.codigo_producto,
ip.descripcion,
ab.cantidad,
ab.total_costo,
ab.fecha_vencimiento, 
ab.lote,
su.nombre AS usuario_registro, 
bo.descripcion AS departamento

FROM inv_bodegas_movimiento as a 
	 inner join documentos as b on a.documento_id=b.documento_id and a.prefijo=b.prefijo
     inner join tipos_doc_generales as c on b.tipo_doc_general_id=c.tipo_doc_general_id
	 inner join inv_bodegas_movimiento_d as ab on a.prefijo=ab.prefijo and a.numero=ab.numero
	 inner join inventarios_productos as ip on ab.codigo_producto=ip.codigo_producto
	 INNER JOIN bodegas bo ON a.bodega=bo.bodega
	 INNER JOIN system_usuarios su ON a.usuario_id=su.usuario_id
	  
                                                                           
WHERE a.fecha_registro::date BETWEEN _1 AND _2
ORDER BY 1,2
--limit 600
