SELECT
cd.empresa_id, cd.centro_de_costo_id, 
c.descripcion as centro_de_costo, cd.departamento, d.descripcion, d.sw_estado as estado_depto, d.servicio, 
s.descripcion as servicio
FROM
cg_conf.centros_de_costo_departamentos cd
INNER JOIN cg_conf.centros_de_costo c ON(cd.centro_de_costo_id=c.centro_de_costo_id)
INNER JOIN departamentos d ON(cd.departamento=d.departamento)
INNER JOIN servicios s ON(d.servicio=s.servicio)