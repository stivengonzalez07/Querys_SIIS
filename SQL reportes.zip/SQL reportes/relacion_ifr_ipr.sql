SELECT fr.prefijo || ' ' || fr.numero as IFR, bm.observacion, bm.total_costo, bm.fecha_registro,
fr.prefijo_remision || ' ' || fr.numero_remision as IPR, t.tipo_id_tercero || ' ' || t.tercero_id as ID_tercero, t.nombre_tercero as tercero
FROM inv_bodegas_movimiento_fr_remision fr
INNER JOIN inv_bodegas_movimiento_ig_remision ig ON(fr.prefijo_remision=ig.prefijo AND fr.numero_remision=ig.numero)
INNER JOIN terceros t ON (ig.tipo_id_tercero=t.tipo_id_tercero AND ig.tercero_id=t.tercero_id)
INNER JOIN inv_bodegas_movimiento bm ON(fr.prefijo=bm.prefijo AND fr.numero=bm.numero)
AND bm.fecha_registro::date BETWEEN _1 AND _2
ORDER BY(fr.numero)