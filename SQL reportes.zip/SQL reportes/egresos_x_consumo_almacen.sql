--EGRESOS POR CONSUMO ALMACEN
SELECT DISTINCT
invm.fecha_registro::date AS fecha_documento, 
invm.prefijo||' '||invm.numero AS num_documento, 
b.descripcion AS bodega, 
invm.observacion, 
ip.codigo_producto, 
ip.descripcion AS producto,
inv.costo_ultima_compra AS costo_unitario, 
invmd.cantidad, 
invmd.total_costo,
invmd.fecha_vencimiento,
invmd.lote, 
su.nombre AS usuario_registro, 
dpto.descripcion AS departamento
FROM
--inv_bodegas_movimiento_traslados invt
inv_bodegas_movimiento invm 
INNER JOIN inv_bodegas_movimiento_d invmd ON invm.prefijo=invmd.prefijo AND invm.numero=invmd.numero AND invm.bodega=invmd.bodega
INNER JOIN inventarios_productos ip ON invmd.codigo_producto=ip.codigo_producto
INNER JOIN inventarios inv ON invmd.codigo_producto=inv.codigo_producto
INNER JOIN inv_bodegas_documentos invd ON invm.documento_id=invd.documento_id AND invm.bodega=invd.bodega
INNER JOIN inv_bodegas_movimiento_consumo invmc ON invm.prefijo=invmc.prefijo AND invm.numero=invmc.numero 
INNER JOIN bodegas b ON invm.bodega=b.bodega
--LEFT JOIN cg_mov_01.cg_mov_contable_01 mc ON invm.prefijo = mc.prefijo AND invm.numero = mc.numero
--LEFT JOIN cg_mov_01.cg_mov_contable_01_detalle mcd ON mc.documento_contable_id = mcd.documento_contable_id
--LEFT OUTER JOIN inv_bodegas_movimiento_compras_directas invcd ON invm.prefijo=invcd.prefijo AND invm.numero=invcd.numero
--LEFT OUTER JOIN terceros t ON invcd.tipo_id_tercero=t.tipo_id_tercero AND invcd.tercero_id=t.tercero_id
LEFT OUTER JOIN departamentos dpto ON invmc.departamento=dpto.departamento
INNER JOIN system_usuarios su ON invm.usuario_id=su.usuario_id
WHERE 
invd.documento_id IN ('24')
AND invm.fecha_registro::date BETWEEN _1 AND _2
--AND invm.fecha_registro::date BETWEEN '2021-04-01' AND '2021-04-28'
