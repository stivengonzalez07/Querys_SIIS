SELECT 
a.numerodecuenta as cuenta,
a.observacion as Motivo_Anulacion,
a.fecha_registro::date as fecha_anulacion,
b.nombre as usuario_anulo
 
             
FROM    auditoria_anulacion_cuentas a, system_usuarios b


WHERE a.usuario_id = b.usuario_id

and fecha_registro::date BETWEEN _1 AND _2