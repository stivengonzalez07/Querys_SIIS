select * from(
(select  i.codigo_producto,
i.descripcion,
i.descripcion_abreviada,
i.grupo_id
from inventarios_productos i) p
left join (select ip.codigo_producto,
ip.unidad_dosificacion,
ip.factor_conversion
from hc_formulacion_factor_conversion ip
inner join unidades u on(ip.unidad_id=u.unidad_id)) f
on (p.codigo_producto=f.codigo_producto))
where p.grupo_id='01' 


