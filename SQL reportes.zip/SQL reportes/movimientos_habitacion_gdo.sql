SELECT
i.ingreso,
mh.numerodecuenta,
i.fecha_ingreso::timestamp, 
s.fecha_registro::timestamp AS fecha_egreso,
dp.descripcion as departamento,
i.tipo_id_paciente,i.paciente_id, 
p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS nombre_paciente, 
((now()::date-p.fecha_nacimiento::date)/365) AS edad_en_anos, 
p.residencia_telefono AS telefono,
mh.movimiento_id,
mh.fecha_ingreso,
mh.fecha_egreso,
mh.cama,
mh.cargo,
mh.departamento,
ee.descripcion

FROM 
movimientos_habitacion mh
RIGHT JOIN ingresos i ON (i.ingreso=mh.ingreso)
RIGHT JOIN pacientes p ON (i.tipo_id_paciente=p.tipo_id_paciente AND i.paciente_id=p.paciente_id)
RIGHT JOIN ingresos_salidas s ON (i.ingreso=s.ingreso)
RIGHT JOIN departamentos dp ON (dp.departamento=i.departamento)
RIGHT JOIN estaciones_enfermeria ee ON(ee.estacion_id=mh.estacion_id)

WHERE
i.estado <>'5'
AND i.fecha_ingreso::date>=_1
AND i.fecha_ingreso::date<=_2
--AND i.fecha_ingreso BETWEEN '2021-05-01' AND '2021-05-30' 
ORDER BY 1,2

