select b.plan_descripcion,
b.prefijo,
sum(b.total)
 from 
(select pl.plan_descripcion,
case when ffc.prefijo = 'C' then 'CONTADO' else 'CREDITO' end as prefijo,
ffc.factura_fiscal,
nc.valor_nota,
case when nc.valor_nota is not null then sum(total_factura)-sum(nc.valor_nota) else sum(total_factura) end as total
from 
fac_facturas_cuentas as ffc
INNER JOIN cuentas as cta ON ffc.numerodecuenta = cta.numerodecuenta
INNER JOIN fac_facturas as ff ON ffc.prefijo=ff.prefijo AND ffc.factura_fiscal=ff.factura_fiscal
INNER JOIN planes as pl ON cta.plan_id=pl.plan_id
INNER JOIN ingresos as ing ON cta.ingreso=ing.ingreso
INNER JOIN pacientes as pac ON ing.paciente_id=pac.paciente_id and ing.tipo_id_paciente=pac.tipo_id_paciente
left join notas_credito as nc ON ffc.prefijo = nc.prefijo_factura and ffc.factura_fiscal = nc.factura_fiscal

WHERE   ff.fecha_registro >= _1
AND     ff.fecha_registro <= _2
AND     NOT (ff.estado ='2' OR ff.estado ='3')
group by 1,2,3,4,5
ORDER BY 1) as b