select 	a.numerodecuenta,
		a.ingreso,
		i.tipo_id_paciente, 
		i.paciente_id,
		j.primer_apellido,
		j.segundo_apellido,
		j.primer_nombre,
		j.segundo_nombre,
		a.plan_id,
		e.descripcion as estado_cuenta,    
		b.cuenta_liquidacion_qx_id as id_liquidacion_qx,
		b.fecha_cirugia,
		b.duracion_cirugia,
		b.fecha_registro,
		b.estado as estado_qx,
		c.cargo_cups,
		d.descripcion,
		c.sw_bilateral,
		c.diagnostico_uno,
		h.descripcion as ambito,
		f.descripcion as via_acceso,
		g.descripcion as tipo_cirugia
  
 from cuentas as a inner join cuentas_liquidaciones_qx as b on a.ingreso=b.ingreso and a.numerodecuenta=b.numerodecuenta
      inner join cuentas_liquidaciones_qx_procedimientos as c on b.cuenta_liquidacion_qx_id=c.cuenta_liquidacion_qx_id
      inner join cups as d on c.cargo_cups=d.cargo
      inner join cuentas_estados as e on a.estado=e.estado
      inner join qx_vias_acceso as f on b.via_acceso=f.via_acceso
      inner join qx_tipos_cirugia as g on b.tipo_cirugia_id=g.tipo_cirugia_id
      inner join qx_ambitos_cirugias as h on b.ambito_cirugia_id=h.ambito_cirugia_id
      inner join ingresos as i on a.ingreso = i.ingreso
      inner join pacientes as j on i.tipo_id_paciente = j.tipo_id_paciente and i.paciente_id  = j.paciente_id

where b.fecha_cirugia::DATE>=_1
 and b. fecha_cirugia::DATE<=_2 
 and b.estado  != '3' and a.estado != '5' order by a.numerodecuenta