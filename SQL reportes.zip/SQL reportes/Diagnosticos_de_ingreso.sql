SELECT 
i.ingreso,
i.fecha_ingreso::timestamp,
dp.descripcion as departamento,
i.tipo_id_paciente,
i.paciente_id,
di.tipo_diagnostico_id as diagnostico,
e.fecha_registro as fecha_registro_diagnostico,
CASE WHEN di.sw_principal='1' THEN 'DIAGNOSTICO PRINCIPAL' ELSE 'OTRO' END AS Tip_diagnositco,
d.diagnostico_nombre as descripcion

FROM hc_diagnosticos_ingreso di,
diagnosticos d, 
hc_evoluciones e,
departamentos dp,
ingresos i

WHERE dp.departamento=e.departamento
AND   di.tipo_diagnostico_id=d.diagnostico_id
AND   di.evolucion_id=e.evolucion_id
AND   i.ingreso=e.ingreso
AND i.estado <>'5'
AND i.fecha_ingreso::date>=_1
AND i.fecha_ingreso::date<=_2
ORDER BY 1,2,3