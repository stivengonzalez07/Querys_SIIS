SELECT c.numerodecuenta,i.tipo_id_paciente,i.paciente_id,p.primer_apellido,p.segundo_apellido,p.primer_nombre,p.segundo_nombre,c.valor_total_empresa::integer
FROM cuentas c,ingresos i,pacientes p
WHERE c.ingreso=i.ingreso
AND i.tipo_id_paciente=p.tipo_id_paciente
AND c.estado!='5'
AND c.plan_id='18'
AND i.paciente_id=p.paciente_id
AND i.fecha_ingreso::date>=_1
AND i.fecha_ingreso::date<=_2
ORDER BY 1
