SELECT distinct c.numerodecuenta,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
cd.cargo,
c.total_cuenta,
d.descripcion,
'Medicamentos' as tipo_producto,
SUM(COALESCE(a.total_costo,0))as costo
FROM pacientes P,
planes pl,
cuentas c,
cuentas_detalle cd LEFT JOIN bodegas_documentos_d as a ON(cd.consecutivo = a.consecutivo),
ingresos i,
departamentos d,
bodegas_documentos_d bdd,
inventarios_productos ip  
WHERE   c.plan_id = pl.plan_id
AND     p.paciente_id = i.paciente_id
AND     d.departamento = i.departamento
AND     c.numerodecuenta = cd.numerodecuenta
AND     i.ingreso = c.ingreso
AND     cd.cargo = 'IMD' AND     cd.consecutivo = bdd.consecutivo
AND     
bdd.codigo_producto = ip.codigo_producto
AND     i.fecha_registro::date >= _1
AND     i.fecha_registro::date <= _2
AND     ip.grupo_id='01'
GROUP BY c.numerodecuenta,
i.fecha_ingreso,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido, 
p.segundo_apellido,
pl.plan_descripcion,
cd.cargo,
c.total_cuenta,
d.descripcion 
UNION  
SELECT  distinct c.numerodecuenta,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre,
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
cd.cargo,
c.total_cuenta,
d.descripcion,
'Insumos' as tipo_producto, SUM(COALESCE(a.total_costo,0))as costo
FROM pacientes P,
planes pl,
cuentas c,
cuentas_detalle cd LEFT JOIN bodegas_documentos_d as a ON(cd.consecutivo = a.consecutivo),
ingresos i,
departamentos d,
bodegas_documentos_d bdd,
inventarios_productos ip  
WHERE   c.plan_id = pl.plan_id
AND     p.paciente_id = i.paciente_id
AND     d.departamento = i.departamento
AND     c.numerodecuenta = cd.numerodecuenta
AND     i.ingreso = c.ingreso
AND     cd.cargo = 'IMD'
AND     cd.consecutivo = bdd.consecutivo
AND     
bdd.codigo_producto = ip.codigo_producto
AND     i.fecha_registro::date >= _1
AND     i.fecha_registro::date <= _2
AND     ip.grupo_id='02'
GROUP BY c.numerodecuenta,
i.fecha_ingreso,
i.tipo_id_paciente,
i.paciente_id,
p.primer_nombre,
p.segundo_nombre, 
p.primer_apellido,
p.segundo_apellido,
pl.plan_descripcion,
cd.cargo,
c.total_cuenta,
d.descripcion