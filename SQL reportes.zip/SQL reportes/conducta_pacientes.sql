SELECT ab.ingreso,
  ab.tipo_id_paciente,
  ab.paciente_id,
  ab.primer_nombre,
  ab.segundo_nombre,
  ab.primer_apellido,
  ab.segundo_apellido,
  ab.fecha_ingreso,
  ab.departamento_ingreso,
  ab.departamento_actual,
  tc.descripcion,
  ab.evolucion,
  tp.descripcion as tipo_profesional
  FROM 
  (SELECT i.ingreso,
  p.tipo_id_paciente,
  p.paciente_id,
  p.primer_nombre,
  p.segundo_nombre,
  p.primer_apellido,
  p.segundo_apellido,
  i.fecha_ingreso,
  d.descripcion as departamento_ingreso,
  e.descripcion as departamento_actual,
  MIN (hc.evolucion_id) as evolucion
  FROM ingresos i,
  pacientes p,
  departamentos d,
  departamentos e,
  hc_evoluciones hc
  WHERE i.tipo_id_paciente = p.tipo_id_paciente 
  AND i.paciente_id=p.paciente_id
  AND i.departamento=d.departamento
  AND i.departamento_actual=e.departamento
  AND hc.ingreso=i.ingreso
  GROUP BY 1,2,3,5,6,7,8,9,10) ab
  INNER JOIN hc_evoluciones he ON (ab.evolucion=he.evolucion_id)
  INNER JOIN historias_clinicas_tipos_cierres tc ON (he.historia_clinica_tipo_cierre_id=tc.historia_clinica_tipo_cierre_id)
  INNER JOIN profesionales_usuarios pu ON (he.usuario_id=pu.usuario_id)
  INNER JOIN profesionales pr ON (pu.tipo_tercero_id=pr.tipo_id_tercero AND pu.tercero_id=pr.tercero_id)
  INNER JOIN tipos_profesionales tp ON (pr.tipo_profesional=tp.tipo_profesional)
  WHERE ab.fecha_ingreso::date >=_1 
  AND ab.fecha_ingreso::date <=_2
  ORDER BY 1
  