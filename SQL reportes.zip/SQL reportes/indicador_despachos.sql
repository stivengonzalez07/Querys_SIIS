select 
x.mes as periodo,
case when x.tipo_solicitud = 'M' then 'SOLICITUD DE MEDICAMENTOS'
else 'SOLICITUD DE INSUMOS' end as TIPO_SOLICITUD,
x.estado,
contador from
(select 
tipo_solicitud,
hsm.sw_estado,
--extract(month from to_date(fecha_solicitud, 'YYYY-MM-DD')) as mes,
extract(month from fecha_solicitud::date) as mes,
case when hsm.sw_estado = '0' then 'Sin despacho'
when hsm.sw_estado = '1' then 'Despachado'
when hsm.sw_estado = '2' then 'Recibido'
when hsm.sw_estado = '3' then 'Cancelado'
when hsm.sw_estado = '4' then 'Consumo Directo'
when hsm.sw_estado = '5' then 'Recibido Parcialmente, solo con algunos de los productos solicitados'
else 'Despachado desde Bodega y Cancelado en la Estacion' end as estado,
count(hsm.sw_estado) as contador
from hc_solicitudes_medicamentos as hsm
inner join bodegas as bo ON bo.bodega = hsm.bodega
where hsm.fecha_solicitud::date between _1 and _2

--to_date(hsm.fecha_solicitud, 'YYYY-MM-DD') between _1 and _2
and hsm.bodega IN('BF')
group by 1,2,3
order by 1,2) as x
order by 1,2,3
