SELECT a.codigo_producto, b.descripcion, c.descripcion, a.existencia 
FROM existencias_bodegas a, inventarios_productos b, bodegas c 
WHERE a.fecha_registro::date BETWEEN _1 AND _2 AND a.codigo_producto=b.codigo_producto AND a.bodega=c.bodega;