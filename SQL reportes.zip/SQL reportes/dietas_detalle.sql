SELECT d.ingreso_id as ingreso, 
pac.primer_nombre||' '||pac.segundo_nombre||' '||pac.primer_apellido||' '||pac.segundo_apellido as paciente,
d.fecha_solicitud, 
d.estacion_id, 
td.descripcion as tipo_dieta, 
ts.descripcion_solicitud,
dc.descripcion as caracteristica_dieta
FROM dietas_solicitud_detalle d
INNER JOIN hc_tipos_dieta td ON (d.hc_dieta_id=td.hc_dieta_id)
INNER JOIN dietas_tipos_solicitud ts ON (d.tipo_solicitud_dieta_id = ts.tipo_solicitud_dieta_id)
INNER JOIN dietas_solicitud_detalle_caracteristicas dtc ON (d.ingreso_id=dtc.ingreso_id
			AND d.fecha_solicitud=dtc.fecha_solicitud 
			AND d.tipo_solicitud_dieta_id=dtc.tipo_solicitud_dieta_id
			AND d.estacion_id=dtc.estacion_id)
INNER JOIN hc_solicitudes_dietas_caracteristicas dc ON (dtc.caracteristica_id=dc.caracteristica_id)
INNER JOIN ingresos i ON (d.ingreso_id=i.ingreso)
INNER JOIN pacientes pac ON (i.tipo_id_paciente=pac.tipo_id_paciente AND i.paciente_id=pac.paciente_id)
WHERE d.fecha_solicitud::date >= _1
AND d.fecha_solicitud::date <= _2
ORDER BY ts.descripcion_solicitud
