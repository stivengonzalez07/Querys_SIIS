SELECT a.solicitud_id AS No_Solicitud
,concat(h.tipo_id_paciente,' ',h.paciente_id) AS Identificacion_Paciente
,concat(i.primer_apellido,' ',i.segundo_apellido,' ',i.primer_nombre,' ',i.segundo_nombre) AS Nombre_paciente
,c.codigo_producto
,d.descripcion
,c.cantidad
,c.lote
,e.nombre AS Usuario_solicita
,f.descripcion AS Estacion
,a.fecha_solicitud 
,g.nombre AS Usuario_despacha
,b.fecha_registro AS Fecha_confirmacion_despacho
FROM hc_solicitudes_medicamentos a
, bodegas_documento_despacho_med b
, bodegas_documento_despacho_med_d c
, inventarios_productos d
, system_usuarios e
, system_usuarios g
, estaciones_enfermeria f
, ingresos h, pacientes i 
WHERE a.sw_estado='1' 
AND a.documento_despacho=b.documento_despacho_id 
AND b.documento_despacho_id=c.documento_despacho_id 
AND c.codigo_producto=d.codigo_producto
AND a.usuario_id=e.usuario_id 
AND b.usuario_id=g.usuario_id 
AND a.estacion_id=f.estacion_id 
AND a.ingreso=h.ingreso 
AND h.paciente_id=i.paciente_id
AND b.fecha_registro::date BETWEEN _1 AND _2
ORDER BY(b.fecha_registro::date)
