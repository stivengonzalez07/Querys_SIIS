SELECT  b.prefijo as Prefijo,
        b.factura_fiscal as Numero,
        d.fecha_registro as Fecha_Factura,
        d.total_factura as Valor,
        e.tipo_tercero_id as Tipo,
        e.tercero_id as Numero,
        a.envio_id as Envio,
		ed.observacion,
        a.fecha_registro as Fecha_Envio,
        i.nombre_tercero as Tercero,
        a.fecha_radicacion as Fecha_radicacion,
        e.plan_descripcion as Entidad
         
FROM envios as a, 
     envios_detalle as b,
	 envios_despacho as ed,	 
     fac_facturas_cuentas as c,
     fac_facturas as d, 
     planes as e, 
     cuentas as f,
     terceros as i
         
WHERE      a.envio_id=b.envio_id 
           and b.prefijo=c.prefijo
           and b.factura_fiscal=c.factura_fiscal 
		   and ed.envio_id=a.envio_id
           and d.prefijo=c.prefijo
           and d.factura_fiscal=c.factura_fiscal 
           and d.plan_id=e.plan_id
           and c.numerodecuenta=f.numerodecuenta
           and e.tipo_tercero_id=i.tipo_id_tercero 
           and e.tercero_id=i.tercero_id
           and a.sw_estado = '1'
           and a.fecha_radicacion::date BETWEEN _1 AND _2
           order by a.envio_id
