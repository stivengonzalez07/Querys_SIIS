SELECT rcc.prefijo, 
       rcc.recibo_caja, 
	   rcc.tipo_id_tercero, 
	   rcc.tercero_id, 
	   rcc.nombre_tercero, 
	   rcc.fecha_ingcaja, 
	   rcc.total_abono,
	   rcc.numerodecuenta,
	   rcc.plan_descripcion,
	   rcc.prefijo_devolucion,
	   rcc.devolucion_id as numero_devolucion,
	   rcc.total_devolucion,
	   rcc.nombre,
	   rcc.descripcion AS caja

FROM (
		SELECT a.prefijo, 
			   a.recibo_caja, 
			   a.tipo_id_tercero, 
			   a.tercero_id, 
			   b.nombre_tercero, 
			   a.fecha_ingcaja, 
			   a.total_abono,
			   rc.numerodecuenta,
			   p.plan_descripcion,
			   rde.prefijo as prefijo_devolucion,
			   rde.devolucion_id,
			   rde.total_devolucion,
			   u.nombre,
			   ca.descripcion
			   
		FROM recibos_caja a 
		INNER JOIN terceros b ON (a.tercero_id=b.tercero_id AND a.tipo_id_tercero=b.tipo_id_tercero)
		INNER JOIN rc_detalle_hosp rc ON (a.prefijo=rc.prefijo AND a.recibo_caja=rc.recibo_caja)
		INNER JOIN cuentas cu ON (rc.numerodecuenta=cu.numerodecuenta)
		INNER JOIN planes p ON (cu.plan_id=p.plan_id)
		INNER JOIN system_usuarios u ON (a.usuario_id = u.usuario_id)
		INNER JOIN cajas ca ON (a.caja_id = ca.caja_id)
		LEFT JOIN rc_devoluciones rde ON (cu.numerodecuenta=rde.numerodecuenta)
		WHERE a.estado='0'
		AND a.fecha_ingcaja::DATE BETWEEN _1 AND _2
		
		UNION 

		SELECT a.prefijo, 
			   a.factura_fiscal as recibo_caja, 
			   a.tipo_id_tercero, 
			   a.tercero_id, 
			   b.nombre_tercero, 
			   a.fecha_registro as fecha_ingcaja, 
			   a.total_abono,
			   a.numerodecuenta,
			   p.plan_descripcion,
			   rde.prefijo as prefijo_devolucion,
			   rde.devolucion_id,
			   rde.total_devolucion,
			   u.nombre,
			   ca.descripcion
			   
		FROM fac_facturas_contado a 
		INNER JOIN terceros b ON (a.tercero_id=b.tercero_id AND a.tipo_id_tercero=b.tipo_id_tercero)
		INNER JOIN cuentas cu ON (a.numerodecuenta=cu.numerodecuenta)
		INNER JOIN planes p ON (cu.plan_id=p.plan_id)
		INNER JOIN system_usuarios u ON (a.usuario_id = u.usuario_id)
		INNER JOIN cajas_rapidas ca ON (a.caja_id = ca.caja_id)
		LEFT JOIN rc_devoluciones rde ON (cu.numerodecuenta=rde.numerodecuenta)
		WHERE a.estado='0'
		AND a.sw_recibo='1'
		AND a.fecha_registro::DATE BETWEEN _1 AND _2
)rcc
GROUP BY rcc.prefijo, 
       rcc.recibo_caja, 
	   rcc.tipo_id_tercero,
	   rcc.tercero_id, 
	   rcc.nombre_tercero, 
	   rcc.fecha_ingcaja, 
	   rcc.total_abono,
	   rcc.numerodecuenta,
	   rcc.plan_descripcion,
	   rcc.prefijo_devolucion,
	   rcc.devolucion_id,
	   rcc.total_devolucion,
	   rcc.nombre,
	   rcc.descripcion
ORDER BY 1,2
