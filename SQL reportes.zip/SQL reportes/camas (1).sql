select 
c.cama,
c.pieza,
c.ubicacion,
c.descripcion,
tc.descripcion
from camas c
inner join tipo_camas_estados tc on(tc.tipo_cama_estado_id=c.estado) 	
order by cama