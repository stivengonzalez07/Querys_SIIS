SELECT c.dia_inventario, 
c.existencia_inicial, 
c.existencia_final, 
c.dias as dias_mes, 
(c.existencia_inicial / c.existencia_final * c.dias)::integer as numero_dias, 
c.producto as codigo_producto, 
ip.descripcion as descripcion_producto 

FROM 
(SELECT ibmc.costo,
ibmc.lapso, 
ibmc.existencia_inicial, 
ibmc.existencia_final, 

DATE_PART('days', DATE_TRUNC('month', ibmc.fecha_registro::date) + '1 MONTH'::INTERVAL - DATE_TRUNC('month', ibmc.fecha_registro::date)) as dias, ibmc.codigo_producto as producto, TO_CHAR(ibmc.fecha_registro::date,'DD') as dia_inventario

FROM inv_bodegas_movimiento_cierres_por_lapso as ibmc

WHERE ibmc.existencia_inicial <> 0
AND ibmc.existencia_final <> 0
AND ibmc.fecha_registro >= _1
AND ibmc.fecha_registro <= _2
group by 1,2,3,4,5,6,7) as c, 
inventarios_productos as ip

WHERE c.producto = ip.codigo_producto
