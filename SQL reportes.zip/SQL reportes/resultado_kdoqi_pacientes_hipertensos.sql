SELECT prc.estadio_kdoqi, 
c.numerodecuenta AS cuenta, 
p.paciente_id, 
p.primer_nombre||' ' ||p.segundo_nombre||' ' ||p.primer_apellido||' '||p.segundo_apellido AS nombre,
CASE WHEN he.cargo_cita = '890201' THEN 'Consulta Primera Vez'
    WHEN he.cargo_cita = '890301' THEN 'Consulta Control'
    ELSE 'Sin Estado' END AS tipo_cita
FROM pyp_renoproteccion_conducta prc
INNER JOIN hc_evoluciones he ON prc.evolucion_id=he.evolucion_id
INNER JOIN ingresos i ON he.ingreso=i.ingreso
INNER JOIN cuentas c ON i.ingreso=c.ingreso
INNER JOIN pacientes p ON i.paciente_id=p.paciente_id
WHERE i.fecha_ingreso::date >= _1
AND i.fecha_ingreso::date <= _2