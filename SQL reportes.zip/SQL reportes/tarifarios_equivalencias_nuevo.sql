SELECT te.tarifario_id, ta.descripcion, te.cargo, td.descripcion, te.cargo_base AS cups, c.descripcion AS descripcion_cups
,te.porc_similitud , te.sw_tipo_consulta
FROM tarifarios_equivalencias te,
tarifarios ta,
tarifarios_detalle td,
cups c
WHERE te.tarifario_id=ta.tarifario_id
AND td.tarifario_id=te.tarifario_id
AND td.cargo=te.cargo
AND c.cargo=te.cargo_base
