Select p.plan_descripcion,s.descripcion as servicio,d.descripcion as departamento,ip.codigo_producto,ip.descripcion as productos
FROM
servicios s,inventarios_productos ip,planes p,departamentos d,planes_paragrafados_medicamentos ppm
WHERE
p.plan_id = ppm.plan_id and s.servicio = ppm.servicio and ip.codigo_producto = ppm.codigo_producto and d.departamento = ppm.departamento
ORDER BY 1,2