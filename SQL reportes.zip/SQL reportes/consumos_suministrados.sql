SELECT 

fsm.fecha_realizado as fecha,
p.primer_apellido || ' '|| p.segundo_apellido || ' ' || p.primer_nombre || ' ' || p.segundo_nombre as Nombre_Paciente,
p.tipo_id_paciente as tipo_Identificacion,
p.paciente_id as Identificacion,
pl.plan_descripcion as Plan,
di.tipo_diagnostico_id as Diagnostico,
ip.codigo_producto as Codigo,
ip.sw_pos,
ip.pos_nopos,
ip.descripcion as Descripcion,
u.descripcion as Unidad_medida,
fsm.cantidad_suministrada,
pr.nombre as Nombre_Medico,
he.ingreso,
pr.registro_medico


from  medicamentos m, ingresos ig,
hc_evoluciones he, hc_diagnosticos_ingreso di,
inventarios_productos ip, unidades u,
cuentas c, planes pl,
hc_formulacion_suministro_medicamentos fsm, 
hc_formulacion_medicamentos_eventos fme, 
pacientes p, profesionales pr


WHERE ip.codigo_producto = m.codigo_medicamento
AND ip.unidad_id = u.unidad_id
AND fsm.codigo_producto = ip.codigo_producto 
AND fsm.num_reg_formulacion = fme.num_reg
AND fme.ingreso = ig.ingreso
AND p.paciente_id = ig.paciente_id
AND ig.ingreso = he.ingreso
AND he.numerodecuenta = c.numerodecuenta
AND c.plan_id = pl.plan_id
AND he.evolucion_id = di.evolucion_id
AND fme.usuario_id = pr.usuario_id
AND di.sw_principal = '1'
AND m.sw_pos='0'
AND fsm.fecha_realizado BETWEEN _1 AND _2

order by ip.codigo_producto

--limit 100 

