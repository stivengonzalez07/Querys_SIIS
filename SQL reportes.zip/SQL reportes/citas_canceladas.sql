SELECT a.agenda_cita_asignada_id as cita, 
       tc.descripcion as motivo_cancelacion,
       a.observacion,
       a.fecha_registro as fecha_cancelacion, 
       s.nombre as usuario_cancela,
       ca.paciente_id,
       pt.primer_nombre || pt.segundo_nombre || pt.primer_apellido || pt.segundo_apellido as nombre_paciente,
       t.profesional_id,
       p.nombre as medico,
       t.fecha_turno,
       c.hora as hora_turno
       
FROM   agenda_citas_asignadas_cancelacion a,
       tipos_cancelacion tc,
       system_usuarios s,
       agenda_citas_asignadas ca,
       profesionales p,
       agenda_citas c,
       agenda_turnos t,
       pacientes pt
       
WHERE  a.usuario_id = s.usuario_id
AND    a.agenda_cita_asignada_id = ca.agenda_cita_asignada_id
AND    ca.paciente_id = pt.paciente_id
AND    t.profesional_id = p.tercero_id
AND    a.tipo_cancelacion_id = tc.tipo_cancelacion_id
AND    ca.agenda_cita_id = c.agenda_cita_id
AND    c.agenda_turno_id = t.agenda_turno_id
AND    a.fecha_registro::date >= _1
AND    a.fecha_registro::date <= _2
ORDER BY a.fecha_registro