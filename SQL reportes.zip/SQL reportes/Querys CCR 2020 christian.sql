--ELiminar Examen Fisico

DELETE FROM hc_revision_por_sistemas WHERE evolucion_id=4211183 AND ingreso=245924

--ACTUALIZA FECHA EN EXAMEN FISICO
UPDATE hc_revision_por_sistemas SET fecha_registro = '2021-06-02 20:19:07' WHERE evolucion_id=4952824 and ingreso=304444

-- Actualizar profesional y/o fecha de registro en EXAMEN FISICO
UPDATE hc_revision_por_sistemas SET usuario_id=1000
AND fecha_registro='2018-11-08 15:43:39'
WHERE evolucion_id=XXXXX AND ingreso=XXXXX

--Eliminar usuario -- completar
DELETE FROM system_menu_items_usuarios WHERE usuario_id=2397;
  DELETE FROM system_usuarios_empresas WHERE usuario_id=2397;

--Eliminar Profesional
		DELETE FROM profesionales_estado WHERE tercero_id='1143970103';
	  DELETE FROM profesionales_empresas WHERE tercero_id='1143970103';
 DELETE FROM profesionales_departamentos WHERE tercero_id='1143970103';
DELETE FROM profesionales_especialidades WHERE tercero_id='1143970103';
			   DELETE FROM profesionales WHERE tercero_id='1143970103';


--Eliminar varios usuario de estacion de enfermeria

DELETE FROM estaciones_enfermeria_usuarios where usuario_id IN(2278)

--Query para actualizar estacion de usuarios

UPDATE estaciones_enfermeria SET sw_productos_pendientes='1 ,sw_productos_confirmar=1'


--Query para ubicar texto en plan terapeutico

SELECT pt.descripcion, pt.evolucion_id, pt.fecha_registro_plan 
FROM hc_evoluciones_submodulos evs, hc_plan_terapeutico pt, cuentas c
WHERE evs.evolucion_id = pt.evolucion_id
AND c.ingreso = evs.ingreso
AND evs.ingreso=169692
--AND c.numerodecuenta = 45570
AND pt.fecha_registro_plan >= '2019-07-06 00:01' AND  pt.fecha_registro_plan < '2019-07-07 23:59'
AND pt.descripcion ilike '%DE ECO DE TORAX%'
limit 50

--Consulta entre tablas evoluciones

UPDATE 
SET

SELECT o.hc_os_solicitud_id, o.evolucion_id, o.ingreso, o.fecha_solicitud, a.medico_avalista, a.usuario_solicitud
FROM hc_os_solicitudes o, hc_os_solicitudes_apoyod a
where o.hc_os_solicitud_id=a.hc_os_solicitud_id
AND o.paciente_id = 16594050
AND a.medico_avalista=248 

--Eliminar componentes de usuarios de una estacion 

DELETE FROM estaciones_enfermeria_usuarios_componentes WHERE usuario_id = 758

--Actualizar perfil a medico especialista en la tabla estaciones enfermeria

UPDATE estaciones_enfermeria_usuarios SET estacion_perfil_id = 02 WHERE usuario_id = 480

--Eliminar KIT de la tabla insumos

DELETE FROM  insumos_paquetes_d WHERE insumo_paquete_id = 3 AND codigo_producto IN ('0201010738',
 '0201010189', 
 '0201010570', 
 '0201010167', 
 '0201010161', 
 '0201010113', 
 '0201010782', 
 '0201010647')
 
 --Eliminar Recomendaciones medicas
 DELETE FROM hc_recomendaciones_medicas_detalle WHERE evolucion_id='3131221';
		 DELETE FROM hc_recomendaciones_medicas WHERE evolucion_id='3131221';

--Query buscar usuarios por login

SELECT u.usuario_id, u.usuario
FROM system_usuarios u
WHERE u.usuario IN ('roslucpa',
'mayferfe',
'luipospo',
'astminmi',
'gusagupa',
'julpinmo',
'myrbermu',
'adrmormi',
'alejimda',
'yenvalla'
)

--Actualizar Descripcion de usuarios

UPDATE system_usuarios SET descripcion = 'PROCESO AUDITORIA Y FACTURACION INTEGRAL' WHERE usuario_id IN (1005,
985 ,
1028,
1023,
1025,
316 ,
285 ,
724 ,
733 ,
889 ,
699 ,
303 ,
315 ,
389 ,
390 ,
544 ,
770 ,
543 ,
912 ,
653 ,
483 ,
793 ,
319 ,
680 ,
725 ,
719 ,
517 ,
552 ,
833 ,
382 ,
794 ,
832 ,
528) 

--Actualizar Perfil de usuario 

UPDATE system_usuarios_perfiles SET perfil_id = XXX WHERE usuario_id IN (1025,
1028,
653,
315,
382,
303,
912)

--Reliquidar Cirugia

DELETE FROM soat_atencion_ambulatoria WHERE numerodecuenta ='38196 ' AND departamento ='CIRU01' AND cargo <> 'IMD'

--Eliminar Perfil

DELETE FROM system_modulos_perfiles WHERE perfil_id = 99
DELETE FROM system_modulos_perfiles_opciones WHERE system_modulo_perfil_id IN (1290,
1291,1292,1293,1294,1295,1296,1297,1298,1299,1300,1301,1302,1303,1304,1305,1306,1309,
1310,1311,1327,1517,1518,1519,1618)

--Query para consultar usuarios con varios perfiles

SELECT u.usuario_id, COUNT(*) Total, u.nombre, u.activo
FROM system_usuarios_perfiles up, system_usuarios u
WHERE up.usuario_id = u.usuario_id
GROUP BY u.usuario_id
HAVING COUNT(*) > 1

--Borrar usuario de reportes CSV

DELETE FROM usuarios_asigna_reportes WHERE usuario_id = 542

--QUERY para consultar Reportes por perfil y por usuario ()

SELECT ur.reporte_empresa_id, u.usuario, re.nombre_archivo, re.titulo_reporte, up.perfil_id, p.descripcion
FROM usuarios_asigna_reportes ur, system_usuarios u, reportes_empresa re, system_usuarios_perfiles up, system_perfiles p
WHERE u.usuario_id = ur.usuario_id
AND ur.reporte_empresa_id = re.reporte_empresa_id
AND u.usuario_id = up.usuario_id
AND up.perfil_id = p.perfil_id
AND up.perfil_id = 60
AND u.usuario_id = 4
ORDER BY reporte_empresa_id

--Consultar Menus por perfil

SELECT mp.*, mi.titulo
FROM system_menu_items_perfiles mp, system_menus_items mi
WHERE mp.menu_item_id = mi.menu_item_id
AND mp.perfil_id = 89
ORDER BY mi.titulo

-- Actualizar caducidad de contraseña

UPDATE system_usuarios SET fecha_caducidad_contrasena IS NULL, caducidad_contrasena IS NULL WHERE usuario IN ('joragumi','fraroddi','lorchara','ANDarica','dieferco','linherfe','stehercr','wilgardo')

--Eliminar nota que se repite 

DELETE FROM hc_notas_enfermeria_descripcion WHERE hc_notas_enfermeria_descripcion_id IN (300085,
300086,
300074,
300088,
300054,
300055,
300040,
300064,
300067)

--Consultar menus por perfiles

SELECT sm.titulo, sp.*
FROM system_menu_items_perfiles smp, system_menus_items sm, system_perfiles sp
WHERE smp.menu_item_id = sm.menu_item_id
AND smp.perfil_id = sp.perfil_id
AND smp.menu_item_id = 224
AND smp.perfil_id <> 2 --Este perfil es de administrador

SELECT u.usuario_id, COUNT(*) Total, u.nombre, u.activo AS Estado
FROM system_usuarios_perfiles up, system_usuarios u
WHERE up.usuario_id = u.usuario_id
GROUP BY u.usuario_id
HAVING COUNT(*) > 1

-- Query para borrar modulo por perfiles
 
DELETE FROM system_menu_items_perfiles WHERE menu_item_id = 224 AND perfil_id IN (3,4,6,14,15,16,62,60,83,88,95,
53,54,52,89,87,100,98,112,113,32,114,109,117,40,122,123)

-- Query para buscar modulos en un perfil

SELECT sp.descripcion,smi.menu_item_id, smi.titulo
FROM system_menu_items_perfiles smp, system_menus_items smi, system_perfiles sp
WHERE smp.perfil_id = sp.perfil_id
AND smp.menu_item_id= smi.menu_item_id
AND smp.perfil_id = 14
ORDER BY smi.titulo

-- Query para buscar reportes de todos los usuarios de acuerdo al perfil

SELECT ur.reporte_empresa_id, 
       u.usuario_id ,
       u.usuario, 
       re.nombre_archivo, 
       re.titulo_reporte, 
       up.perfil_id, 
       p.descripcion
FROM usuarios_asigna_reportes ur, 
     system_usuarios u, 
     reportes_empresa re, 
     system_usuarios_perfiles up, 
     system_perfiles p
WHERE u.usuario_id = ur.usuario_id
  AND ur.reporte_empresa_id = re.reporte_empresa_id
  AND u.usuario_id = up.usuario_id
  AND up.perfil_id = p.perfil_id
  AND up.perfil_id = 24
  ORDER BY u.usuario_id

-- Query para actualizar observacion en varios items de una respuesta glosa

UPDATE glosas_respuestas_cargos SET observacion = '608.1, no se acepta glosa, paciente que sufre accidente de tránsito en calidad de 
peatón vs moto presenta trauma en codo, humero, reja costal, cadera del lado izquierdo, dolor de intensidad moderada, Según hallazgos 
y evolución clínica, se definirá conducta a seguir, Se indica manejo analgésico y curación de heridas, por el mecanismo del trauma y 
las lesiones presentadas se requiere descartar lesiones a este nivel, no se acepta glosa y nos acogemos decreto número 4747 de 2007 
artículo 23. una vez formuladas las glosas a una factura, no se podrán formular nuevas glosas a la misma factura, salvo las que surjan 
de hechos nuevos detectados en la respuesta dada a la glosa inicial. y según la administradora de los recursos del sistema general de 
seguridad social en salud manual de auditoría integral de reclamaciones siempre que en la respuesta a los resultados de auditoría el 
reclamante aporte un nuevo documento, este será objeto de una auditoría integral complementando la realizada a la reclamación inicial 
y solo respecto de este nuevo documento podrán aplicarse nuevas glosas, en cuyo caso opera el derecho a dar respuesta al resultado de 
auditoría.' where glosa_respuesta_id=38188
AND glosa_respuesta_cargo_id IN (
190955,
190956,
190957,
190958,
190959)
---Insertar usuario soat
INSERT INTO system_usuarios_departamentos VALUES(410,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(412,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(413,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(414,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(415,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(508,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(546,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(554,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(554,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(556,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(685,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(900,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1011,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1179,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1198,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1282,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1156,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1166,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1643,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1644,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1651,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1652,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(1834,'ADMISI',now(),910,'1');
INSERT INTO system_usuarios_departamentos VALUES(2030,'ADMISI',now(),910,'1');
---------
INSERT INTO userpermisos_soat VALUES('01','01',410);
INSERT INTO userpermisos_soat VALUES('01','01',412);
INSERT INTO userpermisos_soat VALUES('01','01',413);
INSERT INTO userpermisos_soat VALUES('01','01',414);
INSERT INTO userpermisos_soat VALUES('01','01',415);
INSERT INTO userpermisos_soat VALUES('01','01',508);
INSERT INTO userpermisos_soat VALUES('01','01',546);
INSERT INTO userpermisos_soat VALUES('01','01',554);
INSERT INTO userpermisos_soat VALUES('01','01',554);
INSERT INTO userpermisos_soat VALUES('01','01',556);
INSERT INTO userpermisos_soat VALUES('01','01',685);
INSERT INTO userpermisos_soat VALUES('01','01',900);
INSERT INTO userpermisos_soat VALUES('01','01',1011);
INSERT INTO userpermisos_soat VALUES('01','01',1179);
INSERT INTO userpermisos_soat VALUES('01','01',1198);
INSERT INTO userpermisos_soat VALUES('01','01',1282);
INSERT INTO userpermisos_soat VALUES('01','01',1156);
INSERT INTO userpermisos_soat VALUES('01','01',1166);
INSERT INTO userpermisos_soat VALUES('01','01',1643);
INSERT INTO userpermisos_soat VALUES('01','01',1644);
INSERT INTO userpermisos_soat VALUES('01','01',1651);
INSERT INTO userpermisos_soat VALUES('01','01',1652);
INSERT INTO userpermisos_soat VALUES('01','01',1834);
INSERT INTO userpermisos_soat VALUES('01','01',2030);
			



--Actualizar Usuario de Control Cuentas ya creado

UPDATE system_usuarios_departamentos_cc SET usuario_id = 534 WHERE usuario_id = 455
UPDATE usuarios_menu_prosi SET usuario_id = 534 WHERE usuario_id = 455

--Borrar respuesta glosas

DELETE FROM glosas_respuestas_inventarios WHERE glosa_respuesta_id = 94789;
DELETE FROM glosas_respuestas_cargos WHERE glosa_respuesta_id = 94789;

--Buscar documentos interfazados en lapso de fecha
SELECT * FROM cg_mov_01.cg_mov_contable_01 WHERE sw_interface='1' 
AND lapso='201702' 
AND fecha_documento BETWEEN '2017-02-04' AND '2017-02-09'
ORDER BY(fecha_documento)

-- Query para actualizar la interfaz a varios documentos contables

UPDATE cg_mov_01.cg_mov_contable_01 SET sw_interface = '1' WHERE prefijo='RTC' AND numero IN (1505, 1506, 
1507, 1533, 1534, 1544)

-------insertar cargos cups

--INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'862505','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'834203','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'862510','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'862505','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'862505','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'397203','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'836001','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'861103','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'867002','1',DEFAULT,DEFAULT,28370,NULL);
INSERT INTO hc_notas_operatorias_procedimientos VALUES(29566,'397206','1',DEFAULT,DEFAULT,28370,NULL);

--Actualizar color de SIIS

UPDATE system_usuarios_vars SET valor = 'AzulXp' WHERE variable = 'Tema'

--Actualizar planes tipo cama

UPDATE planes_tipos_camas SET tarifario_id = '0005', valor_lista = 73700 WHERE plan_id = 159 
AND cargo_cups = 'S20100' AND cargo = '38925';
--Excel
--=CONCATENAR("UPDATE planes_tipos_camas SET tarifario_id = '";E4;"', valor_lista = ";H4;" WHERE plan_id = ";B4;" AND cargo_cups = '";F4;"' AND cargo = '";G4;"';")

--Query para eliminar perfiles

DELETE FROM system_modulos_perfiles_opciones WHERE system_modulo_perfil_id IN (2594,
2595,
2596,
2597,
2598,
2604,
2605,
2606,
2607,
2608,
2723,
2724,
2725,
2771,
2792,
2793,
2794,
2795,
2796);

DELETE FROM system_modulos_perfiles WHERE perfil_id = 128;
    DELETE FROM system_menu_items_perfiles WHERE perfil_id = 128;
        DELETE FROM system_perfiles WHERE perfil_id = 128;
		
--cargue de medicamento/insumo en cuenta con transaccion y bodega discriminado
SELECT cd.transaccion
, bd.codigo_producto
, cd.numerodecuenta
, cd.cargo
, cd.departamento
, bdn.bodega
, cd.cantidad
, cd.precio 
FROM cuentas_detalle cd
INNER JOIN bodegas_documentos_d bd ON (cd.consecutivo=bd.consecutivo)
INNER JOIN bodegas_doc_numeraciones  bdn ON (bd.bodegas_doc_id = bdn.bodegas_doc_id)
WHERE cd.numerodecuenta=217576
AND bd.codigo_producto='0201010542'
ORDER BY cd.departamento

--cargue de medicamento/insumo en cuenta con sumatoria por bodega sin trasaccion

SELECT bd.codigo_producto
, cd.numerodecuenta
, cd.cargo
, cd.departamento
, bdn.bodega
, SUM (cd.cantidad)
, cd.precio 
FROM cuentas_detalle cd
INNER JOIN bodegas_documentos_d bd ON (cd.consecutivo=bd.consecutivo)
INNER JOIN bodegas_doc_numeraciones  bdn ON (bd.bodegas_doc_id = bdn.bodegas_doc_id)
WHERE cd.numerodecuenta=217576
AND bd.codigo_producto='0201010542'
GROUP BY 1,2,3,4,5,7
ORDER BY cd.departamento

--Query para buscar medicamentos devueltos

SELECT   /*b.*, a.usuario_id,
         a.fecha_registro,
         a.bodega,*/ d.*
FROM inv_solicitudes_devolucion a, 
     inv_solicitudes_devolucion_d b,
     bodegas_documentos_d c,
     cuentas_detalle d
WHERE   a.documento = b.documento
    AND a.numeracion = c.numeracion
    AND c.consecutivo = d.consecutivo
    AND b.codigo_producto = c.codigo_producto
    --AND d.codigo_producto = '0201010368'
    AND d.cargo = 'DIMD'
    AND a.ingreso = 244342
    --AND d.numerodecuenta = 68634


--Query para buscar la solicitud de un medicamento quien despacho

SELECT  a.solicitud_id,
        a.ingreso,
        a.fecha_solicitud,
        a.estacion_id,
        b.medicamento_id,
        b.cant_solicitada,
        a.usuario_id,
        c.nombre AS usuario_solicito,
        a.documento_despacho,
        d.usuario_id,
        e.nombre AS usuario_despacho,
		d.fecha_registro AS fecha_despacho 
FROM hc_solicitudes_medicamentos a,
     hc_solicitudes_medicamentos_d b,
     system_usuarios c,
     system_usuarios e,
     bodegas_documento_despacho_med d 
WHERE a.solicitud_id = b.solicitud_id
  AND c.usuario_id = a.usuario_id
  AND a.documento_despacho = d.documento_despacho_id
  AND d.usuario_id = e.usuario_id
  AND a.ingreso = 80083
  AND b.medicamento_id = '0102010072'
ORDER BY a.fecha_solicitud


--Query para buscar la solicitud de un insumo quien despacho


SELECT  a.solicitud_id,
		a.sw_estado,
        a.ingreso,
        a.fecha_solicitud,
        a.estacion_id,
        b.codigo_producto,
        b.cantidad AS cantidad_solicitada,
        a.usuario_id,
        c.nombre AS usuario_solicito,
        a.documento_despacho,
		d.cantidad AS cantidad_despachada,
        f.usuario_id,
        e.nombre AS usuario_despacho,
        f.fecha_registro AS fecha_despacho 
FROM hc_solicitudes_medicamentos a,
     hc_solicitudes_insumos_d b,
     system_usuarios c,
     system_usuarios e,
     bodegas_documento_despacho_ins_d d,
	 bodegas_documento_despacho_med f
WHERE a.solicitud_id = b.solicitud_id
AND b.consecutivo_d = d.consecutivo_solicitud
  AND c.usuario_id = a.usuario_id
  AND d.documento_despacho_id = f.documento_despacho_id
  AND f.usuario_id = e.usuario_id
  AND a.ingreso = 179072
  AND b.codigo_producto= '0201010618'
ORDER BY a.fecha_solicitud


-- Query para actualizar facturas de pacientes plan particular
	
UPDATE fac_facturas SET sw_clase_factura = 1, tipo_factura = 1 WHERE factura_fiscal IN (57615, 58616, 5936)

-- Query para consultar los ID contables repetidos en glosas

SELECT DISTINCT b.glosa_id, 
                b.factura_fiscal, 
                b.numero, 
                b.prefijo_glosa
FROM glosas b
WHERE b.numero IN  (SELECT a.numero
                    FROM glosas a
                    WHERE a.numero IS NOT NULL
                    GROUP BY 1
                    HAVING COUNT(*) > 1)
ORDER BY b.numero

--Query para consultar plan de cuenta y factura

SELECT a.factura_fiscal, a.plan_id AS plan_facturas, c.numerodecuenta, c.plan_id AS plan_cuentas
FROM fac_facturas a, fac_facturas_cuentas b, cuentas c 
WHERE a.factura_fiscal = b.factura_fiscal
AND c.numerodecuenta = b.numerodecuenta
AND b.factura_fiscal IN (51624,
54508,
60391,
61106,
61656,
61977,
62153,
62593,
62601,
62903,
63092,
63311)
ORDER BY b.factura_fiscal

--Query para ver los movimientos de un producto

SELECT  a.numerodecuenta,c.ingreso,g.fecha_ingreso,
a.departamento,
f.descripcion,
a.cargo,
a.cantidad,
a.precio,
a.valor_cargo,
d.codigo_producto,
d.descripcion,
a.fecha_cargo AS fecha_cargo_producto
FROM 
 cuentas_detalle a,
 bodegas_documentos_d b,
 cuentas c,
 inventarios_productos d,
 departamentos f,
 ingresos g
WHERE
a.numerodecuenta=c.numerodecuenta AND
a.consecutivo=b.consecutivo AND
b.codigo_producto=d.codigo_producto AND
c.estado!= '5' AND
a.departamento=f.departamento AND 
c.ingreso = g.ingreso AND
d.codigo_producto IN ( '0102010123', 'XXXXXXX')
'10295756'  ,
'1151936547',
'1143842298',
'29671004'  ,
'1061533446',
'94396266'  ,
'38644411'			


-- Planes cuentas

SELECT a.plan_id AS plan_cuentas,
c.plan_id AS plan_tarifario,
b.tarifario_id AS tarifario_cuentas_detalle,
c.tarifario_id AS tarifario,
b.numerodecuenta AS numero_cuenta_detalle
FROM cuentas a, 
cuentas_detalle b,
plan_tarifario c
WHERE a.numerodecuenta = b.numerodecuenta
AND a.plan_id = c.plan_id
AND b.tarifario_id <> c.tarifario_id
AND a.plan_id IN (219,196)
AND a.estado IN ('1','2','3')
AND c.tarifario_id IN ('0004', '0005')
AND b.tarifario_id <> 'SYS'

--Estado de cuenta cuadrada

UPDATE cuentas SET estado='3' WHERE (estado='1' OR estado='2')AND numerodecuenta IN (
132917)

--Actualizar plan en cuentas
UPDATE cuentas SET plan_id = 219, tipo_afiliado_id = 2, rango = '1' WHERE numerodecuenta IN (72815,
73652,
75170,
72226,
74702,
75618,
76978,
75851,
74643,
73982,
68919)

--Insertar codigos de procedimientos en nota operatoria
=CONCATENAR("INSERT INTO hc_notas_operatorias_procedimientos VALUES(24191,'";A2;"','1',null,nextval('hc_notas_operatorias_procedimientos_operatoria_id_seq'::regclass),23080,null);")


-- Borrar Nota Operatorias
             
	 DELETE FROM hc_descripcion_cirugia WHERE hc_nota_operatoria_cirugia_id = 36387;
   DELETE FROM hc_notas_operatorias_profilaxis WHERE hc_nota_operatoria_cirugia_id = 36387;
   DELETE FROM hc_notas_operatorias_procedimientos WHERE hc_nota_operatoria_cirugia_id = 36387;
   DELETE FROM hc_diagnosticos_asociados_postqx_paciente_noc WHERE hc_nota_operatoria_cirugia_id = 36387;
   DELETE FROM hc_cultivos_quirurgicos WHERE hc_nota_operatoria_cirugia_id = 36387;
   DELETE FROM hc_hallazgos_quirurgicos WHERE hc_nota_operatoria_cirugia_id = 36387;
   DELETE FROM hc_patologia_quirurgicos WHERE hc_nota_operatoria_cirugia_id = 36387;
   DELETE FROM hc_notas_operatorias_cirugias WHERE hc_nota_operatoria_cirugia_id = 36387;
																								   

----------ELIMINAR ACTAS
DELETE FROM actas_conciliacion_glosas_detalle WHERE acta_conciliacion_id=537;
UPDATE glosas_respuestas SET acta_conciliacion_id=NULL WHERE acta_conciliacion_id=537;
	         
-- Cambiar usuario en nota operatoria

             UPDATE hc_descripcion_cirugia SET usuario_id = 1117 WHERE hc_nota_operatoria_cirugia_id = 34305;
    UPDATE hc_notas_operatorias_profilaxis SET usuario_id = 1117 WHERE hc_nota_operatoria_cirugia_id = 34305;
            UPDATE hc_cultivos_quirurgicos SET usuario_id = 1117 WHERE hc_nota_operatoria_cirugia_id = 34305;
           UPDATE hc_hallazgos_quirurgicos SET usuario_id = 1117 WHERE hc_nota_operatoria_cirugia_id = 34305;
           UPDATE hc_patologia_quirurgicos SET usuario_id = 1117 WHERE hc_nota_operatoria_cirugia_id = 34305;
     UPDATE hc_notas_operatorias_cirugias SET usuario_id =  1117 WHERE hc_nota_operatoria_cirugia_id = 34305;
	  
--Query para actualizar precio de un producto en una lista de precios

UPDATE lista_precios_detalle SET precio = xxxx WHERE codigo_lista = '003' and codigo_producto= 'xxxxxx'

--Query para buscar permisos de la opciones en un modulo y a que perfil tienen este permiso

SELECT  a.system_modulo_perfil_id,
	a.modulo,
	a.opcion_permiso_nombre,
	CASE WHEN a.opcion_valor = '0' THEN 'INACTIVO'
    WHEN a.opcion_valor ='1' THEN 'ACTIVO'
    END AS permiso,
	c.descripcion		
FROM system_modulos_perfiles_opciones a,
	system_modulos_perfiles b, 
    system_perfiles c
WHERE a.system_modulo_perfil_id = b.system_modulo_perfil_id
	AND b.perfil_id = c.perfil_id
	AND a.modulo = 'AuditoriaCuentas' -- Aqui va el modulo 
	AND a.opcion_permiso_nombre = 'sw_crear_nota' -- Aqui la opcion dentro del modulo
	ORDER BY 5
	
--Query para actualizar el permiso a la opcion de un modulo	
	
UPDATE system_modulos_perfiles_opciones SET opcion_valor = '0' -- (0) para que no lo tenga, (1) para que si
WHERE system_modulo_perfil_id <> 1504
AND modulo = 'AuditoriaCuentas' -- El modulo
AND opcion_permiso_nombre = 'sw_crear_nota' -- La opcion dentro del modulo

-- Query para buscar cuentas relacionadas a un evento con valores

SELECT a.ingreso,
b.numerodecuenta,
b.total_cuenta,
b.valor_total_empresa AS total_empresa_cuentas,
e.factura_fiscal,
e.total_factura,
c.evento,
c.saldo AS saldo_soat,
c.saldo_inicial AS saldo_inicial_soat
FROM ingresos_soat a,
cuentas b,
soat_eventos c,
fac_facturas_cuentas d,
fac_facturas e, 
planes f
WHERE a.ingreso = b.ingreso
AND b.numerodecuenta = d.numerodecuenta
AND d.factura_fiscal = e.factura_fiscal
AND b.plan_id = f.plan_id
AND f.tipo_cliente = '20'
AND a.evento = c.evento
AND b.estado <> '5' 
AND e.estado <> '0'
AND c.paciente_id = '25665695'
--AND c.evento =  XXXX Usar esta linea para buscar el evento especifico, en caso de que el paciente tenga mas de un evento
ORDER BY c.evento

--Uno para consultar la cantidad
SELECT bd.codigo_producto
, cd.numerodecuenta
, cd.cargo
, cd.departamento
, bdn.bodega
, SUM (cd.cantidad)
, cd.precio
FROM cuentas_detalle cd
INNER JOIN bodegas_documentos_d bd ON (cd.consecutivo=bd.consecutivo)
INNER JOIN bodegas_doc_numeraciones bdn ON (bd.bodegas_doc_id = bdn.bodegas_doc_id)
WHERE cd.numerodecuenta=198022
AND bd.codigo_producto='0102010107'
GROUP BY 1,2,3,4,5,7
ORDER BY cd.departamento

--otro para ver la transacion

SELECT cd.transaccion
, bd.codigo_producto
, cd.numerodecuenta
, cd.cargo
, cd.departamento
, bdn.bodega
, cd.cantidad
, cd.precio
FROM cuentas_detalle cd
INNER JOIN bodegas_documentos_d bd ON (cd.consecutivo=bd.consecutivo)
INNER JOIN bodegas_doc_numeraciones bdn ON (bd.bodegas_doc_id = bdn.bodegas_doc_id)
WHERE cd.numerodecuenta=198022
AND bd.codigo_producto='0102010107'
ORDER BY cd.departamento

-- Query para buscar entre documentos generados

select a.prefijo, a.numero, a.codigo_producto, a.total_costo, b.prefijo, b.numero, b.codigo_producto, b.total_costo
from inv_bodegas_movimiento_d a,  
inv_bodegas_movimiento_d b
where a.prefijo = 'IOC' AND a.numero = 2092 
AND b.prefijo = 'EDP' AND b.numero = 68
AND a.total_costo != b.total_costo
AND a.codigo_producto = b.codigo_producto

--revisar
SELECT  a.solicitud_id,
        a.ingreso,
        a.fecha_solicitud,
        a.estacion_id,
        b.medicamento_id
        --b.cantidad,
        --a.usuario_id,
        --c.nombre AS usuario_solicito,
        --a.documento_despacho,
        --f.usuario_id,
        --e.nombre AS usuario_despacho,
        --f.fecha_registro AS fecha_despacho 
FROM hc_solicitudes_medicamentos a,
     hc_solicitudes_medicamentos_d b
     --system_usuarios c,
     --system_usuarios e,
     --bodegas_documento_despacho_ins_d d,
	 --bodegas_documento_despacho_med f
WHERE a.solicitud_id = b.solicitud_id
--AND b.consecutivo_d = d.consecutivo_solicitud
  --AND c.usuario_id = a.usuario_id
  --AND d.documento_despacho = f.documento_despacho_id
  --AND f.usuario_id = e.usuario_id
  AND a.ingreso = 191258
  AND b.medicamento_id= '0102010029'
  AND a.sw_estado =! 3
ORDER BY a.fecha_solicitud

--Query para actualizar los permisos de los componente de la estacion

UPDATE estaciones_enfermeria_usuarios_componentes 
SET  sw_permiso = '1'
--FROM estaciones_enfermeria_usuarios_componentes as x
WHERE estacion_componente_id = '04'
AND usuario_id = (
SELECT usuario_id
FROM (
            SELECT sp.usuario_id
               FROM system_usuarios_perfiles sp 
               WHERE sp.perfil_id = 1
AND sp.usuario_id = estaciones_enfermeria_usuarios_componentes.usuario_id) AS usuarios)

-- ACTUALIZAR INTERFACE A DOC EN CG MOV

UPDATE cg_mov_01.cg_mov_contable_01 SET sw_interface = 1 WHERE prefijo = 'IFR' AND numero IN (9592, 9593, 9595)

-- Crear perfil igual a otro en base a un csv

=CONCATENAR("INSERT INTO system_modulos_perfiles VALUES (DEFAULT, ";B596;", ";C596;", ";D596;", 145, ";F596;", ";G596;", ";H596;", NOW(), 610, ";K596;", NULL, ";M596;", NULL, NULL, ";P596;", ";Q596;", ";R596;", ";S596;", ";T596;", ";U596;"")


--ACTUALIZAR PERFILES FARMACIA

-- 84 	AUX SERVICIOS FARMACEUTICO FARMACIA CENTRAL
-- 96 	AUX SERVICIOS FARMACEUTICO FARMACIA URG 	
-- 64 	AUX SERVICIOS FARMACEUTICO FARMACIA CIRUGIA

-- BODEGAS
-- BF - Farmacia Central
-- BC - Farmacia Cirugia
-- OU - Farmacia Urgencias
-- CM - ALMACEN CENTRAL DE MEZCLAS
				ALTER TABLE userpermisos_solicitudes_bodegas DISABLE TRIGGER validacion_bodega;        
UPDATE system_usuarios_perfiles SET perfil_id=84 WHERE usuario_id = 1898; -- Actualizar perfil usuario
UPDATE userpermisos_solicitudes_bodegas SET bodega = 'BF' WHERE usuario_id =1898 AND bodega='BC'; -- Actualizar bodegas módulo "ADMINISTRACION DE BODEGAS"
UPDATE inv_bodegas_userpermisos SET bodega = 'BF' WHERE usuario_id =1898 AND bodega='BC'; -- Actualizar bodegas módulo "TRANSACCIONES DE BODEGAS"
UPDATE bodegas_usuarios SET bodega = 'BF' WHERE usuario_id =1898 AND bodega='BC'; -- 'COLOCAR LA BODEGA ACTUAL' Actualizar bodegas módulo "BODEGAS EMPRESAS"
				ALTER TABLE userpermisos_solicitudes_bodegas ENABLE TRIGGER validacion_bodega;

--CREAR USUARIO NUEVO EN FARMACIA
	    --INSERT INTO system_usuarios_perfiles VALUES(84,'01',2475);
INSERT INTO system_usuarios_vars values (2589,'LimitRowsBrowser','100');
INSERT INTO userpermisos_solicitudes_bodegas VALUES('01','01',2589,'BF',nextval('userpermisos_solicitudes_bodegas_userpermiso_bodega_id_seq'::regclass)); --Insertar bodegas módulo "ADMINISTRACION DE BODEGAS"
INSERT INTO userpermisos_solicitudes_bodegas VALUES('01','01',2589,'CP',nextval('userpermisos_solicitudes_bodegas_userpermiso_bodega_id_seq'::regclass)); --Insertar bodegas módulo "ADMINISTRACION DE BODEGAS" - Almacen central de mezclas
INSERT INTO inv_bodegas_userpermisos VALUES(31,'01','01','BF',2589,'0'); --Insertar bodegas módulo "TRANSACCIONES DE BODEGAS" DOC-TRASLADO
INSERT INTO bodegas_usuarios VALUES('01','01','BF',2589);--Insertar bodegas módulo "BODEGAS EMPRESAS"
INSERT INTO inv_bodegas_userpermisos VALUES(31,'01','01','CL',2589,'0');
INSERT INTO bodegas_usuarios VALUES('01','01','CL',2589);
																
INSERT INTO system_usuarios_vars values (2671,'LimitRowsBrowser','100');
INSERT INTO userpermisos_solicitudes_bodegas VALUES('01','01',2671,'BF',nextval('userpermisos_solicitudes_bodegas_userpermiso_bodega_id_seq'::regclass)); --Insertar bodegas módulo "ADMINISTRACION DE BODEGAS"
INSERT INTO userpermisos_solicitudes_bodegas VALUES('01','01',2671,'CP',nextval('userpermisos_solicitudes_bodegas_userpermiso_bodega_id_seq'::regclass)); --Insertar bodegas módulo "ADMINISTRACION DE BODEGAS" - Almacen central de mezclas
INSERT INTO inv_bodegas_userpermisos VALUES(31,'01','01','BF',2671,'0'); --Insertar bodegas módulo "TRANSACCIONES DE BODEGAS" DOC-TRASLADO
INSERT INTO bodegas_usuarios VALUES('01','01','BF',2671);--Insertar bodegas módulo "BODEGAS EMPRESAS"
INSERT INTO inv_bodegas_userpermisos VALUES(31,'01','01','CL',2671,'0'); --Insertar bodegas módulo "TRANSACCIONES DE BODEGAS" DOC-TRASLADO
INSERT INTO bodegas_usuarios VALUES('01','01','CL',2671);--Insertar bodegas módulo "BODEGAS EMPRESAS"
INSERT INTO inv_bodegas_userpermisos VALUES(31,'01','01','CP',2671,'0'); --Insertar bodegas módulo "TRANSACCIONES DE BODEGAS" DOC-TRASLADO
INSERT INTO bodegas_usuarios VALUES('01','01','CP',2671);--Insertar bodegas módulo "BODEGAS EMPRESAS"

			  INSERT INTO usuarios_asigna_reportes VALUES(3,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(5,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(7,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(8,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(9,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(20,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(21,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(22,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(23,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(24,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(25,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(26,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(27,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(31,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(32,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(33,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(34,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(57,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(58,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(59,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(60,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(62,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(63,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(64,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(65,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(66,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(67,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(68,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(72,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(79,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(80,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(81,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(84,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(96,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(99,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(103,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(106,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(107,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(108,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(109,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(115,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(117,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(118,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(119,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(120,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(126,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(135,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(142,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(145,2589,910,now()); 
		      INSERT INTO usuarios_asigna_reportes VALUES(148,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(151,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(151,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(172,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(208,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(210,2589,910,now()); 
			  INSERT INTO usuarios_asigna_reportes VALUES(220,2589,910,now()); 			  
			  
			  
			  
-Programa para generación de recargos de turnos en SIIS.

INSERT INTO turnos_profesionales_alterno (fecha,identificacion,nombre,tipo_turno_id,fecha_registro,usuario_registro) VALUES ('1/12/2020','1042448284','JEFFERSON SANABRIA CURVELO',9,now(),2);


--Transaciones de bogega
insert into inv_bodegas_userpermisos values ('22','01','01','CM',2381,'0');
insert into inv_bodegas_userpermisos values ('24','01','01','CM',2381,'0');
insert into inv_bodegas_userpermisos values ('26','01','01','CM',2381,'0');
insert into inv_bodegas_userpermisos values ('29','01','01','CM',2381,'0');
insert into inv_bodegas_userpermisos values ('31','01','01','CM',2381,'0');
insert into inv_bodegas_userpermisos values ('31','01','01','CP',2381,'0');

--Reportes
INSERT INTO usuarios_asigna_reportes  VALUES(54,2381,910,now()); -- INSERTA REPORTE Existencias Actuales
INSERT INTO usuarios_asigna_reportes  VALUES(55,2381,910,now()); -- INSERTA REPORTE Existencias Bodegas
INSERT INTO usuarios_asigna_reportes  VALUES(56,2381,910,now()); -- INSERTA REPORTE Existencias Farmacia
INSERT INTO usuarios_asigna_reportes  VALUES(122,2381,910,now()); -- INSERTA REPORTE Existencias Actuales
INSERT INTO usuarios_asigna_reportes  VALUES(123,2381,910,now()); -- INSERTA REPORTE Existencias Bodegas
INSERT INTO usuarios_asigna_reportes  VALUES(124,2381,910,now()); -- INSERTA REPORTE Existencias Farmacia
INSERT INTO usuarios_asigna_reportes  VALUES(207,2381,910,now()); -- INSERTA REPORTE Existencias Farmacia
			  
https://asistencial.clinicacristorey.com.co/SIIS_CR/programas/calculo_recargo_turnos_alterno.php	



insert into bodegas_usuarios values ('01','01','PM',837);
--insert into bodegas_usuarios values ('01','01','CL',837);
insert into bodegas_usuarios values ('01','01','CF',837);
insert into bodegas_usuarios values ('01','01','CE',837);
insert into bodegas_usuarios values ('01','01','AC',837);
insert into bodegas_usuarios values ('01','01','BA',837);
insert into bodegas_usuarios values ('01','01','SG',837);
insert into bodegas_usuarios values ('01','01','AF',837);
insert into bodegas_usuarios values ('01','01','GH',837);
insert into bodegas_usuarios values ('01','01','TI',837);
insert into bodegas_usuarios values ('01','01','SS',837);
insert into bodegas_usuarios values ('01','01','CM',837);
insert into bodegas_usuarios values ('01','01','MC',837);
--insert into bodegas_usuarios values ('01','01','BP',837);
--insert into bodegas_usuarios values ('01','01','LA',837);
insert into bodegas_usuarios values ('01','01','BI',837);
insert into bodegas_usuarios values ('01','01','BC',837);
insert into bodegas_usuarios values ('01','01','OU',837);
insert into bodegas_usuarios values ('01','01','BO',837);
insert into bodegas_usuarios values ('01','01','BF',837);
insert into bodegas_usuarios values ('01','01','MO',837);
insert into bodegas_usuarios values ('01','01','AN',837);
insert into bodegas_usuarios values ('01','01','HE',837);
insert into bodegas_usuarios values ('01','01','SP',837);
insert into bodegas_usuarios values ('01','01','TR',837);
insert into bodegas_usuarios values ('01','01','RP',837);
insert into bodegas_usuarios values ('01','01','TM',837);
insert into bodegas_usuarios values ('01','01','JJ',837);
--insert into bodegas_usuarios values ('01','01','LB',837);
insert into bodegas_usuarios values ('01','01','CP',837);
insert into bodegas_usuarios values ('01','01','AP',837);
insert into bodegas_usuarios values ('01','01','CI',837);
insert into bodegas_usuarios values ('01','01','CT',837);
insert into bodegas_usuarios values ('01','01','LH',837);
insert into bodegas_usuarios values ('01','01','BT',837);
insert into bodegas_usuarios values ('01','01','MR',837);
insert into bodegas_usuarios values ('01','01','MD',837);
insert into bodegas_usuarios values ('01','01','EC',837);
insert into bodegas_usuarios values ('01','01','GT',837);
insert into bodegas_usuarios values ('01','01','GB',837);
		  
		

118994,
150790,
180114,
186386,
191119,
201925,
216999,
239510,
246661,
246662,
252714,
255688,
257386,
263482,
269939,
272028,
273316,
276304,
276812,
277492,
278034,
279871,
280752,
282789,
283243,
285155,
286742
				   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
			   
															  
----------DOCUMENTOS A BODEGA

INSERT INTO inv_bodegas_documentos VALUES(16,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(17,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(18,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(19,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(20,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(21,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(22,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(23,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(24,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(25,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(26,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(27,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(28,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(29,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(30,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(31,'01','01','HC',DEFAULT,'1');
INSERT INTO inv_bodegas_documentos VALUES(50,'01','01','HC',DEFAULT,'1');

																
--INSERTAR USUARIO EN CONTROL CUENTAS - ASIGNARLO A DEPTO
--Departamentos
/*
ADMURG	Admisiones urgencias
FACURG	Facturación Urgencias
FACIMA	Facturación Imágenes
FACTP3	Facturación piso 3
FACTP4	Facturación piso 4
FACTP5	Facturación piso 5
FAUCI3	Facturación UCI 3 - 4
FACIRU	Facturación Cirugía
FACCNT	Facturación central
AUDCTA	Auditoria cuentas médicas
FACAUD	Facturación Auditoria
FACCEX	Facturación consulta externa
COBRZA	Cobranza
COOFAC	Coordinación de facturación
CONCTA	Control cuentas
FACTP6	Facturación piso 6
GLODEV	Radicacion Adres
GRUPO1	Grupo 1 Auditoria Glosas y Dev
GRUPO3	Grupo 3 Auditoria Glosas y Dev
GRUPO2	Grupo 2 Auditoria Glosas y Dev
GDES	Gestion documental y Estadisitica
AUDCCT	Auditoria Concurrente
JURIDI	Juridico
FAUCI5	Facturación UCI 5 - 6
FACLAB	Facturacion Laboratorio
INVGLO	Inventario Glosas Dev
INVFAC	Inventario Cuentas Facts
AUTORI	Autorizaciones
AUDDFA	AUDITORIA DFA
DEVNES	Devoluciones
*/
																		  INSERT INTO usuarios_menu_prosi VALUES(2435,2,'1','0','0','1','1');
																		  INSERT INTO usuarios_menu_prosi VALUES(2435,3,'0','1','0','1','0');
																		  INSERT INTO usuarios_menu_prosi VALUES(2435,6,'0','0','0','1','1');
INSERT INTO system_usuarios_departamentos_cc VALUES(nextval('system_usuarios_departamentos_cc_id_seq'::regclass),2435,'FACCNT',now(),910,'1');
																												 

-- Query para obtener los todos los permisos a las opciones de un modulo para un perfil 

SELECT a.*, b.departamento, b.tipo_caja, b.grupo_departamento_id
FROM system_modulos_perfiles_opciones a,
system_modulos_perfiles b
WHERE a.system_modulo_perfil_id = b.system_modulo_perfil_id
AND b.perfil_id = 100 -- Perfil a copia
ORDER BY a.system_modulo_perfil_id

--Query para traer el id del permisos a los modulos

SELECT b.system_modulo_perfil_id
FROM system_modulos_perfiles_opciones a,
system_modulos_perfiles b
WHERE a.system_modulo_perfil_id = b.system_modulo_perfil_id
AND a.modulo = b.modulo
AND b.modulo = 'Glosas'
AND b.perfil_id = 100
GROUP BY b.system_modulo_perfil_id

--Query para actualizar estado de relacion de cuentas



--Query para buscar evolucion de un profesional en sub-modulos

SELECT a.* 
FROM hc_evoluciones_submodulos a, 
hc_evoluciones b,
ingresos c
WHERE a.evolucion_id = b.evolucion_id 
AND b.ingreso = c.ingreso
AND b.usuario_id = 1134 -- ID del usuario profesional
AND c.paciente_id = '66921660' -- identificacion del paciente

select b.descripcion
from system_usuarios a, 
system_perfiles b,
system_usuarios_perfiles c
where a.usuario_id = c.usuario_id
and c.perfil_id = b.perfil_id
and a.usuario_id IN (498, 1141, 1138, 1144)

--Consulta para traer cargos de respuesta de glosa

SELECT c.glosa_respuesta_cargo_id, 
e.cargo, 
a.glosa_id
FROM glosas a,
glosas_respuestas b,
glosas_respuestas_cargos c,
glosas_detalle_cargos d,
cuentas_detalle e
WHERE a.glosa_id = b.glosa_id
AND b.glosa_respuesta_id = c.glosa_respuesta_id
AND c.glosa_detalle_cargo_id = d.glosa_detalle_cargo_id
AND d.transaccion = e.transaccion
AND a.sw_estado NOT IN ('0','3')
AND a.factura_fiscal = 55049 --Numero de la factura
AND e.cargo IN ('39118', '39118', '39121', '39124', '39209') --Cargos de la respuesta a buscar

--Consulta para traer cargos de la ultima respuesta
SELECT c.glosa_respuesta_cargo_id, 
e.cargo, 
a.glosa_id,
b.glosa_respuesta_id
FROM glosas a,
glosas_respuestas b,
glosas_respuestas_cargos c,
glosas_detalle_cargos d,
cuentas_detalle e
WHERE a.glosa_id = b.glosa_id
AND b.glosa_respuesta_id = c.glosa_respuesta_id
AND c.glosa_detalle_cargo_id = d.glosa_detalle_cargo_id
AND d.transaccion = e.transaccion
AND a.sw_estado NOT IN ('0','3')
AND a.factura_fiscal = 16882
AND b.glosa_respuesta_id = (SELECT MAX (f.glosa_respuesta_id) FROM glosas_respuestas as f WHERE a.glosa_id=f.glosa_id)--consulta la ultima respuesta
AND e.cargo IN ('21101', '21102', '21105', '21106', '21201') --Cargos de la respuesta a buscar

-- Numerador de perfiles

SELECT   ROW_NUMBER() OVER(ORDER BY perfil_id) AS cantidad_perfiles, *
FROM system_perfiles

-- Remplazar un dato por otro

update system_perfiles set descripcion = REPLACE(descripcion,'_',' ')

--modificar fecha a ingreso pacientes del 26 oct
--=CONCATENAR("update ingresos set fecha_ingreso='";F5;"' where ingreso=";C5;";")
update ingresos set fecha_ingreso='2018-10-26 11:37:00' where ingreso=97977;


-- Actualiza interface en cg_mov_01
SELECT * FROM
UPDATE cg_mov_01.cg_mov_contable_01
SET sw_interface='1'
WHERE prefijo='ECI' AND numero IN('3321',
'1076',
'7720',
'7722',
'7724',
'7727',
'7731',
'3245')

--Query para ver cargos en cuentas de cirugia

SELECT a.numerodecuenta, 
c.ingreso, 
p.tipo_id_paciente, 
p.paciente_id, 
a.departamento, 
f.descripcion, 
a.cargo, 
a.cantidad, 
a.precio, 
d.codigo_producto, 
d.descripcion, 
a.fecha_cargo AS fecha_cargo_producto, 
d.referencia AS Cod_Casa_Medica 
FROM cuentas_detalle a, 
bodegas_documentos_d b, 
cuentas c, 
inventarios_productos d, 
departamentos f, 
ingresos g, 
pacientes p 
WHERE a.numerodecuenta=c.numerodecuenta 
AND a.consecutivo=b.consecutivo 
AND b.codigo_producto=d.codigo_producto 
AND a.departamento=f.departamento 
AND c.ingreso = g.ingreso 
AND p.tipo_id_paciente=g.tipo_id_paciente 
AND p.paciente_id=g.paciente_id 
AND d.grupo_id='03' 
AND c.estado!= '5' 
AND a.fecha_cargo::date BETWEEN '2018-09-01' AND '2018-10-31' 
ORDER BY a.numerodecuenta

--ver un medicamento en detalle de la cuenta
SELECT cd.*
FROM  bodegas_documentos_d bd
INNER JOIN cuentas_detalle cd ON cd.consecutivo=bd.consecutivo
WHERE cd.numerodecuenta=217576
AND bd.codigo_producto='0201010542'
AND cd.cargo IN('IMD','DIMD')
ORDER BY cd.cargo, cd.departamento

--Activar productos especificos en una orden de compra
UPDATE compras_requisiciones_detalle SET estado='1' WHERE requisicion_id=4803 
AND codigo_producto IN('0503020010',
'0503020009',
'0503020007',
'0503020017',
'0503010032',
'0503010019',
'0504050010')

-- Cambiar plan de solicitudes
UPDATE hc_os_solicitudes SET plan_id=207
WHERE hc_os_solicitud_id IN(745647, 745648, 746870, 746875, 746891, 746900)

-------------------------------------------parametrizacion por grupos
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41750501' WHERE centro_de_costo_id='01010102';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41751001' WHERE centro_de_costo_id='01010112';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41751001' WHERE centro_de_costo_id='01010122';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41751501' WHERE centro_de_costo_id='01010106';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41751501' WHERE centro_de_costo_id='01010107';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41751501' WHERE centro_de_costo_id='01010108';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41752001' WHERE centro_de_costo_id='01010104';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41752501' WHERE centro_de_costo_id='01010103';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41752501' WHERE centro_de_costo_id='01010116';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41752501' WHERE centro_de_costo_id='01010117';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41752501' WHERE centro_de_costo_id='01010109';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41752501' WHERE centro_de_costo_id='01010118';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41753001' WHERE centro_de_costo_id='01010119';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41753001' WHERE centro_de_costo_id='01010114';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41757001' WHERE centro_de_costo_id='01010101';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41757001' WHERE centro_de_costo_id='01010105';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41757001' WHERE centro_de_costo_id='01010111';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41757001' WHERE centro_de_costo_id='01010113';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41757001' WHERE centro_de_costo_id='01010110';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41757001' WHERE centro_de_costo_id='01010120';
UPDATE cg_conf.doc_fv01_inv_grupos_productos_por_cc SET cuenta_glosa='41757001' WHERE centro_de_costo_id='01010121';
UPDATE cg_conf.doc_fv01_cargos_por_cc SET cuenta_glosa='41751001' WHERE centro_de_costo_id='01010112' AND tarifario_id='0007';

																	                                             
--Modificar TRIGGERS
ALTER TABLE nombre_tabla DISABLE TRIGGER nombre_trigger;

update nombre_tabla set nombre_campo=valor where nombre_campo_condicion= valor ;    



      

ALTER TABLE nombre_tabla ENABLE TRIGGER nombre_trigger;    

--MODIFICAR FECHA DE INGRESO Y CUENTA PARA LOS INGRESOS POR ADMISIONES SIN HC
UPDATE cuentas SET fecha_registro='2019-03-06 08:29:00' WHERE numerodecuenta IN(XXXX,
XXXX);

ALTER TABLE cuentas_detalle DISABLE TRIGGER cuentas_contro_modificacion;
UPDATE cuentas_detalle SET fecha_cargo='2019-03-06 08:29:00' WHERE numerodecuenta IN(XXXX,
XXXX);
ALTER TABLE cuentas_detalle ENABLE TRIGGER cuentas_contro_modificacion;

UPDATE ingresos SET fecha_ingreso='2019-03-06 08:29:00', fecha_registro='2019-03-06 08:29:00' WHERE ingreso IN(XXXX,
XXXX);

--busca las citas asignadas a un profesional 
SELECT ac.agenda_cita_id, ac.sw_estado, ac.hora, aga.tipo_id_paciente, aga.paciente_id, p.primer_nombre||' '||p.segundo_nombre||' '||p.primer_apellido||' '||p.segundo_apellido AS nombre, aga.fecha_registro AS registro, aga.fecha_deseada::date
FROM agenda_citas_asignadas aga
INNER JOIN agenda_citas ac ON aga.agenda_cita_id=ac.agenda_cita_id
INNER JOIN pacientes p ON p.tipo_id_paciente=aga.tipo_id_paciente AND p.paciente_id=aga.paciente_id
INNER JOIN agenda_turnos agt ON agt.agenda_turno_id=ac.agenda_turno_id
WHERE agt.agenda_turno_id IN(
11264,
11280,
11360,
11358,
11359) AND agt.profesional_id='16918366'
ORDER BY 2

--CANCELA LAS CITAS
UPDATE agenda_citas SET sw_estado='3' WHERE agenda_cita_id IN(
202378, 
202379, 
202380, 
202381, 
202382, 
202383, 
202384, 
202385, 
202386, 
202387, 
202388, 
202389)

---------------actualiza valores
UPDATE glosas SET valor_pendiente = valor_no_aceptado 
WHERE glosa_id IN 
				(SELECT a.glosa_id
					FROM actas_conciliacion_glosas_detalle a
					WHERE a.acta_conciliacion_id = 592)


------ELIMINAR DOCUMENTOS UNO E
DELETE FROM cg_mov_contable WHERE prefijo='CGL' AND numero=10;
DELETE FROM cg_mov_contable_01_detalle WHERE documento_contable_id=376011;

----contabilidad
delete from cg_mov_01.cg_mov_contable_01_detalle where documento_contable_id=394299


--ELIMINAR RESPUESTA GLOSA IPS
DELETE FROM glosas_respuestas_cargos WHERE glosa_respuesta_id=130328 ;
DELETE FROM glosas_respuestas_inventarios WHERE glosa_respuesta_id=130328;
DELETE FROM glosas_respuestas_cuentas WHERE glosa_respuesta_id=130328;
--EPS
     DELETE FROM glosas_respuestas_eps_cargos WHERE glosa_respuesta_eps_id=58555;
DELETE FROM glosas_respuestas_eps_inventarios WHERE glosa_respuesta_eps_id=58555;
    DELETE FROM glosas_respuestas_eps_cuentas WHERE glosa_respuesta_eps_id=58555;

DELETE FROM glosas_respuestas_eps WHERE glosa_id=55369;58554
--GLOS
DELETE FROM glosas_respuestas WHERE glosa_id=61329;
UPDATE glosas SET valor_aceptado=0.00, sw_estado='1', valor_no_aceptado=0.00, valor_pendiente=valor_glosa WHERE glosa_id=61329

--INSUMOS MEDICOS
SELECT estado AS Activo, codigo_producto, descripcion, sw_pos FROM inventarios_productos WHERE grupo_id='02' AND clase_id='01' AND subclase_id='01'
UPDATE inventarios_productos SET sw_pos='1' WHERE grupo_id='02' AND clase_id='01' AND subclase_id='01' AND sw_pos='0'

--Buscar diagnostico de INGRESO
SELECT * FROM hc_diagnosticos_ingreso WHERE evolucion_id IN (SELECT hes.evolucion_id FROM hc_evoluciones_submodulos 
hes INNER JOIN hc_diagnosticos_ingreso hdi ON hdi.evolucion_id=hes.evolucion_id WHERE ingreso=XXXX AND 
submodulo='DiagnosticoI');

--insertar cuando tiene un registro
INSERT INTO ingresos_soat VALUES(22,27) ON CONFLICT(ingreso) DO NOTHING; --ingreso ya esta omite el registro
INSERT INTO ingresos_soat VALUES(25,2) ON CONFLICT(ingreso) DO NOTHING; --ingreso ya esta omite el registro
INSERT INTO ingresos_soat VALUES(21,27) ON CONFLICT(ingreso) DO NOTHING; --ingreso no esta lo ingresa
--se deben de tener en cuenta todas las primarias en el parentesis del conflict

--otro ejemplo
INSERT INTO cg_conf.doc_fv01_inv_grupos_productos_por_cc 
VALUES (
'01'
,'18'
,'01'
,'06'
,(select centro_de_costo_id from cg_conf.centros_de_costo_departamentos where departamento = 'HM1104')
,'41309020'
,'C'
,(select centro_de_costo_id from cg_conf.centros_de_costo_departamentos where departamento = 'HM1104')) 
ON CONFLICT (empresa_id,grupo_id,clase_id,subclase_id,centro_de_costo_id) 
DO UPDATE SET centro_costo_destino = 
(select centro_de_costo_id from cg_conf.centros_de_costo_departamentos where departamento = 'HM1104');

--usuarios BD
SELECT u.usename AS "Role name",
  CASE WHEN u.usesuper AND u.usecreatedb THEN CAST('superuser, create
database' AS pg_catalog.text)
       WHEN u.usesuper THEN CAST('superuser' AS pg_catalog.text)
       WHEN u.usecreatedb THEN CAST('create database' AS
pg_catalog.text)
       ELSE CAST('' AS pg_catalog.text)
  END AS "Attributes"
FROM pg_catalog.pg_user u
ORDER BY 1;

---Query para buscar los planes de las facturas
SELECT FAC.prefijo, FAC.factura_fiscal, CUE.numerodecuenta,  CUE.plan_id
PLA.plan_descripcion
FROM fac_facturas_cuentas FAC, cuentas CUE, planes PLA
WHERE 
FAC.numerodecuenta=CUE.numerodecuenta
AND CUE.plan_id=PLA.plan_id
AND factura_fiscal IN(40537)

------TEMPERATURA
INSERT INTO inv_tipos_medidas_equipos VALUES (21,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (21,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (22,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (22,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (23,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (23,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (24,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (24,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (25,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (25,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (26,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (26,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (27,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (27,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (28,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (28,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (29,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (29,'01',10.0000,30.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (30,'02',45.0000,70.0000);
INSERT INTO inv_tipos_medidas_equipos VALUES (30,'01',10.0000,30.0000);

----CODIGO INVIMA

UPDATE inventarios_productos SET codigo_invima IN 
('2012DM-0008870',
'2012DM-0008870',
'2012DM-0008870',
'2012DM-0008870',
'2007DM-0001053',
'2017DM-0017400',
'2014DM-0002401-R1',
'2014DM-0002401-R1',
'2014DM-0002401-R1')  
WHERE codigo_producto IN 
('0301090319',
'0301090351',
'0301140052',
'0301140053',
'0301140610',
'0301130019',
'0301010001',
'0301010002',
'0301010003')



-----Tabla Cups
UPDATE cups SET bys_producto_id='85101505' WHERE cargo IN (
'399602',
'890112',
'890212',
'890312',
'890412',
'890612',
'893810',
'939000',
'939100',
'939300',
'939401',
'939402',
'939403',
'939500',
'939601',
'939700',
'939800')


SELECT 
bd.codigo_producto,
bd.cantidad,
bd.total_costo
FROM
bodegas_documentos_d bd,
cuentas_detalle,
WHERE
FAC.numerodecuenta=CUE.numerodecuenta
AND CUE.plan_id=PLA.plan_id
AND factura_fiscal IN(40537)

