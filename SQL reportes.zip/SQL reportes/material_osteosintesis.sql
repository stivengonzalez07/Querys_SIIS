SELECT
ip.codigo_producto,
ip.descripcion AS descripcion_producto,
i.precio_venta,
ip.referencia,
ip.fecha_registro,
fa.descripcion AS casa_medica

FROM
inventarios i
INNER JOIN inventarios_productos ip ON (i.codigo_producto=ip.codigo_producto)
INNER JOIN inv_fabricantes fa ON(ip.fabricante_id=fa.fabricante_id)

WHERE
ip.fecha_registro::DATE BETWEEN _1 AND _2
--ip.fecha_registro::DATE BETWEEN '2020-01-01' AND '2020-01-10'
AND ip.grupo_id='03'

