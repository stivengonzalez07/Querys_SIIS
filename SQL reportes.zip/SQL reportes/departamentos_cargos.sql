SELECT *
FROM departamentos_cargos
ORDER BY departamento