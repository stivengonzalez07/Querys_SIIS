SELECT a.fecha_ingcaja,a.tipo_id_tercero,a.tercero_id,b.nombre_tercero,
c.factura_fiscal,c.prefijo,c.recibo_caja,d.total_factura,c.valor_abonado,d.saldo 
FROM recibos_caja a, terceros b, rc_detalle_tesoreria_facturas c,fac_facturas d 
WHERE a.tipo_id_tercero=b.tipo_id_tercero 
AND a.tercero_id=b.tercero_id 
AND a.prefijo=c.prefijo 
AND a.recibo_caja=c.recibo_caja 
AND c.prefijo_factura=d.prefijo 
AND c.factura_fiscal=d.factura_fiscal 
AND a.fecha_ingcaja BETWEEN _1 AND _2 
ORDER by a.fecha_ingcaja ASC
