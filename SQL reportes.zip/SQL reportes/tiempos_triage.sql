SELECT t.tipo_id_paciente, t.paciente_id,
p.primer_nombre,p.segundo_nombre,p.primer_apellido,p.segundo_apellido,p.fecha_nacimiento,edad(p.fecha_nacimiento) AS edad, p.sexo_id AS sexo, /* se adiciono columna sexo_id*/
CASE 
WHEN i.ingreso IS NULL THEN '0'
ELSE i.ingreso END AS ingreso,
pl.plan_descripcion AS Plan,
su.nombre AS usuario_registro_ingreso,
nt.nivel_triage_id AS nivel_triage,
nt.descripcion AS nivel_triage_descripcion, 
 td.diagnostico_id AS cod_diagnostico,
 dg.diagnostico_nombre,
TO_CHAR(t.hora_llegada, 'YYYY-MM-DD') AS fecha_registro_admision_triage,
 TO_CHAR(t.hora_llegada, 'HH24:MI') AS hora_llegada_admision_triage,
 sy.nombre AS medico_clasifica,
 TO_CHAR(he.fecha, 'YYYY-MM-DD') AS  fecha_medico_abrio_historia,
 TO_CHAR(he.fecha, 'HH24:MI') AS  Hora_medico_abrio_historia,
 TO_CHAR(he.fecha-t.hora_llegada, 'HH24:MI') AS tiempo_espera_triage,

 TO_CHAR(t.fecha_clasificacion , 'YYYY-MM-DD') AS fecha_medico_guarda_triage,
  TO_CHAR(t.fecha_clasificacion , 'HH24:MI') AS hora_medico_guarda_triage,
 TO_CHAR(he.fecha-t.fecha_clasificacion, 'HH24:MI') AS tiempo_medico_demora_haciendo_triage

FROM triages t
LEFT OUTER JOIN niveles_triages nt ON t.nivel_triage_id=nt.nivel_triage_id
INNER JOIN puntos_triage pt ON t.punto_triage_id=pt.punto_triage_id
LEFT OUTER JOIN triages_diagnosticos td ON t.triage_id=td.triage_id
LEFT OUTER JOIN diagnosticos dg ON td.diagnostico_id=dg.diagnostico_id
INNER JOIN ingresos i ON t.ingreso=i.ingreso 
INNER JOIN planes pl ON pl.plan_id=t.plan_id
INNER JOIN pacientes p ON t.paciente_id=p.paciente_id AND t.tipo_id_paciente=p.tipo_id_paciente  
LEFT  JOIN system_usuarios sy ON t.usuario_clasificacion=sy.usuario_id 
LEFT JOIN system_usuarios su ON i.usuario_id=su.usuario_id
INNER JOIN (select MIN(evolucion_id) as evolucion_id, ingreso
from hc_evoluciones
where hc_modulo = 'UrgenciasConsulta'
group by ingreso) as hee ON hee.ingreso = t.ingreso
INNER JOIN hc_evoluciones as he ON t.ingreso = he.ingreso AND hee.evolucion_id = he.evolucion_id
WHERE t.hora_llegada::date between _1 AND _2