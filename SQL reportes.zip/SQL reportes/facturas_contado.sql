SELECT 	fc.factura_fiscal AS factura,
		f.tipo_id_tercero,
		f.tercero_id,
		f.total_factura::integer,
		fc.total_efectivo::integer,
		fc.total_tarjetas::integer,
		fc.fecha_registro::date AS fecha	
FROM		fac_facturas_contado fc,
		fac_facturas f
WHERE		f.factura_fiscal = fc.factura_fiscal
AND		fc.fecha_registro::date = f.fecha_registro::date
AND		fc.fecha_registro::date >= _1 
AND 		fc.fecha_registro::date <= _2