SELECT  DISTINCT v.prefijo,
v.numero,
v.cargo_cups,
v.cargo AS cargo_tarifario, 
td.descripcion,
p.plan_descripcion AS entidad,
v.tipo_id_paciente,
v.paciente_id,
v.tipo_id_tercero,
v.tercero_id,
t.nombre_tercero AS profesional,
v.valor_real,
v.numerodecuenta

FROM voucher_honorarios v,
planes p,
terceros t,
tarifarios_detalle td,
cuentas c

WHERE v.plan_id = p.plan_id
AND v.tercero_id = t.tercero_id
AND v.numerodecuenta = c.numerodecuenta
AND c.estado = '0'
AND v.cargo = td.cargo
AND v.tarifario_id = td.tarifario_id
AND v.valor_real > 0
AND v.fecha_registro::date >= _1
AND v.fecha_registro::date <= _2
ORDER BY v.numero