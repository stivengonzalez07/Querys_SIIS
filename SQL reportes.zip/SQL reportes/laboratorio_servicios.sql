SELECT cu.descripcion as Laboratorio, os.cantidad as cantidad, se.descripcion as servicio, cu.precio as valor, os.fecha_solicitud, om.fecha_cumplimiento, ff.fecha_registro as fecha_factura
FROM cups as cu, hc_os_solicitudes os, servicios se, os_maestro as om, fac_facturas_cuentas as ffc, fac_facturas as ff
WHERE os.cargo = cu.cargo
AND se.servicio = os.servicio
AND cu.grupo_tarifario_id = '17'
AND cu.subgrupo_tarifario_id = '90'
AND os.fecha_solicitud::date BETWEEN _1 AND _2
AND os.hc_os_solicitud_id = om.hc_os_solicitud_id
AND om.numerodecuenta = ffc.numerodecuenta
AND ff.factura_fiscal = ffc.factura_fiscal
group by cu.descripcion, se.descripcion, cu.precio, os.cantidad, os.fecha_solicitud, om.fecha_cumplimiento, ff.fecha_registro

order by cantidad desc

limit 100