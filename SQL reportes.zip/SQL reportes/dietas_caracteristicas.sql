SELECT h.fecha_solicitud,
c.descripcion_solicitud,
j.descripcion,
CASE WHEN l.descripcion = 'HPGL' THEN 'HIPOGLUCIDA'
     WHEN l.descripcion = 'Hipoglucida' THEN 'HIPOGLUCIDA'
     END AS descripcion, 
COUNT(*) AS dietas_solicitadas
FROM dietas_solicitud_detalle a, 
ingresos b, 
dietas_tipos_solicitud c,  
estaciones_enfermeria g,
dietas_solicitud h, 
pacientes i,
hc_tipos_dieta j, 
dietas_solicitud_detalle_caracteristicas k, 
hc_solicitudes_dietas_caracteristicas l 
WHERE a.tipo_solicitud_dieta_id=c.tipo_solicitud_dieta_id 
AND a.ingreso_id=b.ingreso 
AND a.estacion_id=g.estacion_id 
AND a.ingreso_id=h.ingreso_id 
AND a.fecha_solicitud=h.fecha_solicitud 
AND a.tipo_solicitud_dieta_id=h.tipo_solicitud_dieta_id 
AND b.tipo_id_paciente=i.tipo_id_paciente  
AND b.paciente_id=i.paciente_id 
AND h.fecha_solicitud 
BETWEEN _1 AND _2 
AND a.hc_dieta_id=j.hc_dieta_id 
AND h.estado_dieta IN ('1','2') 
AND a.ingreso_id=k.ingreso_id 
AND a.fecha_solicitud=k.fecha_solicitud 
AND a.tipo_solicitud_dieta_id=k.tipo_solicitud_dieta_id 
AND a.estacion_id=k.estacion_id 
AND k.caracteristica_id=l.caracteristica_id 
AND l.descripcion IN ('Hipoglucida', 'HPGL')
GROUP BY h.fecha_solicitud,c.descripcion_solicitud,j.descripcion,l.descripcion 
ORDER BY h.fecha_solicitud,c.descripcion_solicitud,j.descripcion,l.descripcion