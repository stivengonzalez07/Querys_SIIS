select a.ingreso,a.tipo_id_paciente,a.paciente_id,concat
(f.primer_apellido,' ',f.segundo_apellido,' ',f.primer_nombre,' ',f.segundo_nombre) as Nombre_Completo,
a.fecha_ingreso,b.descripcion as Causa_Externa,c.via_ingreso_nombre,d.descripcion as Causa_Salida,
e.fecha_registro as Fecha_Salida from ingresos a, causas_externas b, vias_ingreso c, 
hc_epicrisis_tipos_causa_salida d, hc_epicrisis_datos_salida e, pacientes f 
where a.ingreso=e.ingreso and a.causa_externa_id=b.causa_externa_id and 
a.via_ingreso_id=c.via_ingreso_id and d.hc_epicrisis_tipo_causa_salida_id=e.hc_epicrisis_tipo_causa_salida_id and
e.hc_epicrisis_tipo_causa_salida_id in ('1','2') and 
a.tipo_id_paciente=f.tipo_id_paciente and a.paciente_id=f.paciente_id and 
e.fecha_registro::date BETWEEN _1 AND _2 order by e.fecha_registro asc
