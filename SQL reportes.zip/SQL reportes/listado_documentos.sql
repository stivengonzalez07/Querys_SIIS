SELECT 
documento_id,
tipo_doc_general_id,
prefijo,
descripcion,
sw_contabiliza,
sw_estado_interfazado,
sw_costos
FROM public.documentos;