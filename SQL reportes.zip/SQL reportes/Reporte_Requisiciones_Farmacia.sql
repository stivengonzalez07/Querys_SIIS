SELECT    
copd.requisicion_id, 
comreq.fecha_requisicion,
depar.descripcion AS Area,
copd.codigo_producto AS Codigo,
invp.descripcion AS descripcion_producto,
unid.descripcion unidad_de_manejo, 
copd.numero_unidades :: int AS cantidad_requisicion, 
su.nombre,        
copd.codigo_producto AS producto_oc,
copd.numero_unidades :: int AS cantidad_solicitada_oc, 
t.nombre_tercero AS proveedor,
tf.nombre_tercero AS proveedor_final, 
cop.fecha_registro AS fecha_creacion_oc,
(CASE WHEN doc.cantidad IS NOT NULL 
                                THEN doc.cantidad 
                                ELSE 0 
                           END )::int as cantidad_recibida, 
                          (copd.numero_unidades - (CASE WHEN copd.numero_unidades_recibidas IS NOT NULL 
                                                   THEN copd.numero_unidades_recibidas 
                                                   ELSE 0 END )):: int AS faltantes, 
-- Round(copd.valor,2) AS precio_unitario_oc, 
-- Round(copd.porc_iva,2) AS iva, 
-- Round((copd.numero_unidades * copd.valor),2) AS valor_total_oc_enviada,
-- copd.numero_unidades2 :: int AS cantidad_solicitada_proveedor_final, 
-- Round(copd.valor2,2) AS precio_unitario_proveedor_final, 
-- Round(copd.porc_iva2,2) AS iva_proveedor_final, 
-- Round((copd.numero_unidades2 * copd.valor2),2) AS valor_total_proveedor_final, 
doc.prefijo_factura, 
doc.numero_factura, 
doc.fecha_factura, 
doc.numero_doc_ingreso, 
doc.prefijo_documento_ingreso, 
doc.fecha_ingreso_al_sistema, 
cop.fecha_envio as fecha_envio_oc
--, 
-- Round((nullif(doc.total_costo,0)/nullif(doc.cantidad,0)),2) as precio_factura, 
-- Round(((nullif(doc.total_costo,0)/nullif(doc.cantidad,0)) - copd.valor),2) as diferencia 
                          
        FROM compras_ordenes_pedidos_detalle AS copd
        LEFT JOIN compras_ordenes_pedidos AS cop ON (copd.orden_pedido_id = cop.orden_pedido_id) 
        LEFT JOIN compras_requisiciones AS comreq ON ( copd.requisicion_id = comreq.requisicion_id )
        LEFT JOIN departamentos AS depar ON ( comreq.departamento=depar.departamento ) 
        LEFT JOIN system_usuarios AS su ON (su.usuario_id = cop.usuario_id)
        LEFT JOIN inventarios_productos AS invp ON ( copd.codigo_producto=invp.codigo_producto )
        LEFT JOIN unidades AS unid ON ( invp.unidad_id=unid.unidad_id )   
        LEFT JOIN ( SELECT  ibmocd.requisicion_id AS requisicion_id,
                                ibmoc.orden_pedido_id AS orden_pedido_id, 
                                ibmocd.codigo_producto AS codigo_producto, 
                                ibmoc.prefijo AS prefijo_factura, 
                                ibmoc.numero :: varchar AS numero_factura, 
                                ibmoc.fecha_factura :: date AS fecha_factura, 
                                ibm.prefijo AS prefijo_documento_ingreso, 
                                ibm.numero AS numero_doc_ingreso, 
                                ibm.fecha_registro:: date AS fecha_ingreso_al_sistema, 
                                ibmoc.fecha_recepcion AS fecha_recepcion
                                , 
                                 SUM(ibmocd.total_costo) AS total_costo, 
                                 SUM(ibmocd.cantidad) AS cantidad 
                        FROM inv_bodegas_movimiento_ordenes_compra_i008 AS ibmoc 
                        LEFT JOIN inv_bodegas_movimiento AS ibm ON (ibmoc.empresa_id = ibm.empresa_id AND ibmoc.prefijo = ibm.prefijo AND 
                                                                    ibmoc.numero = ibm.numero) 
                        LEFT JOIN inv_bodegas_movimiento_d AS ibmocd ON (ibm.empresa_id = ibmocd.empresa_id AND ibm.prefijo = ibmocd.prefijo AND 
                                                                            ibm.numero = ibmocd.numero)
                            GROUP BY 1,2,3,4,5,6,7,8,9,10 
                            UNION
                            SELECT  ibmocd.requisicion_id AS requisicion_id,
                                    ibmoc.orden_pedido_id AS orden_pedido_id, 
                                    ibmocd.codigo_producto AS codigo_producto, 
                                    ibmoc.prefijo_factura AS prefijo_factura, 
                                    ibmoc.numero_factura :: varchar AS numero_factura, 
                                    ibmoc.fecha_factura :: date AS fecha_factura, 
                                    ibm.prefijo AS prefijo_documento_ingreso, 
                                    ibm.numero AS numero_doc_ingreso, 
                                    ibm.fecha_registro:: date AS fecha_ingreso_al_sistema, 
                                    ibmoc.fecha_recepcion AS fecha_recepcion
                                    , 
                                    SUM(ibmocd.total_costo) AS total_costo, 
                                    SUM(ibmocd.cantidad) AS cantidad 
                            FROM inv_bodegas_movimiento_ordenes_compra AS ibmoc 
                            LEFT JOIN inv_bodegas_movimiento AS ibm ON ( ibmoc.empresa_id = ibm.empresa_id AND ibmoc.prefijo = ibm.prefijo AND 
                                                                         ibmoc.numero = ibm.numero) 
                            LEFT JOIN inv_bodegas_movimiento_d AS ibmocd ON (ibm.prefijo = ibmocd.prefijo AND 
                                                                             ibm.numero = ibmocd.numero)
                                      GROUP BY 1,2,3,4,5,6,7,8,9,10 
                            UNION
                            SELECT  ibmocd2.requisicion_id AS requisicion_id,
                                    ibmoc2.orden_pedido_id AS orden_pedido_id, 
                                    ibmocd.codigo_producto AS codigo_producto, 
                                    ibmoc.prefijo AS prefijo_factura, 
                                    ibmoc.numero :: varchar AS numero_factura, 
                                    ibmoc.fecha_factura :: date AS fecha_factura, 
                                    ibm.prefijo AS prefijo_documento_ingreso, 
                                    ibm.numero AS numero_doc_ingreso, 
                                    ibm.fecha_registro:: date AS fecha_ingreso_al_sistema, 
                                    ibm.fecha_registro:: date AS fecha_recepcion
                                     , 
                                     SUM(ibmocd.total_costo) AS total_costo, 
                                     SUM(ibmocd.cantidad) AS cantidad 
                            FROM inv_bodegas_movimiento_factura_remision AS ibmoc 
                            LEFT JOIN inv_bodegas_movimiento AS ibm ON ( ibmoc.empresa_id = ibm.empresa_id AND ibmoc.prefijo = ibm.prefijo AND 
                                                                         ibmoc.numero = ibm.numero) 
                            LEFT JOIN inv_bodegas_movimiento_d AS ibmocd ON (ibm.empresa_id = ibmocd.empresa_id AND ibm.prefijo = ibmocd.prefijo AND 
                                                                             ibm.numero = ibmocd.numero)
                            LEFT JOIN inv_bodegas_movimiento_d AS ibmocd2 ON (ibmocd2.movimiento_id = ibmocd.movimiento_id_ref)
                            LEFT JOIN inv_bodegas_movimiento_ordenes_compra_i008 AS ibmoc2 ON (ibmoc2.empresa_id = ibmocd2.empresa_id AND ibmoc2.prefijo = ibmocd2.prefijo AND 
                                                                                               ibmoc2.numero = ibmocd2.numero)
                            GROUP BY 1,2,3,4,5,6,7,8,9,10) AS doc ON (copd.orden_pedido_id = doc.orden_pedido_id AND 
                                                                                 copd.codigo_producto = doc.codigo_producto AND
                                                                                 copd.requisicion_id = doc.requisicion_id) 
                JOIN terceros_proveedores AS tp ON (cop.codigo_proveedor_id = tp.codigo_proveedor_id) 
                JOIN terceros AS t ON (tp.tipo_id_tercero = t.tipo_id_tercero AND tp.tercero_id = t.tercero_id)
                LEFT JOIN terceros_proveedores AS tpf ON (cop.codigo_proveedor_final = tpf.codigo_proveedor_id) 
                LEFT JOIN terceros AS tf ON (tpf.tipo_id_tercero = tf.tipo_id_tercero AND tpf.tercero_id = tf.tercero_id)  
                WHERE copd.estado != '4' 
                AND cop.fecha_registro::date BETWEEN 
                _1 AND _2 --RANGO FECHA DE CREACIÓN DE LA OC 
                --'2021-11-01' AND '2021-11-09'