SELECT
 ip.codigo_producto,
 ip.codigo_barras,
 ip.descripcion,
 ip.referencia,
 i.precio_venta,
 i.costo,
 u.descripcion AS unidad,
 ip.codigo_invima,
 ip.sw_pos AS POS,
 (select mp.codigo_cum from medicamentos mp where ip.codigo_producto=mp.codigo_medicamento limit 1) as codgio_cum,
 ip.codigo_cum,
 ip.porc_iva,
 i.fecha_registro as Fecha_Creacion,
 us.nombre,
 ip.codigo_atc,
 ip.grupo_id,
 si.descripcion
FROM
 inventarios_productos ip
LEFT OUTER JOIN inventarios i ON i.codigo_producto=ip.codigo_producto
LEFT OUTER JOIN unidades u ON ip.unidad_id=u.unidad_id
LEFT OUTER JOIN inv_subclases_inventarios si ON ip.grupo_id=si.grupo_id AND ip.clase_id=si.clase_id AND  ip.subclase_id=si.clase_id
LEFT JOIN system_usuarios us ON i.usuario_id=us.usuario_id
