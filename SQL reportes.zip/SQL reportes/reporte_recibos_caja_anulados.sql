SELECT rcd.prefijo || rcd.recibo_caja as Recibo_caja, 
rcd.numerodecuenta as Cuenta, 
rc.total_abono as Valor_recibo, 
su.nombre as Usuario_anula,
ca.fecha_registro as Fecha_anulacion,
ma.motivo_descripcion as Motivo_anulacion,
ca.observacion as Observacion_anulacion
FROM rc_detalle_hosp rcd,
recibos_caja rc,
cajas_auditoria_anulaciones ca,
cajas_motivos_anulaciones ma,
system_usuarios su
WHERE  rc.recibo_caja=rcd.recibo_caja
AND ca.recibo_caja=rc.recibo_caja
AND ma.motivo_anulacion_id=ca.motivo_anulacion_id
AND su.usuario_id=ma.usuario_id
AND rc.sw_recibo_tesoreria is null
AND ca.fecha_registro BETWEEN _1 AND _2